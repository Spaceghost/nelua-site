CC := /srv/ai/cache/nelibc-cosmo/toolchain/bin/x86_64-unknown-cosmo-cc
CFLAGS += -O2 -pipe -std=c99 -D_POSIX_C_SOURCE=200809L -fno-builtin -frounding-math -Wno-unknown-pragmas -Werror=implicit-function-declaration -Werror=implicit-int -Werror=pointer-sign -Werror=pointer-arith
LDFLAGS += -s 
LDLIBS += -lpthread -lm -lrt
RUN_TEST := /srv/ai/artifacts/nelibc-cosmo/easy-first-20261117/conformance-final/supervisor/src/common/runtest.exe -w /srv/ai/tmp/nelibc-cosmo/.ape-1.10
