CC := gcc
CFLAGS += -O2 -pipe -std=c99 -D_POSIX_C_SOURCE=200809L -fno-builtin -frounding-math -Wno-unknown-pragmas -Werror=implicit-function-declaration -Werror=implicit-int -Werror=pointer-sign -Werror=pointer-arith
LDFLAGS += -s 
LDLIBS += -lpthread -lm -lrt -lcrypt -ldl -lresolv -lutil
RUN_TEST := /srv/ai/artifacts/nelibc-cosmo/conformance-final-20261117/supervisor/src/common/runtest.exe
LDLIBS := /srv/ai/workspaces/nelibc/cosmo/build/libnelibc-gcc.a $(LDLIBS)
