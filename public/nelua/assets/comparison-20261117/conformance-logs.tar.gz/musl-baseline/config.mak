CC := /opt/zig/zig cc -mcpu=x86_64 -target x86_64-linux-musl
CFLAGS += -O2 -pipe -std=c99 -D_POSIX_C_SOURCE=200809L -fno-builtin -frounding-math -Wno-unknown-pragmas -Werror=implicit-function-declaration -Werror=implicit-int -Werror=pointer-sign -Werror=pointer-arith
LDFLAGS += -s -static
LDLIBS += -lpthread -lm -lrt
RUN_TEST := /srv/ai/artifacts/nelibc-cosmo/conformance-final-20261117/supervisor/src/common/runtest.exe
