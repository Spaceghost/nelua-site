CC := /opt/zig/zig cc -mcpu=x86_64 -target x86_64-linux-musl
CFLAGS += -O2 -pipe -std=c99 -D_POSIX_C_SOURCE=200809L -fno-builtin -frounding-math -Wno-unknown-pragmas -Werror=implicit-function-declaration -Werror=implicit-int -Werror=pointer-sign -Werror=pointer-arith
LDFLAGS += -s -static -Wl,-u,nelibc_hybrid_free -Wl,--wrap=fread -Wl,--wrap=fwrite -Wl,--wrap=fflush -Wl,--wrap=fileno -Wl,--wrap=feof -Wl,--wrap=ferror -Wl,--wrap=clearerr -Wl,--wrap=ungetc -Wl,--wrap=freopen -Wl,--wrap=fgetpos -Wl,--wrap=fsetpos -Wl,--wrap=fseek -Wl,--wrap=ftell -Wl,--wrap=fseeko -Wl,--wrap=ftello -Wl,--wrap=setvbuf -Wl,--wrap=flockfile -Wl,--wrap=ftrylockfile -Wl,--wrap=funlockfile -Wl,--wrap=fclose -Wl,--wrap=localeconv -Wl,--wrap=setlocale -Wl,--wrap=atexit -Wl,--wrap=exit -Wl,--wrap=free -Wl,--wrap=realloc
LDLIBS += -lpthread -lm -lrt
RUN_TEST := /srv/ai/artifacts/nelibc-cosmo/conformance-final-20261117/supervisor/src/common/runtest.exe
LDLIBS := /srv/ai/workspaces/nelibc/cosmo/build/libnelibc-zig-musl.a $(LDLIBS)
