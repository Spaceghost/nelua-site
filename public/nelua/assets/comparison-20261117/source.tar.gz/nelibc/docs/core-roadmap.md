# Core gaps and priorities

This is a working order for making Nelibc a dependable, general-purpose Linux
libc. “Implemented” in the API manifest means a symbol is present in the
archive; it does not certify every behavior required by C or POSIX.

## Priority order

| Priority | Gap | Why it blocks a compelling libc | Next milestone |
|---|---|---|---|
| P0 | Reliable build and consumer gate | Regressions in any compiler/libc profile undermine every replacement | Keep the seven-profile `make smoke-matrix` and four-profile `make dogfood-matrix` green as the source changes; shrink the libc-test expected lists, hybrid and standalone (`docs/libc-test.md`) |
| P1 | C math library | The Nelua slice includes binary32/binary64 math, including `scalb`, `scalbf`, `significand`, and `significandf`, plus x86-64 long-double math, internal binary32/64/80 classification, and all standard standalone x86-64 fenv entry points; hybrid fenv delegates to the host | Expand long-double edge coverage, fenv environment edges, and math quality/performance |
| P1 | Standalone threading completeness | Standalone pthread remains a subset; several POSIX behaviors and process/signal APIs remain gaps | Continue POSIX pthread behavior coverage and audit process/signal interactions |
| P1 | Process creation APIs | Standalone `posix_spawn`/`posix_spawnp` handles direct execution, PATH lookup, synchronous setup/exec-error reporting, ordered close/dup2/open/chdir/fchdir file actions, and standard spawn attributes; negative file-action descriptors return `EBADF` | Broaden process/signal/fork interaction audit and successful real-time scheduling coverage where permitted; hybrid profiles continue to use host spawn implementations |
| P2 | Locale and character data | Standalone locale data supports C plus UTF-8 case/width/classification, C-style C/C.UTF-8 collation, a limited German UTF-8 collation, C/German numeric/monetary conventions, and German `LC_TIME` names/formats; thread and global locale state carry ctype, numeric, monetary, collation, and time categories | Expand Unicode collation weights and add more locale datasets |
| P2 | Host profile (freestanding consumers) | Writ's freestanding Bend runtime and a Drift-style kernel need the standalone libc without Linux beneath it; `docs/host-profile.md` supplies it as the standalone archive over a `nelibc_host` callback table, with pthreads as cooperative lanes on the host's one hardware thread, fault delivery, a generated-C snapshot, and `make host-matrix`, `host-snapshot-matrix`, and the unmodified Bend 2.0.39 runtime as consumer checks | Kernel (preemptive) threads behind the same table and a QEMU long-mode boot of the Bend corpus beside Drift's reference kernel |
| P2 | API-surface audit | The generated coverage table only sees declarations in current project headers and smoke references are locators, not proofs | Corrected baseline comparison against musl 1.2.5 is recorded in `docs/musl-1.2.5-api-coverage.csv`; classify the remaining undeclared candidates by program impact and record intentional omissions |
| P3 | Platform portability | The modules ask for platform work through Nelibc's own operation vocabulary (`include/nelibc_sys.h`, `nelibc_sys3/6`), with Linux x86-64 one backend (`src/sys/linux_x86_64_ops.c`, a number table) and the host profile another; the operation names still pin Linux syscall semantics and argument shapes, and the entry points and thread register are x86-64 | Add a second architecture backend (its own number table plus the entry point and TLS register) before claiming portable standalone support |

## Current evidence

### libc-test standalone baseline, 2026-11-07 (branch `libc-test-standalone`)

`make libc-test-standalone-gcc` and `-zig` build libc-test's functional,
regression and math tests with Nelibc's headers only, link them statically
with Nelibc's `_start` and the standalone archive, and run them under
libc-test's own runner built the same way. First run on main `3ea86f3` plus
the harness (container `nelibc-writ`, user `build`): gcc 255 of 343 pass
(78 build, 6 link, 3 fail, 1 timeout), zig 277 pass (50 build, 3 link, 12
fail, 1 timeout); every math test that builds passes. Nelibc has no
`<limits.h>`, which blocks 32 tests under GCC only. Run-time bugs found:
static constructors never run in standalone binaries, `ftello` in append
mode, `sem_open` reopen, scanf `%n`/`EOF`/pushback, `ungetc` after a failed
scan, cancellation cleanup handlers and `sem_wait` cancellation,
`pthread_create` `ENOMEM`, `atexit` after the last `pthread_exit`, and a
normal PI mutex relock returning `EDEADLK`. `docs/libc-test.md`, "Standalone
profile", ranks the missing headers and functions. No Nelibc source changed;
the 155-target gate was not run on this branch.

### libc-test slice 1, 2026-11-07

musl's libc-test (`63e36e9`) now runs against the gcc and zig hybrid archives
as `make libc-test-gcc` and `make libc-test-zig`, with the failing set checked
against `tools/libc_test_expected_<profile>.txt`. The first runs (container
`nelibc-writ`, glibc 2.36 baseline fails 43) found and this slice fixed: five
header gaps visible only with Nelibc's headers first (`<poll.h>`,
`<ctype.h>`, `<string.h>`, `<strings.h>`, `<inttypes.h>`), `inet_aton`'s
hex/octal grammar and `inet_pton`'s leading zeros, `%f` capped at 22 digits
and `%a` of zero, `strptime` `%z` without minutes, and `sigaddset` accepting
signal 33. It added `strsignal`, `strerror_l`, `strcasecmp_l`,
`strncasecmp_l`, `strcoll_l` and `strxfrm_l`. Remaining: 112 (gcc) and 118
(zig) expected failures, 78 of them math exception flags and ulp errors;
`docs/libc-test.md` classifies them.

Gate: the 155-target list, same container and user, Nelua `dabbd9ef`, on
`1cfe68a`: 150 exited 0. Five exited 2, all from this slice's own `%a`
changes: `smoke-standalone-{zig,gcc}` and `smoke-lib-standalone-{zig,gcc}`
expected `%.0a` of 3.5 as `0x1p+2` (now `0x2p+1`, the glibc and musl
carry), and `stdio-format-diff-zig-musl` diffed a subnormal `%a` that glibc
and musl legitimately print differently. Fixed in `151e773` and `d1353ef`;
the five targets rerun on `d1353ef` all exited 0. The other 150 were not
rerun on `d1353ef`; the two fixes touch only `tools/syscall_smoke.c` and
`tools/stdio_format_diff.c`.


### libc-test slice 2, 2026-11-07 (branch `libc-test-slice-2`)

`strftime` flags/widths and ISO week, `fnmatch` bracket semantics, exact
`%La`, `%Le/%Lf/%Lg` for double-valued arguments, `malloc_usable_size` in
every profile that exports `malloc`, the TZif reader off the stack, and
scanf `%Nc` on short input. libc-test: gcc 114 expected (was 112: 3 fixed,
5 long double math tests that an output-parsing gap had hidden), zig 116
(was 118: 7 fixed, the same 5 added). Smokes observed green on this branch:
`lib-consumer-{gcc,zig,zig-musl,standalone-gcc,standalone-zig}`,
`smoke-standalone-{gcc,zig}`, `smoke-lib-standalone-{gcc,zig}`,
`stdio-format-diff-{gcc,zig-musl}`.

Gate: the 155-target list, container `nelibc-writ`, user `build`, Nelua
`dabbd9ef`. The first run, on `7120e7c`, failed every zig-linked shootout
at link time: zig cc's default UBSan instrumented the `dlsym` call in the
new hybrid `malloc_usable_size` adapter with `__ubsan_handle_nonnull_arg`,
and those targets link without the UBSan runtime. `236d556` compiles
`src/alloc_hybrid_adapter.c` with `-fno-sanitize=all` under zig, like
`src/stdio_host_adapter.c`. The rerun on `236d556`: 155/155 targets exited
0 and no log contains a warning; logs in
`/work/artifacts/gate-slice2b-20261107-0824/`.

Open after this slice: the math flag/ulp list, scanf/strftime/fnmatch cases
only testable in the standalone profile. (Exact decimal `%Le/%Lf/%Lg`: see
below.)

### Exact long double decimal, 2026-11-07 (branch `long-double-decimal`)

`%Le`, `%Lf`, `%Lg` (and `E`/`F`/`G`) of a long double that is not exactly a
double used to return -1 with `EINVAL`. They are now formatted exactly:
`nelibc_format_long_double_parts` in `src/stdlib_float.nelua` writes the
value `m * 2^e` (64-bit `m`, subnormals and pseudo-denormals by the same
formula) as its complete decimal expansion with the existing big-integer
code, at most 4,932 integer digits or `m * 5^16445` below one, then rounds
the digit string half to even, as the double path does. `%g` picks its style
from the exponent after rounding, as C requires. Values that are doubles,
infinities and NaNs keep the double path. The sign comes from the x87 sign
bit, so `-1e-4000L` prints `-0.000000`. Not done: the current rounding mode
is not consulted (glibc honors it), and the `'` grouping flag is ignored on
this path. `tools/lib_consumer_smoke.c` checks 28 cases against glibc 2.36's
strings, including half-to-even ties at the 63rd fraction digit, the
smallest subnormal, `LDBL_MAX` in full (4,940 characters) and width/flag
combinations; `tools/syscall_smoke.c` checks the standalone `swprintf`.

Gate: the 155-target list, container `nelibc-writ`, user `build`, Nelua
`dabbd9ef`, on `21d45df` (this change merged with the libm slice): 155/155
targets exited 0 and no log contains a warning; logs in
`/work/artifacts/gate-ldd2-20261107-0947/`. A first attempt died at target
48 when the container's disk filled; it produced no failure, only no result.

### libm slice, 2026-11-07 (musl math ports)

`src/math_core.nelua` carries ports of musl 1.2.5's exp/exp2/pow/log/log2
(table driven), the fdlibm-derived log10/log1p/expm1/hypot, trigonometric,
hyperbolic and inverse families, lgamma_r, tgamma, the Bessel functions and
musl's ld80 lgammal_r/tgammal, with musl's exception-flag discipline through
an opaque asm barrier. libc-test (`docs/libc-test.md`, "The libm slice"):
gcc 38 and zig 42 expected failures, down from 114 and 116; the seven math
tests left are `fma`, `fmaf` and five long double functions this slice did
not port.

Gate: the 155-target list, container `nelibc-writ`, user `build`, Nelua
`dabbd9ef`, on `87f1ddf`: 155/155 targets exited 0 and no log contains a
warning; logs in `/work/artifacts/gate-libm-20261107-0854/`.

### Gate run, 2026-11-07 (Nelua `dabbd9ef`, no source change)

Same container, user and target list as the runs below, on main `28879ed`
with a fresh compiler cache and Nelua `dabbd9ef` at
`/opt/nelua-dabbd9ef/nelua`: 155/155 targets exited 0 and no log contains a
warning; logs in `/work/artifacts/gate-forkdabb-20261107-0001/`. `dabbd9ef`
completes optional types (constant optionals as C static initializers,
bindgen `--nullable-returns`, editor grammars) and changes one emitter path
nelibc does exercise: a comptime string converted to `cstring` is now
emitted as a C string literal instead of a `nelua_string2cstring` call, so
this run is the evidence that the change is neutral for every profile. The
pin moves to `dabbd9ef` on this evidence.

### Gate run, 2026-11-06 (Nelua `b8ea333e`, no source change)

Same container, user and target list as the runs below, on main `4c68b8e`
with a fresh compiler cache and Nelua `b8ea333e` at
`/opt/nelua-b8ea333e/nelua`: 155/155 targets exited 0 and no log contains a
warning; logs in `/work/artifacts/gate-forkb8ea-20261106-2252/`. `b8ea333e`
adds `orelse`, `if local` and the errmsg/ok kinds of `?` to the compiler,
makes `orelse` a reserved word, and changes two C-generator paths (numeric
`for` bound scoping and immediately invoked capturing closures); nelibc's
sources use none of the new syntax and the gate shows the generator changes
are neutral for them. The pin moves to `b8ea333e` on this evidence.

### Gate run, 2026-11-06 (Nelua `cde61925`, no source change)

Same container, user and target list as the `9cd1b74a` run below, on main
`add2e1a` with a fresh compiler cache and Nelua `cde61925` at
`/opt/nelua-cde61925/nelua`: 155/155 targets exited 0 and no log contains a
warning; logs in `/work/artifacts/gate-forkcde6-20261106-2121/`. `cde61925`
adds optional types (`T?`, `expr?`) to the compiler; the `?` type operator
moved from prefix to postfix and the analyzer gained a boolean-context check,
neither of which nelibc's sources exercise. The pin moves to `cde61925` on
this evidence.

### Gate run, 2026-11-06 (Nelua `9cd1b74a`, no source change)

Recorded in the Incus container `nelibc-writ` on bak (Debian 12, glibc 2.36,
GCC 12.2, Zig 0.17.0, Nelua `9cd1b74a` at `/opt/nelua-9cd1b74a/nelua`, Bend
2.0.39), as the unprivileged `build` user, one target at a time, on main
`b17ec18` with a fresh compiler cache. The same 155 targets as the 2026-11-05
gate all exited 0 and no log contains a Nelua warning; logs in
`/work/artifacts/gate-fork9cd1-20261106-2028/`. Nelua `9cd1b74a` adds variant
`==`/`tostring`/`visit`, nelua-bindgen `--exclude`/`--opaque`/`--config`,
named nested closures with `<byref>`, and editor grammars over `1ad3d5ce`;
nelibc uses none of them yet, so this run only shows the compiler move is
neutral for the library. The pin in `AGENTS.md` and
`.github/workflows/host.yml` moves to `9cd1b74a` on this evidence.

### Gate run, 2026-11-05 (`*const` migration, Nelua `1ad3d5ce`)

Recorded in the Incus container `nelibc-writ` on bak (Debian 12, glibc 2.36,
GCC 12.2, Zig 0.17.0, Nelua `1ad3d5ce` at `/opt/nelua-1ad3d5ce/nelua`, Bend
2.0.39), as the unprivileged `build` user, one target at a time, on the
migrated tree (this commit's sources applied over main `bb21861`). The 155
targets of the 2026-11-05 platform-operation gate (`sys-ops-check`,
`smoke-matrix`, `dogfood-matrix`, `host-matrix`, `host-snapshot-matrix`,
`host-bend-*`, and the shootouts, no TinyCC profile) all passed; logs in
`/work/artifacts/gate-mig8-20261105-1956/`. The same 112 non-shootout targets had passed
on the unmigrated tree with Nelua `2813b433` first
(`/work/artifacts/gate-full-20261105-1926/`), so the compiler move and the
source migration were observed separately.

The migration itself: every `cstring <const>`, `*[0]T <const>`,
`pointer <const>` and `*Record <const>` parameter shim became a real
`*const` pointer type (the fork's `const T*` mapping), the 26 `## cemitdefn`
wide-character wrappers in `memory.nelua` became exported Nelua functions,
and explicit casts mark the places where C's `strchr`-style contract returns
a mutable pointer into const input. Nelua `1ad3d5ce` also emits constant
top-scope initializers (`nilptr`, `&global`, record literals of those) as C
static initializers; before that `tzname`, `all_streams` and the default
`struct tm` values were assigned inside a `nelua_main` nothing calls under
`noentrypoint`. The build now compiles every module without the
"top scope statements are emitted into `nelua_main`" warning.

### Gate run, 2026-11-04 (main `5c54547`)

Recorded in the Incus container `nelibc-writ` on bak (Debian 12, glibc 2.36,
GCC 12.2, Zig 0.17.0, Nelua `3c29419`, Bend 2.0.39), as the unprivileged
`build` user, one target at a time. Every target reachable from
`smoke-matrix`, `dogfood-matrix`, `host-matrix`, and `host-bend-hello-zig`
that does not name a TinyCC profile passed: 112 targets across hybrid
Zig/glibc, GCC/glibc, and Zig/musl, standalone Zig and GCC, freestanding Zig
and GCC, and the host profile with Zig and GCC. The run surfaced and fixed
six regressions that the previous evidence had not covered because it was
recorded on a different host: the freestanding and collation-diff links
after `string.nelua` gained the `inet_*` conversions, a syscall smoke that
asserted an `unshare` failure which succeeds for a privileged caller, three
absolute-addressed x87 constant loads that Debian's default-PIE linker
rejects, a missing `stddef.h` in the standalone `signal.h`, missing
`INFINITY`/`NAN`/`HUGE_VAL*` in the standalone `math.h`, and a `powl`
identity check that compared exception flags against glibc 2.36's spurious
underflow.

After that run the `arpa/inet.h` conversions moved out of `string.nelua`
into `src/inet.nelua` (one object per profile in every archive), and the
`shootout-matrix` targets that do not name TinyCC were run on the same host
as the same user: 40 targets (memory, string, strstr, strcasecmp,
strverscmp, sysconf, confstr, pathconf, float, int, rand_r, qsort, stdio,
and I/O shootouts on Zig/glibc, GCC/glibc, and Zig/musl) completed and
wrote their CSVs under `/work/artifacts/gate-20261104-1640-shootout/` in
the container. The musl pathconf shootout now exempts
`REC_MIN_XFER_SIZE`, `REC_XFER_ALIGN`, and `ALLOC_SIZE_MIN`, which musl
hardcodes to 4096 while glibc and Nelibc report `f_bsize` (131072 on the
container's ZFS root). The numbers are from one machine and one run; they
locate regressions, they are not a published benchmark.

Not run: every `*-tcc` target. Debian's packaged TinyCC 0.9.27 cannot build
the profile (see the quickstart) and no mob-branch build is installed in the
container yet. Those profiles are unrun, not passing.

### Host profile lanes, 2026-11-04

The host profile gained cooperative threads: `pthread_create` makes a lane
on the one hardware thread, and the dispatcher switches lanes on every
blocking wait, `sched_yield`, and thread exit, with futex wake, requeue,
wake-op, and the priority-inheritance operations moving lanes, signals
queued per lane, and the robust list walked at exit. In the same change
the archive lost its last reachable `syscall` instructions (the credential
adapter now goes through the raw entry point; the raw syscall bodies and
the detached-exit helper are dropped from the host archive by section),
and `host-check-*` disassembles the whole-archive link to prove it. In the
same container and as the same user, `host-matrix` and
`host-snapshot-matrix` passed with Zig and GCC, `host-bend-hello-zig`
printed `hi`, the same hello executable printed `hi` and exited 0 at
`+RTS --threads 2`, `4`, and `8`, and the fork-join program
`tools/host_bend_parallel.bend` printed `65536` at `--threads 1`, `2`, `4`,
and `8` with the Bend pool's workers created and run as lanes (1, 3, and 7
lanes; 2, 6, and 14 switches) as reported by the harness's
`NELIBC_HOST_STATS=1` counters. `make host-bend-parallel-zig` now runs that
program at `--threads 4` and requires 65536 plus three worker lanes that
switched.

After the lane change, main `2e3ee6f` was gated in the same container as
the `build` user, one target at a time: all 152 non-TinyCC targets reachable
from `smoke-matrix`, `dogfood-matrix`, `host-matrix`, `host-bend-hello-zig`,
`host-snapshot-matrix`, and `shootout-matrix` passed (logs under
`/work/artifacts/gate-20261104-1906-lanes/`). One target,
`spawn-smoke-resetids-userns`, first failed because a second `make` in the
same tree rebuilt the standalone archive at the same moment (`ar: file
truncated`) and passed when rerun alone. `lib-adapter-symbols` needs the
TinyCC archive and stays unrun with the rest of the TinyCC profile.

### Platform operations, 2026-11-05

The modules stopped naming Linux syscalls: `tools/sys_ops.py` generates the
`NELIBC_SYS_*` vocabulary (`include/nelibc_sys.h`, 230 operations), the
Linux x86-64 number table (`src/sys/linux_x86_64_ops.c`), and the `SYS_*`
constant block each Nelua module uses; `make sys-ops-check` fails when any
of them is stale. The host profile answers the operations by name and its
callback is `thread_area_set` (the architecture's thread register), with no
Linux number in `src/host/`. Main `fd11a1c` was gated in the same container
as the `build` user, one target at a time: all 155 non-TinyCC targets
(the 152 above plus `sys-ops-check`, `host-bend-parallel-zig`, and the
`unistd-cancel` standalone pair now in the list) passed (logs under
`/work/artifacts/gate-20261105-0109-ops/`), and the `host.yml` workflow
passed on the same commit. The first push failed its CI link because
`zig cc` instruments the table index with UBSan by default; the ops object
now compiles with `-fno-sanitize=all` like the other freestanding objects.

Hybrid archives now leave `fork` and `pthread_atfork` to the host libc. The
Nelua raw-syscall fork and Nelibc atfork registry remain available in standalone
builds; the hybrid unistd objects localize those symbols so glibc and musl can
run their own internal fork handlers for allocator, stdio, and thread state.
`make lib-consumer-matrix` passed across Zig/glibc, GCC/glibc, Zig/musl, and
TinyCC/glibc, including the consumer's prepare/parent/child handler-order
checks. It also repeats 32 fork/exec cycles while a worker performs public
allocation and host-backed `tmpfile` I/O; every re-execed child checks fresh
allocation and stdio. It also runs four `system("exit 0")` calls while the
worker remains active. Three repeat runs per profile passed for fork/exec;
the expanded fork/exec/system consumer matrix passed across all four profiles.
The child uses
`execve` before touching libc state inherited from the multithreaded parent.
The API manifest marks both functions as host-delegated in hybrid mode.

The four hybrid syscall smoke profiles pass with Zig/glibc, GCC/glibc,
Zig/musl, and TinyCC/glibc. Hybrid spawn uses the host implementation and its
native attributes ABI. `make spawn-hybrid-smoke-matrix` also passes shared
PATH-search, open-action, working-directory, and synchronous setup-error cases
on those four hybrid profiles. The smoke avoids invalid-input validation
details that differ between host libcs. In the static musl profile, Nelibc
exports both `execvp` and `__execvpe`: musl's `posix_spawnp` resolves its
internal `__execvpe` call to Nelibc's PATH-search implementation, preserving
the shell fallback for executable text files without a shebang. This avoids
pulling musl's public `execvp` archive member and colliding with Nelibc's
replacement.
Standalone `system()` now registers its child-kill/reap, signal-restore, and
system-lock cleanup on Nelibc's pthread cleanup stack while waiting for the
shell. The standalone consumer cancels a thread blocked in `system("exec sleep 5")`,
verifies the child was reaped, and calls `system()` again to check the lock was
released. Zig, GCC, and TinyCC standalone consumers pass; the hybrid consumer
matrix also passes, retaining host pthread cleanup handlers.
The same consumer blocks `SIGUSR1` before `system()` and has the shell signal
itself; a normal exit verifies the child regained the caller's mask before
`exec`, and the test restores the parent mask afterward.
Standalone `POSIX_SPAWN_RESETIDS` is tested with distinct real and effective
UIDs inside a rootless user namespace. A separate SCHED_FIFO spawn check
verifies child policy/priority when allowed and verifies synchronous `EPERM`
reporting when the host denies real-time scheduling; the namespace variant is
included in `make spawn-smoke-standalone-matrix` and skips when user namespace
mapping is unavailable.
The standalone spawn smoke also launches children concurrently from four
Nelibc worker threads. Each worker creates its own open-file action list and
mixes direct `posix_spawn` with PATH-searching `posix_spawnp`. Five repeat runs
passed for each Zig, GCC, and TinyCC standalone profile; this is stress
coverage, not a complete audit of signal, cancellation, or fork interactions.
Standalone `posix_spawnp` now prepares PATH candidates in the parent without
an `access()` prefilter, then tries them with `execve` in the child. This
avoids an access/exec permission race; if an earlier candidate fails with a
search-continuable error such as `ENOENT` from a missing script interpreter,
the child tries later entries. The smoke places an executable with a missing
shebang interpreter first and a working script second; the Zig, GCC, and
TinyCC standalone matrix passes.
The same case checks error precedence: an earlier non-executable candidate
keeps the final `posix_spawnp` result at `EACCES` when a later executable
candidate fails with `ENOENT`.
The signal check queues a signal in the parent, verifies the child receives
only its requested mask/default action, and checks that the parent's pending
signal, mask, and handler remain unchanged. A deferred cancellation queued
before `posix_spawn` remains pending until the caller's explicit
`pthread_testcancel`; POSIX.1-2024 excludes `posix_spawn` from its cancellation
point list and prohibits adding cancellation points to other specified
functions ([cancellation-point rules](https://pubs.opengroup.org/onlinepubs/9799919799/functions/V2_chap02.html)).
This also holds on child setup/exec failure: spawn cleanup now reaps with a
raw `wait4` loop that retries `EINTR`, rather than entering Nelibc's
cancellation-aware `waitpid`. The smoke queues cancellation before a spawn
whose file action fails with `ENOENT`, verifies spawn returns that error, and
then confirms cancellation is delivered only at the worker's explicit
`pthread_testcancel`. The standalone Zig, GCC, and TinyCC matrix passes.
The smoke now blocks the child on a FIFO open, waits until its parent worker is
reading the spawn error pipe, and sends that thread `SIGUSR2` with restart
disabled. It runs both a successful spawn and a spawn whose following file
action fails with `ENOENT`. Releasing the FIFO forces the parent to handle
`EINTR` while reading the error pipe; the success case returns a child PID and
the failure case reports `ENOENT` after reaping the child. Both preserve the
caller's `errno`. The standalone Zig, GCC, and TinyCC matrix passed, followed
by five repeat runs per compiler and the optional user-namespace RESETIDS
check. This covers deterministic success and failure `EINTR` paths; it does not
replace a broader process/signal/fork interaction audit.
The standalone pthread smoke also registers no-op atfork handlers from a worker
while the initial thread performs 32 forks. Zig, GCC, and TinyCC smoke binaries
pass this concurrent registry/snapshot stress.
Standalone `fork()` now brackets user handlers with internal lock preparation:
it waits for stdio stream locks, pthread registry locks, then the allocator
lock. The parent releases them in reverse order and the child resets inherited
owners before user child handlers run. Standalone locale selection uses
per-thread state and has no process-wide locale-cache mutex; hybrid locale
cache locking remains under the host libc's fork handlers.

The pthread smoke holds the allocator lock or `stdout` lock in a worker while
the initial thread forks, then verifies the child can allocate and lock stdout.
Its registered child handler also allocates, try-locks stdout, and creates,
sets, reads, and deletes a pthread key. A worker concurrently registers
atfork handlers and creates/deletes keys during 32 forks. The standalone
pthread smoke and consumer pass with Zig, GCC, and TinyCC; the hybrid consumer
passes with Zig/glibc, GCC/glibc, Zig/musl, and TinyCC/glibc.
The standalone fork child also invalidates inherited joinable and detached
handles for vanished sibling threads: `pthread_join` and `pthread_cancel`
return `ESRCH`, while the parent retains its original joinable handle and can
join normally. The child tid-slot table is cleared along with per-thread
resources so stale sibling TIDs cannot be mistaken for live threads.
Forking from a Nelibc-created worker is also covered: the calling worker's
`pthread_self()` identity survives in the child, while another worker's
inherited handle is invalidated. The test passed under Zig, GCC, and TinyCC;
the Zig smoke also passed ten consecutive reruns.
The same worker-fork case sets a pthread-specific value before `fork()` and
checks it in the child, then executes a cleanup handler pushed before the
fork. A shared marker confirms the copied cleanup stack remains usable in the
child, while the parent continues without running that handler.
It also verifies that a disabled cancellation state is inherited by the child,
that the worker's thread-local `errno` value is copied to the child and left
unchanged in the parent, and that the parent restores its own cancellation
state after the fork. A blocked, thread-directed `SIGUSR1` is absent from the
child's pending set while the blocked mask survives; the parent retains and
consumes its pending signal. For robust mutexes,
the child retargets process-private robust locks held by the calling thread to
its new TID and rebuilds its kernel robust list. For PI locks, the hook resets
the child-private futex word and reacquires it with `FUTEX_LOCK_PI`, establishing
kernel ownership for the child TID; an unlock and reacquire are both tested.
Process-shared robust mutexes are excluded so the child does not rewrite the
parent's shared owner state. These cases pass in the Zig, GCC, and TinyCC
standalone pthread smoke; the Zig smoke also passed ten consecutive runs.

### Practical completeness estimate

These are engineering estimates for a Linux x86-64 general-purpose libc, not
symbol-count ratios or standards-conformance claims:

| Area | Estimated completeness | Main remaining work |
|---|---:|---|
| Core memory, strings, allocation, integer conversion, process/startup, and common I/O | 75–85% | Edge-case conformance, ABI review, and wider consumer coverage |
| Core time and basic signals/process APIs | 65–80% | Cross-libc differential coverage, locale names, and less common POSIX behavior |
| Math | 42–50% | Remaining C math entry points, less-common fenv environment edges, and quality/performance work |
| Standalone threading/TLS | 35–50% | Cancellation, synchronization breadth, and static-TLS ABI limits; dynamic TLS is deferred |
| Locale and international text | 15–30% | Locale datasets, Unicode case conversion, collation, and numeric/time conventions |
| Overall “core libc” for common Linux C programs | 65–75% | Math and threading gaps plus stronger compatibility evidence |

The core score gives extra weight to whether ordinary programs can build,
start, allocate, do I/O, handle strings/numbers, and use threads. Math and
threading are the largest capability gaps; locales and broader portability
matter more for completeness than for the initial common-program target.

### Standalone pthread gap audit

The generated API inventory currently records 115 pthread declarations, and
all 115 export from the Zig, GCC, and TinyCC standalone archives. The pthread
smoke passed with all three compilers; the Zig run passed 20 consecutive times.
The 2026-10-25 pthread matrix now also exercises static TLS initialization and
thread isolation: Nelua initialized and zero-filled TLS, plus 64-byte-aligned C
TLS, are read and mutated independently by the initial thread and a new thread.
It also confirms a worker's `errno` is isolated from the initial thread's
`errno`, using Nelibc's standalone TLS errno slot. The matrix passed with all
three compilers, followed by five repeat runs before the errno check and three
after it. This verifies symbol presence and the tested behavior, not full
POSIX conformance.
The pinned musl 1.2.5 public-symbol baseline
has 2 pthread entries without project declarations, both internal cleanup
helpers. The GNU concurrency-hint calls are now implemented as standalone
stateful hints; musl 1.2.5 instead accepts only zero and reports `EAGAIN` for
positive values, so hybrid builds intentionally retain host behavior. The
standalone implementation follows glibc's observable behavior, including
`EINVAL` for negative levels:

The Unix cancellation smoke covers blocked `poll`, `ppoll`, `select`, and
`pselect`, plus socket `send`, `sendmsg`, `recv`, `recvfrom`, and `recvmsg`, in
addition to blocking scalar and vectored (`readv`, `writev`) I/O and process
calls. Both `nanosleep` and `clock_nanosleep`, plus the Linux `epoll_wait`,
`epoll_pwait`, and `epoll_pwait2` extensions, are tested as well. These cases
run in the hybrid glibc, musl, and TinyCC-compiled profiles and the standalone
Zig, GCC, and TinyCC profiles; `make smoke-matrix` includes the standalone
group. `getitimer` and `setitimer` use raw syscalls because POSIX does not list
them as cancellation points; this avoids introducing cancellation there.
`fcntl(F_SETLKW)` enters the cancellation path, and the smoke verifies that a
blocked record-lock request can be canceled while another process holds the
lock.
`waitid` is implemented over Linux `waitid` syscall 247, exposed through
`sys/wait.h`, and delegated to glibc's cancellation-aware entry point in hybrid
glibc builds. Smoke coverage checks both `siginfo_t` child-exit fields and
cancellation of a blocked `P_PID` wait. `sigwait`, `sigwaitinfo`,
`sigtimedwait`, and `sigsuspend` now use cancellation-aware kernel signal waits;
the smoke consumes a queued `SIGUSR1` through `sigwait` and cancels each blocked
wait form across all seven profiles.
`readlink` and `readlinkat` are also cancellation points; a self-canceling
worker verifies that a pending deferred request is acted on at `readlink`
across all seven profiles, without depending on filesystem latency.
`msync` is implemented over Linux syscall 26 as a cancellation point; the
same deterministic pending-cancellation check covers it in all seven profiles.
`tcdrain` uses Linux `ioctl(TCSBRK, 1)`, matching glibc's implementation, and
the smoke checks `EBADF` propagation and pending cancellation.
The message-queue slice implements `mq_open`, `mq_close`, `mq_unlink`,
`mq_getattr`, `mq_setattr`, `mq_send`, `mq_receive`, `mq_timedsend`, and
`mq_timedreceive`, plus kernel-backed `mq_notify`; `mq_open`'s variadic
argument handling is a small C ABI adapter, while the operations use Nelua
Linux syscall wrappers. `SIGEV_THREAD` notification starts a detached callback
thread and services the Linux netlink notification. The smoke checks queue
attributes, send/receive bytes and priority, an expired receive timeout,
`SIGEV_NONE` registration/removal, `SIGEV_SIGNAL` delivery, a callback using
caller-supplied thread attributes, and cancellation of blocked send and receive
calls. The current run passes all seven profiles: Zig/glibc, GCC/glibc,
Zig/musl, TinyCC/glibc, and standalone Zig, GCC, and TinyCC. The TinyCC
compiler used for the shootout was version 0.9.28rc (`e23dabe`).
The checks verify that deferred cancellation wakes each blocked thread and
that `pthread_join` reports `PTHREAD_CANCELED`. This remains targeted behavior
coverage, not a complete cancellation-point audit.

| Priority | Missing APIs | Why they matter | Scope |
|---|---|---|---|
| Complete | `pthread_getconcurrency`, `pthread_setconcurrency` | Statefully stores the requested concurrency hint; it does not alter scheduling | GNU extension; hybrid mode delegates |

This is a baseline-derived priority list, not a complete POSIX inventory. The
POSIX.1-2024 `pthread_cond_clockwait` API is implemented in standalone mode;
it selects realtime or monotonic time per timed wait and shares the existing
condition-variable futex path. It is not in the pinned musl 1.2.5 baseline,
so hybrid musl continues to expose the host API set. A correct compatibility
implementation needs to select the clock inside musl's condition-wait path;
translating deadlines before calling `pthread_cond_timedwait` would not preserve
the requested clock if realtime changes while a wait is active.
POSIX.1-2024 `pthread_rwlock_clockrdlock` and `pthread_rwlock_clockwrlock` are
also implemented in standalone mode. They choose the futex clock per call and
preserve the existing realtime semantics of `pthread_rwlock_timed*lock`.
`pthread_mutex_clocklock` also selects realtime or monotonic deadlines inside
the mutex futex path for normal, robust, and priority-inheritance mutexes;
realtime PI timed locks retain the existing `FUTEX_LOCK_PI` path, while
monotonic PI waits use `FUTEX_LOCK_PI2`. The standalone smoke test checks
expired monotonic waits for normal, robust, PI, and combined robust+PI mutexes,
plus invalid clock and timespec inputs. All three standalone compiler profiles
passed on 2026-10-25; the Zig smoke passed 20 consecutive runs.
Standalone rwlocks use reader preference: new readers may acquire while writers
are queued by default. The GNU `pthread_rwlockattr_setkind_np` extension now
supports reader preference, the glibc-compatible ignored writer-preference
setting, and nonrecursive writer preference; the latter blocks new readers
while a writer is queued. The smoke verifies both writer-preference modes
against the default. This extension follows the behavior documented by the
[Linux pthread rwlock attribute manual](https://man7.org/linux/man-pages/man3/pthread_rwlockattr_setkind_np.3.html).
Process priority scheduling is now exposed: `_SC_PRIORITY_SCHEDULING` returns
200809, with Nelua wrappers for scheduler policy/parameter calls, policy
priority ranges, and the round-robin interval query. The standalone smoke
checks the wrappers and their error paths.

`_SC_THREAD_PRIORITY_SCHEDULING` now returns 200809. Per-priority atomic
reader and writer counts live in each rwlock; per-thread wait records let
`pthread_setschedparam` and `pthread_setschedprio` reprioritize queued waiters.
When a lock becomes available, a higher-priority blocked reader prevents a
lower-priority writer from overtaking it, while equal-priority writer/read
ties favor the writer. An aggregate real-time waiter count avoids scanning
priority buckets on ordinary lock operations. Shared rwlock state supports
process-shared locks without pointers to another process's thread context.
Timeout and asynchronous-cancellation paths remove reader and writer counts.
The real-time-gated smoke covers FIFO and RR priority changes, higher-priority
reader versus lower-priority writer admission, equal-priority reader/writer
precedence, process-shared writer ordering across a fork, and timeout and
cancellation cleanup. Zig and GCC passed 10 repeat runs each on Bak. The GNU
nonrecursive writer-preference attribute remains a separate policy.

Per-thread read ownership is tracked in standalone mode using four inline lock
slots plus dynamically allocated overflow entries. Recursive reads are
counted, and a thread that did not acquire a read lock gets `EPERM` when it
tries to unlock one. The Zig and GCC standalone pthread smoke profiles pass
this ownership test.
The standalone priority-ceiling attributes and mutex get/set operations are
implemented. `PTHREAD_PRIO_PROTECT` raises and restores scheduler priority for
held protected mutexes; on Linux, a `SCHED_OTHER` thread cannot acquire a
positive ceiling and receives `EINVAL`. Calls to `pthread_setschedparam` and
`pthread_setschedprio` while holding protected mutexes update the base priority
while preserving the active ceiling; `pthread_getschedparam` reports that base
priority. The smoke test checks nested protection locks: a higher ceiling may
be acquired while a lower ceiling is held, while a lower ceiling must be
rejected once a higher effective priority is active. It attempts this path when
the host permits `SCHED_FIFO` priority changes and skips it when the host denies
real-time scheduling. The protected-priority transition path passed on Fedora
and Bak with real-time scheduling permission. `pthread_tryjoin_np` is implemented in standalone mode;
it returns `EBUSY` while the target is live and reclaims resources after exit.
`pthread_timedjoin_np` accepts an absolute realtime deadline, returns
`ETIMEDOUT` without consuming the joinable thread, and succeeds when the thread
exits before a later deadline.
`pthread_getname_np` and `pthread_setname_np` support the calling thread and
other live threads through their Linux task names; names are limited to 15
bytes, and get-name buffers must hold at least 16 bytes.
`pthread_getaffinity_np` and `pthread_setaffinity_np` operate on live thread IDs
through Linux scheduler affinity syscalls; tests read and reapply the existing
mask for both a worker and the calling thread.
`pthread_getattr_np` reports the current thread's stack mapping or the recorded
usable stack, guard size, detach state, and scheduling attributes for Nelibc
threads. The initial thread's stack mapping is found through `/proc/self/maps`.
`pthread_getattr_default_np` returns the process defaults, and
`pthread_setattr_default_np` updates defaults used by later `pthread_attr_init`
calls and `pthread_create` calls with a null attributes pointer. The standalone
setter follows the Linux manual's replacement behavior; musl 1.2.5 instead
only raises its stack and guard defaults.
The `pthread_kill`, `pthread_getcpuclockid`, and `pthread_setschedprio` are
implemented in standalone mode and delegated to the host in hybrid mode.
POSIX `_Fork` is implemented in standalone mode: it resets Nelibc's internal
fork-sensitive locks without calling application `pthread_atfork` handlers.
Hybrid builds delegate `_Fork` to the host, and the consumer smoke checks that
registered handlers are skipped in both standalone and hybrid profiles.
Hybrid archives delegate `pthread_atfork` and `fork` to the selected libc so
its internal fork handlers still run. Nelibc keeps its own implementations
for standalone mode. Also audit against the current POSIX pthread index,
including APIs absent from the pinned musl export set.

- The latest available-profile inventory has 1,113 declared names. The three
  rebuilt hybrid archives (Zig/glibc, GCC/glibc, and Zig/musl) export 876
  functions each; the rebuilt standalone Zig and GCC archives export 1,115,
  including two implementation-only entries. TinyCC was unavailable for this
  run. The inventory classifies 228 APIs as host-delegated and 10
  declared-but-unexported in the Zig/musl archive.
  `pthread_mutex_clocklock` is provided by the glibc host in hybrid mode and
  exported by all three standalone archives. This is an inventory signal, not
  a completeness percentage. See `build/api-coverage.csv` after
  `make api-coverage`.
- The corrected musl 1.2.5 public-symbol comparison finds 1,471 declarations
  that are also exported by the pinned release archives: Nelibc exports 810
  in at least one tested hybrid profile, delegates 223 to a hybrid host, and does not
  yet declare 438. No declared API is missing from the tested hybrid archives.
  The largest undeclared groups are network database APIs (32), stdlib (30),
  and unistd (29). These
  are gap counts, not completion percentages; no API has yet been declared intentionally out
  of scope. See `docs/api-coverage.md` for the pinned source and regeneration
  command.
- `<inttypes.h>` now has Nelua implementations for all six public max-width
  helpers, plus glibc's four C23 parser aliases. Consumer checks pass under
  Zig/glibc, GCC/glibc, Zig/musl, TinyCC/glibc, and standalone Zig, GCC, and
  TinyCC; the C23 cases check `0b` parsing and the signed/unsigned limits.
- Standalone `fnmatch` now matches literals, `?`, `*` backtracking, bracket
  ranges, and all twelve POSIX named character classes by decoded character in
  C and UTF-8 locales. It also handles escaping, pathname separators, leading
  periods, leading-directory matching, and case folding. Zig, GCC, and TinyCC
  standalone smoke checks cover these cases. Stateful multibyte encodings
  remain incomplete; hybrid archives use the host multibyte decoder.
- Wide floating conversions `wcstof`, `wcstod`, and `wcstold` now use Nelibc's
  multibyte conversion and floating parser in hybrid and standalone profiles.
  Consumer coverage checks end-pointer mapping and no-conversion behavior.
- Standalone stdio now supports wide stream orientation, wide character/string
  input and output, unlocked variants, aliases, and one-character `ungetwc`
  pushback. UTF-8 stream smoke coverage passes on Zig, GCC, and TinyCC. Hybrid
  profiles continue to use the host stdio ABI and implementations.
- Standalone wide scanf functions now cover literals/whitespace, suppression,
  widths, `%n`, `%c`/`%s`/scansets, integer bases, decimal and hexadecimal
  floating input, and multibyte conversion. Empty `swscanf` input returns EOF
  when a conversion requires input. Zig, GCC, and TinyCC smoke checks pass;
  hybrid profiles delegate to their host libc. Positional arguments and
  extensions such as POSIX `%m` remain outside this tested slice.
- The standalone narrow scanf family parses C strings and byte streams with
  literals/whitespace, suppression, widths, `%n`, `%c`/`%s`/scansets, integer
  bases, decimal/hexadecimal floats, and POSIX allocation forms `%mc`, `%ms`,
  and `%m[`. `%lc`/`%ls` use multibyte decoding; `%l[` matches multibyte set
  members and ranges, and wide conversions restore original input bytes when
  they stop. Fully positional narrow and wide formats select pointer
  arguments from a copied `va_list`; mixing positional and sequential argument
  forms remains unspecified. Wide `%ms`, `%m[`, and `%mc` allocate multibyte
  results, while `%mls`, `%ml[`, and `%mlc` allocate wide-character results
  through Nelibc's allocator. Hybrid builds delegate the six narrow scanner APIs to their
  selected host libc.
- Standalone `swprintf`/`vswprintf` format wide literals and strings through
  Nelibc's multibyte and narrow-formatting paths. Integer/double, wide `%s` and
  `%c`, `%n`, and truncation cases pass; `%L` formats are explicitly rejected
  pending long-double support. Hybrid profiles delegate to their host libc.
- Standalone `fwprintf`, `vfwprintf`, `wprintf`, and `vwprintf` use the same
  locale-aware wide formatter and stream conversion state; `%n` is evaluated
  once with a wide-character count. Hybrid profiles continue to use host stdio.
- Standalone `open_wmemstream` owns a growable wide-character buffer, publishes
  its pointer and element count on flush/close, and supports seek/overwrite.
  Zig, GCC, and TinyCC smoke checks cover growth, publication, and ownership;
  hybrid profiles delegate to their host libc.
- `wcscasecmp_l` and `wcsncasecmp_l` now use the selected locale's wide case
  mapping in hybrid and standalone builds. Consumer cases cover C versus
  UTF-8 folding and bounded comparisons across all seven profiles.
- `wcsftime` and `wcsftime_l` now format through Nelibc's locale-aware
  `strftime` path and multibyte conversion routines. German UTF-8, C-locale,
  locale-restoration, and truncation cases pass across all seven profiles.
- GNU locale-specific `strto*_l` and `wcsto*_l` conversions now use the Nelua
  narrow and wide integer parsers, restoring the caller's prior thread locale.
  Their eight glibc C23 aliases are also exported. All seven consumer profiles
  check signed/unsigned limits, end pointers, `0b` parsing, and locale restore.
  The existing 1,209-case narrow integer differential passes on all four
  hybrid profiles.
- `strtof_l`, `strtod_l`, and `strtold_l` reuse the exact Nelua conversion
  path under the requested thread locale and restore the prior locale before
  returning. Consumer checks cover C and German decimal separators where the
  selected libc provides German locale data, plus Nelibc's standalone German
  locale on all three standalone compiler profiles.
- `make smoke-matrix` passed on 2026-10-25 across Zig/glibc, GCC/glibc,
  Zig/musl, TinyCC/glibc, and standalone Zig, GCC, and TinyCC. This runs the
  ABI, libc-differential, syscall, thread, spawn, and math smoke suites; the
  binary math comparison checks 116 functions against 100,000 generated
  inputs. The standalone timestamp smoke also checks that `lutimes` updates a
  symlink's timestamps without changing its target, using a snapshot taken
  immediately before the operation.
- `make dogfood-matrix` passed on 2026-10-25 for all four hybrid profiles.
  Each incremental C consumer ran and the gate confirmed that the executable
  contains selected Nelibc symbols. The larger Spinel dogfood results below
  remain separate evidence.
- Real-application dogfood passed on 2026-10-24: the Spinel C compiler was
  rebuilt with Zig cc and the glibc hybrid archive, then compiled and ran a
  Ruby client linked against that archive. The same client also ran as a static
  x86-64 musl executable linked against the Zig/musl hybrid archive. Both
  executables contain Nelibc's `memcpy`, `strlen`, and `strtol`. TinyCC also
  compiled the generated client, which Zig linked with Nelibc's TinyCC/glibc
  archive and TinyCC runtime. Reproduction steps are in `docs/quickstart.md`.
- Differential tests cover meaningful memory, string, integer, floating
  conversion, wide-string, tokenizer, collation, and syscall behavior across
  glibc, musl, GCC, Zig cc, and TinyCC profiles.
- `wcpcpy`, `wcpncpy`, and the GNU `wcswcs` alias are now implemented and
  declared. Their bounded-copy return values, terminator padding, and search
  result match the host in 256 wide-string differential cases per profile;
  consumer smoke tests also call all three in the four hybrid profiles and
  standalone Zig, GCC, and TinyCC builds.
- `wcscasecmp` and `wcsncasecmp` are implemented in Nelua and call `towlower`
  for locale-sensitive folding. Hybrid builds therefore follow glibc or musl;
  standalone supplies Unicode 16 simple `towlower` and `towupper` mappings for
  `C.UTF-8`, and ASCII mappings for `C`. ASCII comparison and bounded-prefix
  behavior pass the differential matrix and all seven consumer profiles;
  Unicode mapping smoke checks cover Greek, Cyrillic, Deseret, and polytonic
  Greek. The twelve standard `isw*` classifiers use generated Unicode letter,
  number, case, whitespace, and general-category data in `C.UTF-8`, with
  ASCII classifications in `C`. All 14 narrow byte classifier and
  case-conversion `_l` functions now export in every hybrid and standalone
  archive; they select and restore the thread locale. Their current byte-table
  results are the same for `C` and `C.UTF-8`, the two supported ctype modes.
  `wctype`/`iswctype`, all classifier `_l`
  forms, and `towupper_l`/`towlower_l` use locale handles. Standalone
  `newlocale` and `duplocale` return static handles for supported combinations
  of `C`/`C.UTF-8` ctype, `C`/`de_DE.UTF-8` numeric/monetary/time state;
  `freelocale` is a no-op for those handles. Standalone `uselocale` and locale
  handles now carry per-thread `LC_CTYPE`, `LC_NUMERIC`, `LC_MONETARY`,
  `LC_COLLATE`, and `LC_TIME` state. C and C.UTF-8 use code-point ordering;
  `de_DE.UTF-8` collation handles add a limited German ordering for ASCII,
  Latin-1, and precomposed Latin Extended-A accents, including `ä`/`ö`/`ü`
  and `ß`, with primary, accent, and case levels. Wide and narrow comparisons
  and transform keys share those weights. Generated Unicode 16.0 data covers
  934 nonzero-class combining marks with one or two canonical components,
  plus 58 CCC-zero source marks that decompose into two or three components.
  Combining marks sort by canonical combining class, preserving input order
  within each class. Consumer checks cover wide and narrow comparisons and
  transform keys for all 58, including mixed-class components. Full Unicode
  collation remains unsupported. The consumer also exercises all 55 Unicode
  16.0 combining classes across 1,485 pairwise reorderings.
  Global `setlocale` now selects German collation and preserves it in `LC_ALL`
  category composites. Hybrid profiles continue to use their host's wide
  collation. German time data covers localized weekday/month names and
  `%c`/`%x` formats. Global `setlocale` selects C or German `LC_TIME`,
  reports/accepts its supported `LC_ALL` composites, and `duplocale` snapshots
  the global time category. `strtod`, floating formatting, grouping, `strcoll`,
  `strxfrm`, `strftime`, `strptime`, and their `_l` forms use the selected
  thread's state; the `_l` forms restore the calling thread's prior locale.
  The `localeconv` result itself is stored per thread. Other
  time locales and formats remain incomplete. The standalone consumer matrix
  checks a worker switching C/German numeric, monetary, and time conventions
  while the main thread keeps its global locale, including parse/format
  roundtrips, locale composition, and global-locale snapshots; Zig, GCC, and
  TinyCC pass.
- `wcswidth` is implemented in Nelua and uses the selected host's `wcwidth` in
  hybrid mode. The standalone locale backend uses generated Unicode 16.0
  general-category, East Asian Width, and Default_Ignorable_Code_Point data
  for `C` and `C.UTF-8`; ambiguous characters have width one. Check the
  generated table with `make check-wcwidth-data`; regeneration requires Python
  with Unicode database version 16.0.0. `wcwidth` remains host-delegated in
  hybrid mode, where it follows the selected libc's locale data.
- Time APIs are already implemented across `src/unistd.nelua` and
  `src/stdlib.nelua`: clocks and sleeps, UTC/local conversion, `mktime`,
  `timegm`, `strftime`/`strptime` and their `_l` forms, `getdate`, and the
  `asctime`/`ctime` family. The syscall and consumer smoke checks UTC and
  negative epochs, leap days, POSIX TZ rules, TZif zone files, DST transitions,
  formatting bounds, process/thread CPU clocks, and `DATEMSK` parsing. Broader
  locale-specific time names and cross-libc differential coverage remain open.
- The current math slice in `src/math_core.nelua` exports 138 float and double
  functions plus x86-64 extended-precision `sqrtl`, `nanl`, `fabsl`, `copysignl`,
  `fmal`, `tgammal`, `lgammal`, `lgammal_r`, `erfl`, `erfcl`, `exp10l`, `pow10l`, `fmodl`, `remainderl`, `frexpl`, `modfl`, `hypotl`, `nextafterl`, `nexttowardl`, `atanl`,
  `atan2l`, `asinl`, `acosl`, `logl`, `log2l`, `log10l`, `log1pl`, `expl`,
  `exp2l`, `expm1l`, `sinl`, `cosl`, `sincosl`, `tanl`, `tanhl`, `sinhl`,
  `coshl`, `asinhl`, `acoshl`, `atanhl`, `powl`, `fminl`, `fmaxl`, `fdiml`,
  `cbrtl`, `remquol`, `ilogbl`, `logbl`, `ldexpl`, `scalbnl`, `scalblnl`,
  `truncl`, `floorl`, `ceill`, `rintl`, and
  `nearbyintl`, `roundl`, `lrintl`, `llrintl`, `lroundl`, and `llroundl`, plus
  binary32/64/80 internal classification and sign-bit functions, through all
  four hybrid profiles and standalone archives. The `nextafterl` edge checks
  now verify `FE_UNDERFLOW | FE_INEXACT` when stepping
  from zero to the least subnormal and `FE_OVERFLOW | FE_INEXACT` when stepping
  from the largest finite value to infinity. Crossing from the least normal to
  its subnormal predecessor raises underflow/inexact; stepping back to the
  least normal does not. The zero-to-subnormal path leaves `errno` unchanged;
  overflow `errno` differs between the tested glibc and musl hosts, so the
  differential test compares exception flags for that case.
  `fmal` also checks a halfway product at the subnormal boundary under all four
  rounding modes. The standalone check runs under Zig, GCC, and TinyCC.
  Complex-math
  coverage now includes `cabs*`, `creal*`, `cimag*`, `conj*`,
  `cproj*`, `carg*`, `csqrt*`, `cexp*`, `clog*`, `csin*`, `ccos*`, `csinh*`,
  `ccosh*`, `ctan*`, `ctanh*`, `catan*`, `catanh*`, `casin*`, `cacos*`,
  `casinh*`, `cacosh*`, and `cpow*`: a small C ABI shim extracts components and
  packages complex returns, while Nelua computes
  magnitudes, conjugates and projects values, evaluates arguments with
  `atan2*`, computes principal square roots with scaled intermediates, composes
  complex exponentials from the Nelua real `exp*`, `sin*`, and `cos*`, uses a
  scaled logarithmic modulus for complex logarithms, and composes complex
  circular and hyperbolic sine and cosine from the corresponding real functions.
  Complex tangent functions use scaled exponentials for large inputs. Inverse
  tangent uses scaled quadratic expressions, while inverse sine and cosine use
  scaled distances to their branch points. The inverse hyperbolic families reuse
  those kernels through principal-branch identities. Complex power composes
  Nelibc's complex logarithm and exponential kernels.
  All complex-math names in the pinned musl baseline now have declarations and
  exports; GNU extensions and broader behavioral conformance still need audit.
  Nelua functions implement `fmin`/`fmax` NaN behavior and rounding rules;
  x86-64 hardware instructions implement correctly rounded square root and
  binary remainder. `remquo`, `remquof`, and `remquol` reuse x87 `FPREM1` and return the signed low quotient bits with the remainder. `drem` is the GNU alias for `remainder`; `pow10` aliases `exp10`; `nan` constructors return quiet NaNs and `finite` uses bit-level classification. Nelua `asin` and `acos` use the stable endpoint product
  `(1-x)*(1+x)` and `atan2`; the shootout checks domain behavior and compares
  100,000 values in `[-1, 1]` within four ULPs on each profile. The Nelua
  `atanh` evaluates the endpoint region through `log1p` and preserves odd
  symmetry; the four-profile differential matrix checks 32 adjacent binary32
  and binary64 inputs approaching both poles. These checks found no result
  beyond eight ULPs. Bit-level Nelua implementations also provide `frexp` and
  `modf`, including subnormal decomposition and signed-zero behavior. x86-64
  `FSCALE` primitives implement `ldexp`/`scalbn`; overflow and zero results
  from underflow set `ERANGE`. Long-double `powl` preserves exact powers of two
  through the binary80 subnormal range, including fractional exponents whose
  product with the base exponent is integral. Other powers of two use the x87
  `exp2l` path so fractional results round correctly around the binary80
  subnormal/normal boundary under all four rounding modes. Nonzero subnormal
  results preserve `errno`; underflow exception flags are checked against glibc,
  while musl's known omission of `FE_UNDERFLOW` for some upward-rounded
  subnormals is recorded as a profile difference. Differential checks cover
  `powl(LDBL_MIN, 1)`, `powl(2, -16445)`, exact fractional cases, half-subnormal
  rounding, and values immediately around `LDBL_MIN`; standalone coverage runs
  under Zig, GCC, and TinyCC. Wide-exponent random differential cases also
  cover powers of arbitrary binary80 mantissas. Those checks exposed loss of
  accuracy for large binary exponents. Half-integer powers use a square-root
  decomposition; other noninteger exponents split the base into a small
  mantissa logarithm and compensated binary exponents before scaling; the
  mantissa-log product retains its FMA residual through the `exp2l` call.
  Double-double exponent construction temporarily uses round-to-nearest for its
  error-free transforms, then restores the caller's mode before final scaling.
  Nearest-mode calls above magnitude 576 and directed-mode calls above 256 use
  a double-double atanh-series logarithm to retain the low component through
  the exponent product. This
  path covers magnitudes through 560861783937657 in round-to-nearest and directed
  rounding modes; larger exponents still use `exp(y * log(x))` and need more
  accuracy work. The cap is `LONG_MAX / 16445`, keeping the largest binary80
  subnormal scale inside signed 64-bit `long`. Deterministic random comparisons cover arbitrary fractions
  through 560861783937657 on bases with binary exponents from -4 to 4 in round-to-nearest
  and directed modes; regression cases check all four modes,
  and wide-base cases are also checked in
  all four rounding modes. Musl's `powl` reference can diverge further as the
  fractional exponent grows, so the extended-range musl comparison allows up
  to 32768 ULP; glibc comparisons keep the tighter tolerance.
  It sets `EDOM` for negative square root and
  invalid remainder domains. Standalone x86-64 implements `feclearexcept`,
  `fegetexceptflag`, `feraiseexcept`, `fesetexceptflag`, `fetestexcept`,
  `fegetround`, `fesetround`, `fegetenv`, `feholdexcept`, `fesetenv`, and
  `feupdateenv` with x87/SSE state synchronization. Hybrid profiles retain the
  host fenv ABI and implementation. Standalone smoke tests verify that
  `feraiseexcept` sets only requested flags while preserving existing flags;
  glibc, musl, and TinyCC-host probes show the same results. The smoke tests
  also verify combined overflow/inexact and underflow/inexact requests, plus
  SIGFPE delivery for all five standard exceptions through x87-only and SSE-only
  paths, with only the selected exception unmasked in each unit. They verify
  `feupdateenv` merges newly raised flags into the restored environment,
  `feholdexcept` masks traps while clearing flags, and an invalid rounding mode
  leaves the active mode intact. `fesetexceptflag` restores each flag while
  traps are enabled without raising the trap. Subprocess checks verify
  `feupdateenv` re-raises each of the five accrued exceptions when restoring
  an all-traps-enabled environment. A standalone pthread smoke also verifies
  fenv isolation: a worker changes its rounding mode and raises `FE_INVALID`,
  while the joining thread retains its prior mode and clean flags. Zig, GCC,
  and TinyCC standalone profiles pass. `fesetenv` requires a valid
  environment saved by `fegetenv`/`feholdexcept` or a defined environment
  macro; malformed `fenv_t` bytes are outside its contract. Bit-level
  `ilogb`/`logb` cover normal/subnormal decomposition;
  `nextafter` advances binary32/binary64 encodings directly and handles signed
  zero and NaN values; `nextafter` and `nextafterf` explicitly raise
  underflow/inexact for zero-to-subnormal and normal-to-subnormal steps, and
  overflow/inexact when stepping from the largest finite value to infinity.
  These cases are compared with the host across the four math profiles.
  `nexttoward` compares its long-double direction before narrowing, including
  when the direction lies between adjacent float or double values. Signaling
  NaNs in either `nextafter*` argument raise `FE_INVALID` across the four hybrid
  compiler/libc profiles. Quiet-NaN and signed-zero flags are compared with each
  host because observed behavior differs by profile/compiler. Signed-zero
  equality and subnormal-to-zero exception cases are checked; broader
  zero/quiet-NaN coverage remains. Its
  Nelua `exp`/`exp2`/`pow` and `log`/`log2` are ports of musl 1.2.5's
  table-driven routines (`tools/gen_musl_tables.py` regenerates the tables);
  `log10`, `log1p`, `expm1`, `hypot` and the trigonometric, hyperbolic and
  inverse families follow musl's fdlibm-derived code, and the float variants
  widen to double. The differential run over edge values and 100,000 generated
  inputs reports a maximum observed error of 0 ULP for exp and log and 1 ULP
  for both float variants (nelibc-writ, gcc profile, 2026-11-07); the cross-libc matrix checks the same
  four-ULP bound on each profile. Range errno and overflow/underflow/pole/domain
  exception flags are also checked.
  `j0`/`j1`/`jn` and `y0`/`y1`/`yn` are ports of musl 1.2.5's fdlibm Bessel code; float APIs widen to double. Four-profile comparisons cover zero behavior, domain edges, roots, large arguments, and 100,000 generated inputs, gated at 2e-9 relative error for double and 2e-6 for float. `tgamma` follows musl's Lanczos code and `lgamma_r` musl's fdlibm code with reflection for negative nonintegers; `lgammal_r` and `tgammal` are musl's ld80 ports with every binary80 coefficient spelled as its bit pattern; `lgamma_r`/`lgammaf_r` return the gamma sign, and `lgamma`/`lgammaf` update `signgam`. Differential checks span edge cases and 100,000 generated inputs, with relative-error gates of 2e-13 for double gamma, 2e-12 for double log-gamma, and 2e-5 for float variants. The GNU `sincos` pair API shares argument reduction and evaluates both kernels once; `sincosf` widens to double. The Bessel four-profile differential matrix covers order sign, negative inputs, zero/pole behavior, transition regions, large arguments, and generated inputs. `fma` uses a portable 128-bit integer-product fallback to preserve fused rounding; `fmaf` uses a double-precision product/sum with a halfway correction. Exact-bit differential checks cover edge cases and 100,000 generated triples across compiler/libc profiles. `cbrt` reduces the binary exponent modulo three, seeds from the Nelua
  exponential/logarithm cores, then applies Newton refinement. Across the
  current edge set and 100,000 generated inputs per profile, observed error is
  at most 4 ULP for binary64 and 0 ULP for binary32; this is differential
  coverage, not a proof of correct rounding.
  `exp2` splits the input into an integer binary scale and a fractional
  remainder, evaluates the latter with a degree-20 series and split ln(2), and
  restores scale with `ldexp`; it passes the same four-profile 4-ULP
  differential gate over edge values and 100,000 generated inputs.
  `log2` extracts the binary exponent and evaluates the normalized mantissa
  with an atanh series; exact powers of two return their integer exponent.
  Differential checks compare normal inputs within four ULP. For binary64
  subnormal inputs, the harness also checks a finite in-range result because
  Zig's bundled compiler math returns inaccurate reference values there;
  GCC/glibc comparisons cover those inputs directly. The same bundled Zig
  reference issue affects `log10` subnormals; the harness checks result range
  there and uses full ULP comparisons with GCC/glibc. Targeted `log10` edges
  cover zero, true-min and min-normal inputs, powers of ten and their adjacent
  representable values, large magnitudes, and `DBL_MAX`; zero and negative
  inputs also check `ERANGE` and `EDOM`.
  `log1p` uses a compensated `log(1+x)` path for larger inputs and an atanh
  series for small values; `expm1` uses a Taylor series around zero and the
  exponential core for larger magnitudes. Float variants widen to binary64
  and narrow. Differential checks cover domain edges and generated values
  within four ULP. `log10` uses the natural-log core and log10(e). The GNU
  `exp10` extension splits its input into an integer decimal scale and a
  fractional remainder, then uses powers-of-ten constants and the exponential
  core; observed differential error stays within eight ULP across the matrix.
  `hypot`/`hypotf` scale by the larger input before squaring, prioritize infinity
  over NaN, and avoid underflow from insignificant operand ratios. Pairwise
  differential checks cover edge values and generated inputs.
  The shared `sin`/`cos` reducer multiplies the full significand by 1,200 fixed
  bits of 2/pi, then reconstructs a two-part remainder with split pi/2. Kernel
  polynomials and full-range argument reduction stay within 1 ULP on the tested
  edge values and 100,000 generated inputs for each profile.
  `rint`/`rintf` observe the current SSE rounding mode and report inexact;
  `nearbyint`/`nearbyintf` suppress only inexact while retaining prior flags.
  The differential harness checks those APIs under all four standard rounding
  modes, including half-way values, subnormals, infinities, signed zero, and
  retained exception flags. `lrint`/`lrintf` and `llrint`/`llrintf` use SSE conversions that honor MXCSR rounding and report inexact; `lround`/`lroundf` and their long-long forms round halfway cases away from zero without raising inexact. Their matrix checks all four modes, integer results, exception behavior, and ties. Signaling-NaN `FE_INVALID` reporting varies among
  host libcs, so cross-libc comparisons require a NaN result but permit that
  one flag to differ. The broader core harness also checks signed zero, subnormals, half-way rounding,
  infinities, quiet NaNs, and largest finite values, plus 100,000 generated
  scalar inputs and input pairs per profile against host libm. Signaling-NaN
  operations are exercised, with min/max result comparison relaxed where host
  runtimes differ. The declared long-double math entry points are implemented;
  their broader edge and accuracy coverage plus less-common fenv trap
  environment cases remain open. `sinh`/`cosh`/`tanh` and their float forms use small-input series,
  range-safe exponential formulas, signed-zero and infinity handling, and
  overflow `ERANGE`; differential checks cover the near-overflow transition.
  `atan` uses fdlibm range reduction and its polynomial kernel; `atan2` handles
  signed zero and infinite quadrants before using bounded ratios. Their float
  variants widen to binary64, compute, and narrow. Differential checks cover
  edge values and generated inputs within four ULP.
  `pow` handles zero, infinite, NaN, negative-base integer parity, domain,
  overflow, and underflow cases explicitly. Integer exponents through magnitude
  64 use exponentiation by squaring; the general path evaluates log and exp in
  x86 extended precision before rounding to binary64. Its current differential
  sample reports a maximum of 1 ULP for both float and double over edge and
  100,000 generated input pairs on the four hybrid profiles.
  `asinh` preserves tiny inputs and uses a stable `log1p` form for moderate
  magnitudes plus a large-input logarithmic form;
  `acosh` handles its domain and large arguments explicitly; `atanh` uses a
  small-input series and reports its domain and pole errors. Their float forms
  widen to binary64 then narrow. Differential tests include edge and 100,000
  generated inputs per profile with an eight-ULP acceptance bound; this is
  validation evidence, not a correctly-rounded guarantee.
- Standalone static `-nostdlib` smoke paths exist for Zig, GCC, and TinyCC,
  including startup, TLS fixtures, allocation, stdio, and a pthread subset.
- Standalone pthread now supports deferred and asynchronous cancellation
  requests, cancellation state enable/disable, `pthread_setcanceltype`,
  `pthread_testcancel`, cleanup-handler push/pop for
  created threads, and cancellation of a thread blocked in `pthread_cond_wait`
  or `pthread_cond_timedwait`. Async cancellation during a condition wait is
  deferred until after the mutex is reacquired, so cleanup handlers run with
  the required mutex ownership. Condition variables select realtime or monotonic
  clocks through their attributes. Cancellation smoke covers `pthread_cond_wait`,
  realtime `pthread_cond_timedwait`, and monotonic `pthread_cond_clockwait`; it
  synchronizes on the waiter's mutex handoff and checks cleanup runs with the
  mutex reacquired and the condition wait count cleared. Mutexes support
  absolute realtime timed locks, priority-inheritance futexes, and robust
  owner-death recovery through Linux robust lists. The smoke covers robust PI
  recovery both with and without a blocked waiter, PI timed-lock deadlines, and
  deferred cancellation while a PI waiter is blocked. Forked processes refresh
  their robust-list registration; process-shared robust recovery is
  exercised by a child that exits while holding the mutex. Spin locks, barriers,
  and read-write locks support process sharing. Reusable barriers use futex
  generations; async cancellation is deferred until the current generation
  completes, preventing a canceled arrival from stranding peers. Smoke coverage
  cancels a queued async waiter, completes the generation, then checks join and
  barrier destruction. Read-write locks support recursive readers,
  process sharing, try-locks, and absolute realtime timed locks; the reader-
  preference policy can starve writers under a continuous reader stream. It
  also interrupts blocking calls routed through the cancellable syscall
  wrappers, including read/write, socket I/O (`connect`, `accept`, `recv`,
  `send`), poll/select, waits, sleeps, `pause`, openat, `close`, and fsync. The
  close case fills a loopback TCP send queue, blocks close with `SO_LINGER`,
  requests cancellation while the thread is in the close syscall, then checks
  cancellation after close returns and verifies that the descriptor is closed.
  The smoke checks `/proc` for blocking workers' active syscalls before
  cancellation when procfs allows it. The small-file `fsync` case retains a
  timed wait because it usually completes immediately. `tcdrain` currently
  checks pending cancellation on entry and `EBADF`; the available PTY driver
  drains immediately, so blocked-`tcdrain` cancellation is not covered yet.
  Condition-wait cancellation reacquires the mutex, then unwinds cleanup
  handlers before thread-specific data destructors. Semaphore wait retries
  check for deferred cancellation after waiter registration races; without
  that check, a cancellation wake could repeatedly change the sequence and
  spin instead of exiting. The
  semaphore smoke cancels a registered waiter, including immediately after
  waiter registration, and verifies the waiter count returns to zero and the
  semaphore remains destroyable. It also checks cancellation cleanup with a
  TSD value and verifies handler-before-destructor order. In deferred mode,
  ordinary CPU-bound code
  must call `pthread_testcancel`. Key deletion invalidates the generation, so
  another
  thread's stored value receives no destructor after deletion even when the
  key slot is reused; the smoke verifies this behavior. A separate TSD test
  re-registers its value on every destructor call and confirms exactly the
  four `PTHREAD_DESTRUCTOR_ITERATIONS` passes run.
  Signal 32 is reserved internally and cannot be installed or blocked by
  applications. Asynchronous cancellation requires application code to stay
  within async-cancel-safe operations. The initial thread has its own pthread
  context; cancellation state, cleanup handlers, `pthread_exit`, and thread-
  specific destructors use the same path as created threads. Once exit begins,
  cancellation is disabled through cleanup handlers and TSD destructors, so a
  cancellation point inside a destructor cannot recursively restart thread
  exit. `pthread-exit-standalone-matrix` covers a canceled request during a
  blocked TSD destructor and checks the original thread result and one destructor
  call under Zig, GCC, and TinyCC. The pthread smoke exits a worker with 49
  nested cleanup frames and checks LIFO handler order. Cleanup handlers use
  caller-stack frames, so nesting is limited by the thread stack rather than a
  fixed runtime array.
  Internal allocator critical sections,
  the pthread-key and default-attribute locks, robust-list slot allocation,
  priority-protection bookkeeping, and the named-semaphore registry defer
  asynchronous cancellation until after releasing their locks, then retrigger
  a pending request. The standalone pthread smoke holds this deferral region
  across an async-cancel request while repeatedly exercising small allocation,
  direct mappings, `mremap`-backed `realloc`, and pthread-attribute operations,
  then verifies cleanup runs after release. It also cancels an async thread
  after confirming it is queued on a mutex futex, then checks that the owner can
  unlock and reuse the mutex. A separate async test cancels a waiter queued on
  a priority-inheritance futex while the owner still holds the mutex, then
  verifies unlock and reacquisition. The robust PI variant also verifies the
  surviving owner does not receive `EOWNERDEAD` after canceling its waiter.
  Robust non-PI waiters also have queued-cancel, owner-unlock, and mutex-reuse
  smoke coverage.
  Async-canceled rwlock writers leave `waiting_writers` clear and the lock
  usable. If an async-canceled thread exits inside a `pthread_once` initializer,
  cleanup resets the once control so a later caller can retry; a full cleanup
  stack defers cancellation until the initializer completes. Smoke coverage
  exercises cancellation, retry, and exactly-once completion. These checks run
  on Zig, GCC, and TinyCC. Blocking `pthread_join` and `pthread_timedjoin_np`
  check deferred cancellation while polling for target exit; cancellation
  releases the join claim. Smoke coverage cancels both forms while waiting,
  then confirms another caller can still join each target.
- Standalone pthread attributes support configurable stack sizes, page-
  protected guard regions, and scheduler inheritance/policy/priority. Explicit
  scheduling is applied before a startup gate releases the worker; permission
  failures are returned from `pthread_create` without running the routine.
  `pthread_attr_getguardsize` reports the requested byte size, while stack
  mappings round the guard region up to whole pages. `pthread_getschedparam` and
  `pthread_setschedparam` query and change live Linux thread scheduling.
- Standalone unnamed POSIX semaphores now provide `sem_init`, `sem_destroy`,
  `sem_wait`, `sem_timedwait`, `sem_trywait`, `sem_post`, and `sem_getvalue`.
  They use Nelua-owned futex waits. Async cancellation is deferred until the
  waiter count and cancellation wake address are cleared; smoke coverage checks
  that a canceled waiter leaves the semaphore destroyable.
- Standalone named POSIX semaphores provide `sem_open`, `sem_close`, and
  `sem_unlink` through shared `/dev/shm` mappings and a small C varargs ABI
  bridge; initialization, mapping, wait, and lifetime tracking are Nelua-owned.
  The smoke covers eight concurrent creators, cross-process opens/posts, and
  unlinking while mappings remain open; 20 repeated Zig runs passed.
- Semaphore edge cases now follow POSIX immediate-acquisition rules for
  `sem_timedwait`, accept any nonzero `pshared`, and ignore `sem_open`'s mode
  and initial value when opening an existing name. `sem_clockwait` supports
  `CLOCK_REALTIME` and `CLOCK_MONOTONIC` using absolute futex deadlines.
  Hybrid glibc builds fast-path immediate acquisition before delegating blocked
  waits to glibc, preserving the POSIX invalid-deadline rule. Hybrid musl builds
  provide the API through musl's public semaphore calls; monotonic waits poll at
  1 ms intervals to avoid depending on musl's private `sem_t` layout. The musl
  smoke verifies expiration, wakeup, and cancellation while blocked.
- Hybrid stdio adapts to host `FILE` implementations in several profiles. The
  standalone `FILE` implementation is Nelua-owned, but full standards and
  edge-case coverage remains a separate conformance task.
- Standalone startup reads the executable's `PT_TLS` image and initializes
  static TLS. New pthreads receive a private copy of that static image. This
  supports the local-exec TLS model used by current fixtures; it is runtime
  support in assembly/Nelua, not a Nelua compiler TLS implementation. Dynamic
  TLS modules and a DTV are not implemented, and are deferred until a target
  application needs them. Standalone pthread supports deferred cooperative
  cancellation at explicit cancellation points and condition waits, with
  cleanup handlers on created threads. Asynchronous cancellation and full
  POSIX synchronization coverage remain incomplete.
- The raw syscall and process-startup implementation targets Linux x86-64.

## Completion rule

Do not use a symbol count as a completion score. For each API, record whether
Nelibc implements it, intentionally delegates it, or has not implemented it;
then attach behavior tests, ABI checks, and the compiler/libc profiles that
passed. A family is ready to replace only when its tests run without relying
on the host implementation for the behavior under test.

The wide-character memory, string, collation, and transform entry points use
thin C ABI adapters with standard `const wchar_t *` prototypes; their
implementations remain in Nelua. Repeated Nelua `--cflags` options in
the Makefile are combined because the compiler accepts one flag string. The
musl target is passed as `-target x86_64-linux-musl` so it reaches Zig cc
correctly. `make lib-consumer-matrix` passes wide-string consumers on Zig/glibc,
GCC/glibc, Zig/musl, and TinyCC/glibc; `make lib-consumer-standalone-matrix`
passes the standalone Zig, GCC, and TinyCC profiles.
