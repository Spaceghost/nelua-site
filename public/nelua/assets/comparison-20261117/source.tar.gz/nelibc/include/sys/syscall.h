#ifndef NELIBC_SYS_SYSCALL_WRAPPER_H
#define NELIBC_SYS_SYSCALL_WRAPPER_H

/* Hybrid builds use the host's <sys/syscall.h>. In the standalone profile
 * SYS_name is the kernel's __NR_name from <asm/unistd.h> (the compiler's
 * Linux UAPI headers), for each of the 362 x86-64 system calls listed in
 * linux-libc-dev 6.1 (Debian 12); a name the installed UAPI headers lack is
 * left undefined. */
#ifdef NELIBC_STANDALONE

#include <asm/unistd.h>

#ifdef __NR_read
#define SYS_read __NR_read
#endif
#ifdef __NR_write
#define SYS_write __NR_write
#endif
#ifdef __NR_open
#define SYS_open __NR_open
#endif
#ifdef __NR_close
#define SYS_close __NR_close
#endif
#ifdef __NR_stat
#define SYS_stat __NR_stat
#endif
#ifdef __NR_fstat
#define SYS_fstat __NR_fstat
#endif
#ifdef __NR_lstat
#define SYS_lstat __NR_lstat
#endif
#ifdef __NR_poll
#define SYS_poll __NR_poll
#endif
#ifdef __NR_lseek
#define SYS_lseek __NR_lseek
#endif
#ifdef __NR_mmap
#define SYS_mmap __NR_mmap
#endif
#ifdef __NR_mprotect
#define SYS_mprotect __NR_mprotect
#endif
#ifdef __NR_munmap
#define SYS_munmap __NR_munmap
#endif
#ifdef __NR_brk
#define SYS_brk __NR_brk
#endif
#ifdef __NR_rt_sigaction
#define SYS_rt_sigaction __NR_rt_sigaction
#endif
#ifdef __NR_rt_sigprocmask
#define SYS_rt_sigprocmask __NR_rt_sigprocmask
#endif
#ifdef __NR_rt_sigreturn
#define SYS_rt_sigreturn __NR_rt_sigreturn
#endif
#ifdef __NR_ioctl
#define SYS_ioctl __NR_ioctl
#endif
#ifdef __NR_pread64
#define SYS_pread64 __NR_pread64
#endif
#ifdef __NR_pwrite64
#define SYS_pwrite64 __NR_pwrite64
#endif
#ifdef __NR_readv
#define SYS_readv __NR_readv
#endif
#ifdef __NR_writev
#define SYS_writev __NR_writev
#endif
#ifdef __NR_access
#define SYS_access __NR_access
#endif
#ifdef __NR_pipe
#define SYS_pipe __NR_pipe
#endif
#ifdef __NR_select
#define SYS_select __NR_select
#endif
#ifdef __NR_sched_yield
#define SYS_sched_yield __NR_sched_yield
#endif
#ifdef __NR_mremap
#define SYS_mremap __NR_mremap
#endif
#ifdef __NR_msync
#define SYS_msync __NR_msync
#endif
#ifdef __NR_mincore
#define SYS_mincore __NR_mincore
#endif
#ifdef __NR_madvise
#define SYS_madvise __NR_madvise
#endif
#ifdef __NR_shmget
#define SYS_shmget __NR_shmget
#endif
#ifdef __NR_shmat
#define SYS_shmat __NR_shmat
#endif
#ifdef __NR_shmctl
#define SYS_shmctl __NR_shmctl
#endif
#ifdef __NR_dup
#define SYS_dup __NR_dup
#endif
#ifdef __NR_dup2
#define SYS_dup2 __NR_dup2
#endif
#ifdef __NR_pause
#define SYS_pause __NR_pause
#endif
#ifdef __NR_nanosleep
#define SYS_nanosleep __NR_nanosleep
#endif
#ifdef __NR_getitimer
#define SYS_getitimer __NR_getitimer
#endif
#ifdef __NR_alarm
#define SYS_alarm __NR_alarm
#endif
#ifdef __NR_setitimer
#define SYS_setitimer __NR_setitimer
#endif
#ifdef __NR_getpid
#define SYS_getpid __NR_getpid
#endif
#ifdef __NR_sendfile
#define SYS_sendfile __NR_sendfile
#endif
#ifdef __NR_socket
#define SYS_socket __NR_socket
#endif
#ifdef __NR_connect
#define SYS_connect __NR_connect
#endif
#ifdef __NR_accept
#define SYS_accept __NR_accept
#endif
#ifdef __NR_sendto
#define SYS_sendto __NR_sendto
#endif
#ifdef __NR_recvfrom
#define SYS_recvfrom __NR_recvfrom
#endif
#ifdef __NR_sendmsg
#define SYS_sendmsg __NR_sendmsg
#endif
#ifdef __NR_recvmsg
#define SYS_recvmsg __NR_recvmsg
#endif
#ifdef __NR_shutdown
#define SYS_shutdown __NR_shutdown
#endif
#ifdef __NR_bind
#define SYS_bind __NR_bind
#endif
#ifdef __NR_listen
#define SYS_listen __NR_listen
#endif
#ifdef __NR_getsockname
#define SYS_getsockname __NR_getsockname
#endif
#ifdef __NR_getpeername
#define SYS_getpeername __NR_getpeername
#endif
#ifdef __NR_socketpair
#define SYS_socketpair __NR_socketpair
#endif
#ifdef __NR_setsockopt
#define SYS_setsockopt __NR_setsockopt
#endif
#ifdef __NR_getsockopt
#define SYS_getsockopt __NR_getsockopt
#endif
#ifdef __NR_clone
#define SYS_clone __NR_clone
#endif
#ifdef __NR_fork
#define SYS_fork __NR_fork
#endif
#ifdef __NR_vfork
#define SYS_vfork __NR_vfork
#endif
#ifdef __NR_execve
#define SYS_execve __NR_execve
#endif
#ifdef __NR_exit
#define SYS_exit __NR_exit
#endif
#ifdef __NR_wait4
#define SYS_wait4 __NR_wait4
#endif
#ifdef __NR_kill
#define SYS_kill __NR_kill
#endif
#ifdef __NR_uname
#define SYS_uname __NR_uname
#endif
#ifdef __NR_semget
#define SYS_semget __NR_semget
#endif
#ifdef __NR_semop
#define SYS_semop __NR_semop
#endif
#ifdef __NR_semctl
#define SYS_semctl __NR_semctl
#endif
#ifdef __NR_shmdt
#define SYS_shmdt __NR_shmdt
#endif
#ifdef __NR_msgget
#define SYS_msgget __NR_msgget
#endif
#ifdef __NR_msgsnd
#define SYS_msgsnd __NR_msgsnd
#endif
#ifdef __NR_msgrcv
#define SYS_msgrcv __NR_msgrcv
#endif
#ifdef __NR_msgctl
#define SYS_msgctl __NR_msgctl
#endif
#ifdef __NR_fcntl
#define SYS_fcntl __NR_fcntl
#endif
#ifdef __NR_flock
#define SYS_flock __NR_flock
#endif
#ifdef __NR_fsync
#define SYS_fsync __NR_fsync
#endif
#ifdef __NR_fdatasync
#define SYS_fdatasync __NR_fdatasync
#endif
#ifdef __NR_truncate
#define SYS_truncate __NR_truncate
#endif
#ifdef __NR_ftruncate
#define SYS_ftruncate __NR_ftruncate
#endif
#ifdef __NR_getdents
#define SYS_getdents __NR_getdents
#endif
#ifdef __NR_getcwd
#define SYS_getcwd __NR_getcwd
#endif
#ifdef __NR_chdir
#define SYS_chdir __NR_chdir
#endif
#ifdef __NR_fchdir
#define SYS_fchdir __NR_fchdir
#endif
#ifdef __NR_rename
#define SYS_rename __NR_rename
#endif
#ifdef __NR_mkdir
#define SYS_mkdir __NR_mkdir
#endif
#ifdef __NR_rmdir
#define SYS_rmdir __NR_rmdir
#endif
#ifdef __NR_creat
#define SYS_creat __NR_creat
#endif
#ifdef __NR_link
#define SYS_link __NR_link
#endif
#ifdef __NR_unlink
#define SYS_unlink __NR_unlink
#endif
#ifdef __NR_symlink
#define SYS_symlink __NR_symlink
#endif
#ifdef __NR_readlink
#define SYS_readlink __NR_readlink
#endif
#ifdef __NR_chmod
#define SYS_chmod __NR_chmod
#endif
#ifdef __NR_fchmod
#define SYS_fchmod __NR_fchmod
#endif
#ifdef __NR_chown
#define SYS_chown __NR_chown
#endif
#ifdef __NR_fchown
#define SYS_fchown __NR_fchown
#endif
#ifdef __NR_lchown
#define SYS_lchown __NR_lchown
#endif
#ifdef __NR_umask
#define SYS_umask __NR_umask
#endif
#ifdef __NR_gettimeofday
#define SYS_gettimeofday __NR_gettimeofday
#endif
#ifdef __NR_getrlimit
#define SYS_getrlimit __NR_getrlimit
#endif
#ifdef __NR_getrusage
#define SYS_getrusage __NR_getrusage
#endif
#ifdef __NR_sysinfo
#define SYS_sysinfo __NR_sysinfo
#endif
#ifdef __NR_times
#define SYS_times __NR_times
#endif
#ifdef __NR_ptrace
#define SYS_ptrace __NR_ptrace
#endif
#ifdef __NR_getuid
#define SYS_getuid __NR_getuid
#endif
#ifdef __NR_syslog
#define SYS_syslog __NR_syslog
#endif
#ifdef __NR_getgid
#define SYS_getgid __NR_getgid
#endif
#ifdef __NR_setuid
#define SYS_setuid __NR_setuid
#endif
#ifdef __NR_setgid
#define SYS_setgid __NR_setgid
#endif
#ifdef __NR_geteuid
#define SYS_geteuid __NR_geteuid
#endif
#ifdef __NR_getegid
#define SYS_getegid __NR_getegid
#endif
#ifdef __NR_setpgid
#define SYS_setpgid __NR_setpgid
#endif
#ifdef __NR_getppid
#define SYS_getppid __NR_getppid
#endif
#ifdef __NR_getpgrp
#define SYS_getpgrp __NR_getpgrp
#endif
#ifdef __NR_setsid
#define SYS_setsid __NR_setsid
#endif
#ifdef __NR_setreuid
#define SYS_setreuid __NR_setreuid
#endif
#ifdef __NR_setregid
#define SYS_setregid __NR_setregid
#endif
#ifdef __NR_getgroups
#define SYS_getgroups __NR_getgroups
#endif
#ifdef __NR_setgroups
#define SYS_setgroups __NR_setgroups
#endif
#ifdef __NR_setresuid
#define SYS_setresuid __NR_setresuid
#endif
#ifdef __NR_getresuid
#define SYS_getresuid __NR_getresuid
#endif
#ifdef __NR_setresgid
#define SYS_setresgid __NR_setresgid
#endif
#ifdef __NR_getresgid
#define SYS_getresgid __NR_getresgid
#endif
#ifdef __NR_getpgid
#define SYS_getpgid __NR_getpgid
#endif
#ifdef __NR_setfsuid
#define SYS_setfsuid __NR_setfsuid
#endif
#ifdef __NR_setfsgid
#define SYS_setfsgid __NR_setfsgid
#endif
#ifdef __NR_getsid
#define SYS_getsid __NR_getsid
#endif
#ifdef __NR_capget
#define SYS_capget __NR_capget
#endif
#ifdef __NR_capset
#define SYS_capset __NR_capset
#endif
#ifdef __NR_rt_sigpending
#define SYS_rt_sigpending __NR_rt_sigpending
#endif
#ifdef __NR_rt_sigtimedwait
#define SYS_rt_sigtimedwait __NR_rt_sigtimedwait
#endif
#ifdef __NR_rt_sigqueueinfo
#define SYS_rt_sigqueueinfo __NR_rt_sigqueueinfo
#endif
#ifdef __NR_rt_sigsuspend
#define SYS_rt_sigsuspend __NR_rt_sigsuspend
#endif
#ifdef __NR_sigaltstack
#define SYS_sigaltstack __NR_sigaltstack
#endif
#ifdef __NR_utime
#define SYS_utime __NR_utime
#endif
#ifdef __NR_mknod
#define SYS_mknod __NR_mknod
#endif
#ifdef __NR_uselib
#define SYS_uselib __NR_uselib
#endif
#ifdef __NR_personality
#define SYS_personality __NR_personality
#endif
#ifdef __NR_ustat
#define SYS_ustat __NR_ustat
#endif
#ifdef __NR_statfs
#define SYS_statfs __NR_statfs
#endif
#ifdef __NR_fstatfs
#define SYS_fstatfs __NR_fstatfs
#endif
#ifdef __NR_sysfs
#define SYS_sysfs __NR_sysfs
#endif
#ifdef __NR_getpriority
#define SYS_getpriority __NR_getpriority
#endif
#ifdef __NR_setpriority
#define SYS_setpriority __NR_setpriority
#endif
#ifdef __NR_sched_setparam
#define SYS_sched_setparam __NR_sched_setparam
#endif
#ifdef __NR_sched_getparam
#define SYS_sched_getparam __NR_sched_getparam
#endif
#ifdef __NR_sched_setscheduler
#define SYS_sched_setscheduler __NR_sched_setscheduler
#endif
#ifdef __NR_sched_getscheduler
#define SYS_sched_getscheduler __NR_sched_getscheduler
#endif
#ifdef __NR_sched_get_priority_max
#define SYS_sched_get_priority_max __NR_sched_get_priority_max
#endif
#ifdef __NR_sched_get_priority_min
#define SYS_sched_get_priority_min __NR_sched_get_priority_min
#endif
#ifdef __NR_sched_rr_get_interval
#define SYS_sched_rr_get_interval __NR_sched_rr_get_interval
#endif
#ifdef __NR_mlock
#define SYS_mlock __NR_mlock
#endif
#ifdef __NR_munlock
#define SYS_munlock __NR_munlock
#endif
#ifdef __NR_mlockall
#define SYS_mlockall __NR_mlockall
#endif
#ifdef __NR_munlockall
#define SYS_munlockall __NR_munlockall
#endif
#ifdef __NR_vhangup
#define SYS_vhangup __NR_vhangup
#endif
#ifdef __NR_modify_ldt
#define SYS_modify_ldt __NR_modify_ldt
#endif
#ifdef __NR_pivot_root
#define SYS_pivot_root __NR_pivot_root
#endif
#ifdef __NR__sysctl
#define SYS__sysctl __NR__sysctl
#endif
#ifdef __NR_prctl
#define SYS_prctl __NR_prctl
#endif
#ifdef __NR_arch_prctl
#define SYS_arch_prctl __NR_arch_prctl
#endif
#ifdef __NR_adjtimex
#define SYS_adjtimex __NR_adjtimex
#endif
#ifdef __NR_setrlimit
#define SYS_setrlimit __NR_setrlimit
#endif
#ifdef __NR_chroot
#define SYS_chroot __NR_chroot
#endif
#ifdef __NR_sync
#define SYS_sync __NR_sync
#endif
#ifdef __NR_acct
#define SYS_acct __NR_acct
#endif
#ifdef __NR_settimeofday
#define SYS_settimeofday __NR_settimeofday
#endif
#ifdef __NR_mount
#define SYS_mount __NR_mount
#endif
#ifdef __NR_umount2
#define SYS_umount2 __NR_umount2
#endif
#ifdef __NR_swapon
#define SYS_swapon __NR_swapon
#endif
#ifdef __NR_swapoff
#define SYS_swapoff __NR_swapoff
#endif
#ifdef __NR_reboot
#define SYS_reboot __NR_reboot
#endif
#ifdef __NR_sethostname
#define SYS_sethostname __NR_sethostname
#endif
#ifdef __NR_setdomainname
#define SYS_setdomainname __NR_setdomainname
#endif
#ifdef __NR_iopl
#define SYS_iopl __NR_iopl
#endif
#ifdef __NR_ioperm
#define SYS_ioperm __NR_ioperm
#endif
#ifdef __NR_create_module
#define SYS_create_module __NR_create_module
#endif
#ifdef __NR_init_module
#define SYS_init_module __NR_init_module
#endif
#ifdef __NR_delete_module
#define SYS_delete_module __NR_delete_module
#endif
#ifdef __NR_get_kernel_syms
#define SYS_get_kernel_syms __NR_get_kernel_syms
#endif
#ifdef __NR_query_module
#define SYS_query_module __NR_query_module
#endif
#ifdef __NR_quotactl
#define SYS_quotactl __NR_quotactl
#endif
#ifdef __NR_nfsservctl
#define SYS_nfsservctl __NR_nfsservctl
#endif
#ifdef __NR_getpmsg
#define SYS_getpmsg __NR_getpmsg
#endif
#ifdef __NR_putpmsg
#define SYS_putpmsg __NR_putpmsg
#endif
#ifdef __NR_afs_syscall
#define SYS_afs_syscall __NR_afs_syscall
#endif
#ifdef __NR_tuxcall
#define SYS_tuxcall __NR_tuxcall
#endif
#ifdef __NR_security
#define SYS_security __NR_security
#endif
#ifdef __NR_gettid
#define SYS_gettid __NR_gettid
#endif
#ifdef __NR_readahead
#define SYS_readahead __NR_readahead
#endif
#ifdef __NR_setxattr
#define SYS_setxattr __NR_setxattr
#endif
#ifdef __NR_lsetxattr
#define SYS_lsetxattr __NR_lsetxattr
#endif
#ifdef __NR_fsetxattr
#define SYS_fsetxattr __NR_fsetxattr
#endif
#ifdef __NR_getxattr
#define SYS_getxattr __NR_getxattr
#endif
#ifdef __NR_lgetxattr
#define SYS_lgetxattr __NR_lgetxattr
#endif
#ifdef __NR_fgetxattr
#define SYS_fgetxattr __NR_fgetxattr
#endif
#ifdef __NR_listxattr
#define SYS_listxattr __NR_listxattr
#endif
#ifdef __NR_llistxattr
#define SYS_llistxattr __NR_llistxattr
#endif
#ifdef __NR_flistxattr
#define SYS_flistxattr __NR_flistxattr
#endif
#ifdef __NR_removexattr
#define SYS_removexattr __NR_removexattr
#endif
#ifdef __NR_lremovexattr
#define SYS_lremovexattr __NR_lremovexattr
#endif
#ifdef __NR_fremovexattr
#define SYS_fremovexattr __NR_fremovexattr
#endif
#ifdef __NR_tkill
#define SYS_tkill __NR_tkill
#endif
#ifdef __NR_time
#define SYS_time __NR_time
#endif
#ifdef __NR_futex
#define SYS_futex __NR_futex
#endif
#ifdef __NR_sched_setaffinity
#define SYS_sched_setaffinity __NR_sched_setaffinity
#endif
#ifdef __NR_sched_getaffinity
#define SYS_sched_getaffinity __NR_sched_getaffinity
#endif
#ifdef __NR_set_thread_area
#define SYS_set_thread_area __NR_set_thread_area
#endif
#ifdef __NR_io_setup
#define SYS_io_setup __NR_io_setup
#endif
#ifdef __NR_io_destroy
#define SYS_io_destroy __NR_io_destroy
#endif
#ifdef __NR_io_getevents
#define SYS_io_getevents __NR_io_getevents
#endif
#ifdef __NR_io_submit
#define SYS_io_submit __NR_io_submit
#endif
#ifdef __NR_io_cancel
#define SYS_io_cancel __NR_io_cancel
#endif
#ifdef __NR_get_thread_area
#define SYS_get_thread_area __NR_get_thread_area
#endif
#ifdef __NR_lookup_dcookie
#define SYS_lookup_dcookie __NR_lookup_dcookie
#endif
#ifdef __NR_epoll_create
#define SYS_epoll_create __NR_epoll_create
#endif
#ifdef __NR_epoll_ctl_old
#define SYS_epoll_ctl_old __NR_epoll_ctl_old
#endif
#ifdef __NR_epoll_wait_old
#define SYS_epoll_wait_old __NR_epoll_wait_old
#endif
#ifdef __NR_remap_file_pages
#define SYS_remap_file_pages __NR_remap_file_pages
#endif
#ifdef __NR_getdents64
#define SYS_getdents64 __NR_getdents64
#endif
#ifdef __NR_set_tid_address
#define SYS_set_tid_address __NR_set_tid_address
#endif
#ifdef __NR_restart_syscall
#define SYS_restart_syscall __NR_restart_syscall
#endif
#ifdef __NR_semtimedop
#define SYS_semtimedop __NR_semtimedop
#endif
#ifdef __NR_fadvise64
#define SYS_fadvise64 __NR_fadvise64
#endif
#ifdef __NR_timer_create
#define SYS_timer_create __NR_timer_create
#endif
#ifdef __NR_timer_settime
#define SYS_timer_settime __NR_timer_settime
#endif
#ifdef __NR_timer_gettime
#define SYS_timer_gettime __NR_timer_gettime
#endif
#ifdef __NR_timer_getoverrun
#define SYS_timer_getoverrun __NR_timer_getoverrun
#endif
#ifdef __NR_timer_delete
#define SYS_timer_delete __NR_timer_delete
#endif
#ifdef __NR_clock_settime
#define SYS_clock_settime __NR_clock_settime
#endif
#ifdef __NR_clock_gettime
#define SYS_clock_gettime __NR_clock_gettime
#endif
#ifdef __NR_clock_getres
#define SYS_clock_getres __NR_clock_getres
#endif
#ifdef __NR_clock_nanosleep
#define SYS_clock_nanosleep __NR_clock_nanosleep
#endif
#ifdef __NR_exit_group
#define SYS_exit_group __NR_exit_group
#endif
#ifdef __NR_epoll_wait
#define SYS_epoll_wait __NR_epoll_wait
#endif
#ifdef __NR_epoll_ctl
#define SYS_epoll_ctl __NR_epoll_ctl
#endif
#ifdef __NR_tgkill
#define SYS_tgkill __NR_tgkill
#endif
#ifdef __NR_utimes
#define SYS_utimes __NR_utimes
#endif
#ifdef __NR_vserver
#define SYS_vserver __NR_vserver
#endif
#ifdef __NR_mbind
#define SYS_mbind __NR_mbind
#endif
#ifdef __NR_set_mempolicy
#define SYS_set_mempolicy __NR_set_mempolicy
#endif
#ifdef __NR_get_mempolicy
#define SYS_get_mempolicy __NR_get_mempolicy
#endif
#ifdef __NR_mq_open
#define SYS_mq_open __NR_mq_open
#endif
#ifdef __NR_mq_unlink
#define SYS_mq_unlink __NR_mq_unlink
#endif
#ifdef __NR_mq_timedsend
#define SYS_mq_timedsend __NR_mq_timedsend
#endif
#ifdef __NR_mq_timedreceive
#define SYS_mq_timedreceive __NR_mq_timedreceive
#endif
#ifdef __NR_mq_notify
#define SYS_mq_notify __NR_mq_notify
#endif
#ifdef __NR_mq_getsetattr
#define SYS_mq_getsetattr __NR_mq_getsetattr
#endif
#ifdef __NR_kexec_load
#define SYS_kexec_load __NR_kexec_load
#endif
#ifdef __NR_waitid
#define SYS_waitid __NR_waitid
#endif
#ifdef __NR_add_key
#define SYS_add_key __NR_add_key
#endif
#ifdef __NR_request_key
#define SYS_request_key __NR_request_key
#endif
#ifdef __NR_keyctl
#define SYS_keyctl __NR_keyctl
#endif
#ifdef __NR_ioprio_set
#define SYS_ioprio_set __NR_ioprio_set
#endif
#ifdef __NR_ioprio_get
#define SYS_ioprio_get __NR_ioprio_get
#endif
#ifdef __NR_inotify_init
#define SYS_inotify_init __NR_inotify_init
#endif
#ifdef __NR_inotify_add_watch
#define SYS_inotify_add_watch __NR_inotify_add_watch
#endif
#ifdef __NR_inotify_rm_watch
#define SYS_inotify_rm_watch __NR_inotify_rm_watch
#endif
#ifdef __NR_migrate_pages
#define SYS_migrate_pages __NR_migrate_pages
#endif
#ifdef __NR_openat
#define SYS_openat __NR_openat
#endif
#ifdef __NR_mkdirat
#define SYS_mkdirat __NR_mkdirat
#endif
#ifdef __NR_mknodat
#define SYS_mknodat __NR_mknodat
#endif
#ifdef __NR_fchownat
#define SYS_fchownat __NR_fchownat
#endif
#ifdef __NR_futimesat
#define SYS_futimesat __NR_futimesat
#endif
#ifdef __NR_newfstatat
#define SYS_newfstatat __NR_newfstatat
#endif
#ifdef __NR_unlinkat
#define SYS_unlinkat __NR_unlinkat
#endif
#ifdef __NR_renameat
#define SYS_renameat __NR_renameat
#endif
#ifdef __NR_linkat
#define SYS_linkat __NR_linkat
#endif
#ifdef __NR_symlinkat
#define SYS_symlinkat __NR_symlinkat
#endif
#ifdef __NR_readlinkat
#define SYS_readlinkat __NR_readlinkat
#endif
#ifdef __NR_fchmodat
#define SYS_fchmodat __NR_fchmodat
#endif
#ifdef __NR_faccessat
#define SYS_faccessat __NR_faccessat
#endif
#ifdef __NR_pselect6
#define SYS_pselect6 __NR_pselect6
#endif
#ifdef __NR_ppoll
#define SYS_ppoll __NR_ppoll
#endif
#ifdef __NR_unshare
#define SYS_unshare __NR_unshare
#endif
#ifdef __NR_set_robust_list
#define SYS_set_robust_list __NR_set_robust_list
#endif
#ifdef __NR_get_robust_list
#define SYS_get_robust_list __NR_get_robust_list
#endif
#ifdef __NR_splice
#define SYS_splice __NR_splice
#endif
#ifdef __NR_tee
#define SYS_tee __NR_tee
#endif
#ifdef __NR_sync_file_range
#define SYS_sync_file_range __NR_sync_file_range
#endif
#ifdef __NR_vmsplice
#define SYS_vmsplice __NR_vmsplice
#endif
#ifdef __NR_move_pages
#define SYS_move_pages __NR_move_pages
#endif
#ifdef __NR_utimensat
#define SYS_utimensat __NR_utimensat
#endif
#ifdef __NR_epoll_pwait
#define SYS_epoll_pwait __NR_epoll_pwait
#endif
#ifdef __NR_signalfd
#define SYS_signalfd __NR_signalfd
#endif
#ifdef __NR_timerfd_create
#define SYS_timerfd_create __NR_timerfd_create
#endif
#ifdef __NR_eventfd
#define SYS_eventfd __NR_eventfd
#endif
#ifdef __NR_fallocate
#define SYS_fallocate __NR_fallocate
#endif
#ifdef __NR_timerfd_settime
#define SYS_timerfd_settime __NR_timerfd_settime
#endif
#ifdef __NR_timerfd_gettime
#define SYS_timerfd_gettime __NR_timerfd_gettime
#endif
#ifdef __NR_accept4
#define SYS_accept4 __NR_accept4
#endif
#ifdef __NR_signalfd4
#define SYS_signalfd4 __NR_signalfd4
#endif
#ifdef __NR_eventfd2
#define SYS_eventfd2 __NR_eventfd2
#endif
#ifdef __NR_epoll_create1
#define SYS_epoll_create1 __NR_epoll_create1
#endif
#ifdef __NR_dup3
#define SYS_dup3 __NR_dup3
#endif
#ifdef __NR_pipe2
#define SYS_pipe2 __NR_pipe2
#endif
#ifdef __NR_inotify_init1
#define SYS_inotify_init1 __NR_inotify_init1
#endif
#ifdef __NR_preadv
#define SYS_preadv __NR_preadv
#endif
#ifdef __NR_pwritev
#define SYS_pwritev __NR_pwritev
#endif
#ifdef __NR_rt_tgsigqueueinfo
#define SYS_rt_tgsigqueueinfo __NR_rt_tgsigqueueinfo
#endif
#ifdef __NR_perf_event_open
#define SYS_perf_event_open __NR_perf_event_open
#endif
#ifdef __NR_recvmmsg
#define SYS_recvmmsg __NR_recvmmsg
#endif
#ifdef __NR_fanotify_init
#define SYS_fanotify_init __NR_fanotify_init
#endif
#ifdef __NR_fanotify_mark
#define SYS_fanotify_mark __NR_fanotify_mark
#endif
#ifdef __NR_prlimit64
#define SYS_prlimit64 __NR_prlimit64
#endif
#ifdef __NR_name_to_handle_at
#define SYS_name_to_handle_at __NR_name_to_handle_at
#endif
#ifdef __NR_open_by_handle_at
#define SYS_open_by_handle_at __NR_open_by_handle_at
#endif
#ifdef __NR_clock_adjtime
#define SYS_clock_adjtime __NR_clock_adjtime
#endif
#ifdef __NR_syncfs
#define SYS_syncfs __NR_syncfs
#endif
#ifdef __NR_sendmmsg
#define SYS_sendmmsg __NR_sendmmsg
#endif
#ifdef __NR_setns
#define SYS_setns __NR_setns
#endif
#ifdef __NR_getcpu
#define SYS_getcpu __NR_getcpu
#endif
#ifdef __NR_process_vm_readv
#define SYS_process_vm_readv __NR_process_vm_readv
#endif
#ifdef __NR_process_vm_writev
#define SYS_process_vm_writev __NR_process_vm_writev
#endif
#ifdef __NR_kcmp
#define SYS_kcmp __NR_kcmp
#endif
#ifdef __NR_finit_module
#define SYS_finit_module __NR_finit_module
#endif
#ifdef __NR_sched_setattr
#define SYS_sched_setattr __NR_sched_setattr
#endif
#ifdef __NR_sched_getattr
#define SYS_sched_getattr __NR_sched_getattr
#endif
#ifdef __NR_renameat2
#define SYS_renameat2 __NR_renameat2
#endif
#ifdef __NR_seccomp
#define SYS_seccomp __NR_seccomp
#endif
#ifdef __NR_getrandom
#define SYS_getrandom __NR_getrandom
#endif
#ifdef __NR_memfd_create
#define SYS_memfd_create __NR_memfd_create
#endif
#ifdef __NR_kexec_file_load
#define SYS_kexec_file_load __NR_kexec_file_load
#endif
#ifdef __NR_bpf
#define SYS_bpf __NR_bpf
#endif
#ifdef __NR_execveat
#define SYS_execveat __NR_execveat
#endif
#ifdef __NR_userfaultfd
#define SYS_userfaultfd __NR_userfaultfd
#endif
#ifdef __NR_membarrier
#define SYS_membarrier __NR_membarrier
#endif
#ifdef __NR_mlock2
#define SYS_mlock2 __NR_mlock2
#endif
#ifdef __NR_copy_file_range
#define SYS_copy_file_range __NR_copy_file_range
#endif
#ifdef __NR_preadv2
#define SYS_preadv2 __NR_preadv2
#endif
#ifdef __NR_pwritev2
#define SYS_pwritev2 __NR_pwritev2
#endif
#ifdef __NR_pkey_mprotect
#define SYS_pkey_mprotect __NR_pkey_mprotect
#endif
#ifdef __NR_pkey_alloc
#define SYS_pkey_alloc __NR_pkey_alloc
#endif
#ifdef __NR_pkey_free
#define SYS_pkey_free __NR_pkey_free
#endif
#ifdef __NR_statx
#define SYS_statx __NR_statx
#endif
#ifdef __NR_io_pgetevents
#define SYS_io_pgetevents __NR_io_pgetevents
#endif
#ifdef __NR_rseq
#define SYS_rseq __NR_rseq
#endif
#ifdef __NR_pidfd_send_signal
#define SYS_pidfd_send_signal __NR_pidfd_send_signal
#endif
#ifdef __NR_io_uring_setup
#define SYS_io_uring_setup __NR_io_uring_setup
#endif
#ifdef __NR_io_uring_enter
#define SYS_io_uring_enter __NR_io_uring_enter
#endif
#ifdef __NR_io_uring_register
#define SYS_io_uring_register __NR_io_uring_register
#endif
#ifdef __NR_open_tree
#define SYS_open_tree __NR_open_tree
#endif
#ifdef __NR_move_mount
#define SYS_move_mount __NR_move_mount
#endif
#ifdef __NR_fsopen
#define SYS_fsopen __NR_fsopen
#endif
#ifdef __NR_fsconfig
#define SYS_fsconfig __NR_fsconfig
#endif
#ifdef __NR_fsmount
#define SYS_fsmount __NR_fsmount
#endif
#ifdef __NR_fspick
#define SYS_fspick __NR_fspick
#endif
#ifdef __NR_pidfd_open
#define SYS_pidfd_open __NR_pidfd_open
#endif
#ifdef __NR_clone3
#define SYS_clone3 __NR_clone3
#endif
#ifdef __NR_close_range
#define SYS_close_range __NR_close_range
#endif
#ifdef __NR_openat2
#define SYS_openat2 __NR_openat2
#endif
#ifdef __NR_pidfd_getfd
#define SYS_pidfd_getfd __NR_pidfd_getfd
#endif
#ifdef __NR_faccessat2
#define SYS_faccessat2 __NR_faccessat2
#endif
#ifdef __NR_process_madvise
#define SYS_process_madvise __NR_process_madvise
#endif
#ifdef __NR_epoll_pwait2
#define SYS_epoll_pwait2 __NR_epoll_pwait2
#endif
#ifdef __NR_mount_setattr
#define SYS_mount_setattr __NR_mount_setattr
#endif
#ifdef __NR_quotactl_fd
#define SYS_quotactl_fd __NR_quotactl_fd
#endif
#ifdef __NR_landlock_create_ruleset
#define SYS_landlock_create_ruleset __NR_landlock_create_ruleset
#endif
#ifdef __NR_landlock_add_rule
#define SYS_landlock_add_rule __NR_landlock_add_rule
#endif
#ifdef __NR_landlock_restrict_self
#define SYS_landlock_restrict_self __NR_landlock_restrict_self
#endif
#ifdef __NR_memfd_secret
#define SYS_memfd_secret __NR_memfd_secret
#endif
#ifdef __NR_process_mrelease
#define SYS_process_mrelease __NR_process_mrelease
#endif
#ifdef __NR_futex_waitv
#define SYS_futex_waitv __NR_futex_waitv
#endif
#ifdef __NR_set_mempolicy_home_node
#define SYS_set_mempolicy_home_node __NR_set_mempolicy_home_node
#endif

#else

#include_next <sys/syscall.h>

#endif

#endif
