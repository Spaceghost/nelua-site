#define _GNU_SOURCE
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <getopt.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdint.h>
#include <arpa/inet.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/timerfd.h>
#include <sys/signalfd.h>
#include <locale.h>
#include <malloc.h>
#include <fnmatch.h>
#include <wchar.h>
#include <wctype.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <utime.h>
#include <wordexp.h>
#include "nelibc_alloc.h"
#ifdef NELIBC_STANDALONE
#include <pthread.h>
#include <crypt.h>
#else
#include <sys/mman.h>
#include <pthread.h>
#endif

extern char **environ;
/* BEGIN GENERATED GERMAN CCC-0 SOURCE MARK EXPANSION SMOKE */
typedef struct {
  const wchar_t *composed_wide;
  const wchar_t *decomposed_wide;
  const char *composed_utf8;
  const char *decomposed_utf8;
} german_mark_expansion_case;

static const german_mark_expansion_case german_mark_expansion_cases[] = {
  {
    L"a\U000009cb", L"a\U000009c7\U000009be",
    "\x61\xe0\xa7\x8b", "\x61\xe0\xa7\x87\xe0\xa6\xbe"
  },
  {
    L"a\U000009cc", L"a\U000009c7\U000009d7",
    "\x61\xe0\xa7\x8c", "\x61\xe0\xa7\x87\xe0\xa7\x97"
  },
  {
    L"a\U00000b48", L"a\U00000b47\U00000b56",
    "\x61\xe0\xad\x88", "\x61\xe0\xad\x87\xe0\xad\x96"
  },
  {
    L"a\U00000b4b", L"a\U00000b47\U00000b3e",
    "\x61\xe0\xad\x8b", "\x61\xe0\xad\x87\xe0\xac\xbe"
  },
  {
    L"a\U00000b4c", L"a\U00000b47\U00000b57",
    "\x61\xe0\xad\x8c", "\x61\xe0\xad\x87\xe0\xad\x97"
  },
  {
    L"a\U00000bca", L"a\U00000bc6\U00000bbe",
    "\x61\xe0\xaf\x8a", "\x61\xe0\xaf\x86\xe0\xae\xbe"
  },
  {
    L"a\U00000bcb", L"a\U00000bc7\U00000bbe",
    "\x61\xe0\xaf\x8b", "\x61\xe0\xaf\x87\xe0\xae\xbe"
  },
  {
    L"a\U00000bcc", L"a\U00000bc6\U00000bd7",
    "\x61\xe0\xaf\x8c", "\x61\xe0\xaf\x86\xe0\xaf\x97"
  },
  {
    L"a\U00000c48", L"a\U00000c46\U00000c56",
    "\x61\xe0\xb1\x88", "\x61\xe0\xb1\x86\xe0\xb1\x96"
  },
  {
    L"a\U00000cc0", L"a\U00000cbf\U00000cd5",
    "\x61\xe0\xb3\x80", "\x61\xe0\xb2\xbf\xe0\xb3\x95"
  },
  {
    L"a\U00000cc7", L"a\U00000cc6\U00000cd5",
    "\x61\xe0\xb3\x87", "\x61\xe0\xb3\x86\xe0\xb3\x95"
  },
  {
    L"a\U00000cc8", L"a\U00000cc6\U00000cd6",
    "\x61\xe0\xb3\x88", "\x61\xe0\xb3\x86\xe0\xb3\x96"
  },
  {
    L"a\U00000cca", L"a\U00000cc6\U00000cc2",
    "\x61\xe0\xb3\x8a", "\x61\xe0\xb3\x86\xe0\xb3\x82"
  },
  {
    L"a\U00000ccb", L"a\U00000cc6\U00000cc2\U00000cd5",
    "\x61\xe0\xb3\x8b", "\x61\xe0\xb3\x86\xe0\xb3\x82\xe0\xb3\x95"
  },
  {
    L"a\U00000d4a", L"a\U00000d46\U00000d3e",
    "\x61\xe0\xb5\x8a", "\x61\xe0\xb5\x86\xe0\xb4\xbe"
  },
  {
    L"a\U00000d4b", L"a\U00000d47\U00000d3e",
    "\x61\xe0\xb5\x8b", "\x61\xe0\xb5\x87\xe0\xb4\xbe"
  },
  {
    L"a\U00000d4c", L"a\U00000d46\U00000d57",
    "\x61\xe0\xb5\x8c", "\x61\xe0\xb5\x86\xe0\xb5\x97"
  },
  {
    L"a\U00000dda", L"a\U00000dd9\U00000dca",
    "\x61\xe0\xb7\x9a", "\x61\xe0\xb7\x99\xe0\xb7\x8a"
  },
  {
    L"a\U00000ddc", L"a\U00000dd9\U00000dcf",
    "\x61\xe0\xb7\x9c", "\x61\xe0\xb7\x99\xe0\xb7\x8f"
  },
  {
    L"a\U00000ddd", L"a\U00000dd9\U00000dcf\U00000dca",
    "\x61\xe0\xb7\x9d", "\x61\xe0\xb7\x99\xe0\xb7\x8f\xe0\xb7\x8a"
  },
  {
    L"a\U00000dde", L"a\U00000dd9\U00000ddf",
    "\x61\xe0\xb7\x9e", "\x61\xe0\xb7\x99\xe0\xb7\x9f"
  },
  {
    L"a\U00000f73", L"a\U00000f71\U00000f72",
    "\x61\xe0\xbd\xb3", "\x61\xe0\xbd\xb1\xe0\xbd\xb2"
  },
  {
    L"a\U00000f75", L"a\U00000f71\U00000f74",
    "\x61\xe0\xbd\xb5", "\x61\xe0\xbd\xb1\xe0\xbd\xb4"
  },
  {
    L"a\U00000f76", L"a\U00000fb2\U00000f80",
    "\x61\xe0\xbd\xb6", "\x61\xe0\xbe\xb2\xe0\xbe\x80"
  },
  {
    L"a\U00000f78", L"a\U00000fb3\U00000f80",
    "\x61\xe0\xbd\xb8", "\x61\xe0\xbe\xb3\xe0\xbe\x80"
  },
  {
    L"a\U00000f81", L"a\U00000f71\U00000f80",
    "\x61\xe0\xbe\x81", "\x61\xe0\xbd\xb1\xe0\xbe\x80"
  },
  {
    L"a\U00000f93", L"a\U00000f92\U00000fb7",
    "\x61\xe0\xbe\x93", "\x61\xe0\xbe\x92\xe0\xbe\xb7"
  },
  {
    L"a\U00000f9d", L"a\U00000f9c\U00000fb7",
    "\x61\xe0\xbe\x9d", "\x61\xe0\xbe\x9c\xe0\xbe\xb7"
  },
  {
    L"a\U00000fa2", L"a\U00000fa1\U00000fb7",
    "\x61\xe0\xbe\xa2", "\x61\xe0\xbe\xa1\xe0\xbe\xb7"
  },
  {
    L"a\U00000fa7", L"a\U00000fa6\U00000fb7",
    "\x61\xe0\xbe\xa7", "\x61\xe0\xbe\xa6\xe0\xbe\xb7"
  },
  {
    L"a\U00000fac", L"a\U00000fab\U00000fb7",
    "\x61\xe0\xbe\xac", "\x61\xe0\xbe\xab\xe0\xbe\xb7"
  },
  {
    L"a\U00000fb9", L"a\U00000f90\U00000fb5",
    "\x61\xe0\xbe\xb9", "\x61\xe0\xbe\x90\xe0\xbe\xb5"
  },
  {
    L"a\U00001b3b", L"a\U00001b3a\U00001b35",
    "\x61\xe1\xac\xbb", "\x61\xe1\xac\xba\xe1\xac\xb5"
  },
  {
    L"a\U00001b3d", L"a\U00001b3c\U00001b35",
    "\x61\xe1\xac\xbd", "\x61\xe1\xac\xbc\xe1\xac\xb5"
  },
  {
    L"a\U00001b40", L"a\U00001b3e\U00001b35",
    "\x61\xe1\xad\x80", "\x61\xe1\xac\xbe\xe1\xac\xb5"
  },
  {
    L"a\U00001b41", L"a\U00001b3f\U00001b35",
    "\x61\xe1\xad\x81", "\x61\xe1\xac\xbf\xe1\xac\xb5"
  },
  {
    L"a\U00001b43", L"a\U00001b42\U00001b35",
    "\x61\xe1\xad\x83", "\x61\xe1\xad\x82\xe1\xac\xb5"
  },
  {
    L"a\U0001112e", L"a\U00011131\U00011127",
    "\x61\xf0\x91\x84\xae", "\x61\xf0\x91\x84\xb1\xf0\x91\x84\xa7"
  },
  {
    L"a\U0001112f", L"a\U00011132\U00011127",
    "\x61\xf0\x91\x84\xaf", "\x61\xf0\x91\x84\xb2\xf0\x91\x84\xa7"
  },
  {
    L"a\U0001134b", L"a\U00011347\U0001133e",
    "\x61\xf0\x91\x8d\x8b", "\x61\xf0\x91\x8d\x87\xf0\x91\x8c\xbe"
  },
  {
    L"a\U0001134c", L"a\U00011347\U00011357",
    "\x61\xf0\x91\x8d\x8c", "\x61\xf0\x91\x8d\x87\xf0\x91\x8d\x97"
  },
  {
    L"a\U000113c5", L"a\U000113c2\U000113c2",
    "\x61\xf0\x91\x8f\x85", "\x61\xf0\x91\x8f\x82\xf0\x91\x8f\x82"
  },
  {
    L"a\U000113c7", L"a\U000113c2\U000113b8",
    "\x61\xf0\x91\x8f\x87", "\x61\xf0\x91\x8f\x82\xf0\x91\x8e\xb8"
  },
  {
    L"a\U000113c8", L"a\U000113c2\U000113c9",
    "\x61\xf0\x91\x8f\x88", "\x61\xf0\x91\x8f\x82\xf0\x91\x8f\x89"
  },
  {
    L"a\U000114bb", L"a\U000114b9\U000114ba",
    "\x61\xf0\x91\x92\xbb", "\x61\xf0\x91\x92\xb9\xf0\x91\x92\xba"
  },
  {
    L"a\U000114bc", L"a\U000114b9\U000114b0",
    "\x61\xf0\x91\x92\xbc", "\x61\xf0\x91\x92\xb9\xf0\x91\x92\xb0"
  },
  {
    L"a\U000114be", L"a\U000114b9\U000114bd",
    "\x61\xf0\x91\x92\xbe", "\x61\xf0\x91\x92\xb9\xf0\x91\x92\xbd"
  },
  {
    L"a\U000115ba", L"a\U000115b8\U000115af",
    "\x61\xf0\x91\x96\xba", "\x61\xf0\x91\x96\xb8\xf0\x91\x96\xaf"
  },
  {
    L"a\U000115bb", L"a\U000115b9\U000115af",
    "\x61\xf0\x91\x96\xbb", "\x61\xf0\x91\x96\xb9\xf0\x91\x96\xaf"
  },
  {
    L"a\U00011938", L"a\U00011935\U00011930",
    "\x61\xf0\x91\xa4\xb8", "\x61\xf0\x91\xa4\xb5\xf0\x91\xa4\xb0"
  },
  {
    L"a\U00016121", L"a\U0001611e\U0001611e",
    "\x61\xf0\x96\x84\xa1", "\x61\xf0\x96\x84\x9e\xf0\x96\x84\x9e"
  },
  {
    L"a\U00016122", L"a\U0001611e\U00016129",
    "\x61\xf0\x96\x84\xa2", "\x61\xf0\x96\x84\x9e\xf0\x96\x84\xa9"
  },
  {
    L"a\U00016123", L"a\U0001611e\U0001611f",
    "\x61\xf0\x96\x84\xa3", "\x61\xf0\x96\x84\x9e\xf0\x96\x84\x9f"
  },
  {
    L"a\U00016124", L"a\U00016129\U0001611f",
    "\x61\xf0\x96\x84\xa4", "\x61\xf0\x96\x84\xa9\xf0\x96\x84\x9f"
  },
  {
    L"a\U00016125", L"a\U0001611e\U00016120",
    "\x61\xf0\x96\x84\xa5", "\x61\xf0\x96\x84\x9e\xf0\x96\x84\xa0"
  },
  {
    L"a\U00016126", L"a\U0001611e\U0001611e\U0001611f",
    "\x61\xf0\x96\x84\xa6", "\x61\xf0\x96\x84\x9e\xf0\x96\x84\x9e\xf0\x96\x84\x9f"
  },
  {
    L"a\U00016127", L"a\U0001611e\U00016129\U0001611f",
    "\x61\xf0\x96\x84\xa7", "\x61\xf0\x96\x84\x9e\xf0\x96\x84\xa9\xf0\x96\x84\x9f"
  },
  {
    L"a\U00016128", L"a\U0001611e\U0001611e\U00016120",
    "\x61\xf0\x96\x84\xa8", "\x61\xf0\x96\x84\x9e\xf0\x96\x84\x9e\xf0\x96\x84\xa0"
  },
};
/* END GENERATED GERMAN CCC-0 SOURCE MARK EXPANSION SMOKE */
/* BEGIN GENERATED GERMAN COMBINING CLASS SMOKE */
typedef struct {
  unsigned int combining_class;
  wchar_t wide;
  const char *utf8;
} german_combining_class_case;

static const german_combining_class_case german_combining_class_cases[] = {
  {
    1, L'\U00000334',
    "\xcc\xb4"
  },
  {
    6, L'\U00016ff0',
    "\xf0\x96\xbf\xb0"
  },
  {
    7, L'\U0000093c',
    "\xe0\xa4\xbc"
  },
  {
    8, L'\U00003099',
    "\xe3\x82\x99"
  },
  {
    9, L'\U0000094d',
    "\xe0\xa5\x8d"
  },
  {
    10, L'\U000005b0',
    "\xd6\xb0"
  },
  {
    11, L'\U000005b1',
    "\xd6\xb1"
  },
  {
    12, L'\U000005b2',
    "\xd6\xb2"
  },
  {
    13, L'\U000005b3',
    "\xd6\xb3"
  },
  {
    14, L'\U000005b4',
    "\xd6\xb4"
  },
  {
    15, L'\U000005b5',
    "\xd6\xb5"
  },
  {
    16, L'\U000005b6',
    "\xd6\xb6"
  },
  {
    17, L'\U000005b7',
    "\xd6\xb7"
  },
  {
    18, L'\U000005b8',
    "\xd6\xb8"
  },
  {
    19, L'\U000005b9',
    "\xd6\xb9"
  },
  {
    20, L'\U000005bb',
    "\xd6\xbb"
  },
  {
    21, L'\U000005bc',
    "\xd6\xbc"
  },
  {
    22, L'\U000005bd',
    "\xd6\xbd"
  },
  {
    23, L'\U000005bf',
    "\xd6\xbf"
  },
  {
    24, L'\U000005c1',
    "\xd7\x81"
  },
  {
    25, L'\U000005c2',
    "\xd7\x82"
  },
  {
    26, L'\U0000fb1e',
    "\xef\xac\x9e"
  },
  {
    27, L'\U0000064b',
    "\xd9\x8b"
  },
  {
    28, L'\U0000064c',
    "\xd9\x8c"
  },
  {
    29, L'\U0000064d',
    "\xd9\x8d"
  },
  {
    30, L'\U00000618',
    "\xd8\x98"
  },
  {
    31, L'\U00000619',
    "\xd8\x99"
  },
  {
    32, L'\U0000061a',
    "\xd8\x9a"
  },
  {
    33, L'\U00000651',
    "\xd9\x91"
  },
  {
    34, L'\U00000652',
    "\xd9\x92"
  },
  {
    35, L'\U00000670',
    "\xd9\xb0"
  },
  {
    36, L'\U00000711',
    "\xdc\x91"
  },
  {
    84, L'\U00000c55',
    "\xe0\xb1\x95"
  },
  {
    91, L'\U00000c56',
    "\xe0\xb1\x96"
  },
  {
    103, L'\U00000e38',
    "\xe0\xb8\xb8"
  },
  {
    107, L'\U00000e48',
    "\xe0\xb9\x88"
  },
  {
    118, L'\U00000eb8',
    "\xe0\xba\xb8"
  },
  {
    122, L'\U00000ec8',
    "\xe0\xbb\x88"
  },
  {
    129, L'\U00000f71',
    "\xe0\xbd\xb1"
  },
  {
    130, L'\U00000f72',
    "\xe0\xbd\xb2"
  },
  {
    132, L'\U00000f74',
    "\xe0\xbd\xb4"
  },
  {
    202, L'\U00000321',
    "\xcc\xa1"
  },
  {
    214, L'\U00001dce',
    "\xe1\xb7\x8e"
  },
  {
    216, L'\U0000031b',
    "\xcc\x9b"
  },
  {
    218, L'\U00001dfa',
    "\xe1\xb7\xba"
  },
  {
    220, L'\U00000316',
    "\xcc\x96"
  },
  {
    222, L'\U0000059a',
    "\xd6\x9a"
  },
  {
    224, L'\U0000302e',
    "\xe3\x80\xae"
  },
  {
    226, L'\U0001d16d',
    "\xf0\x9d\x85\xad"
  },
  {
    228, L'\U000005ae',
    "\xd6\xae"
  },
  {
    230, L'\U00000300',
    "\xcc\x80"
  },
  {
    232, L'\U00000315',
    "\xcc\x95"
  },
  {
    233, L'\U0000035c',
    "\xcd\x9c"
  },
  {
    234, L'\U0000035d',
    "\xcd\x9d"
  },
  {
    240, L'\U00000345',
    "\xcd\x85"
  },
};
/* END GENERATED GERMAN COMBINING CLASS SMOKE */
extern long nelibc_test_legacy_strtol(const char *, char **, int)
    __asm__("strtol");
extern long nelibc_test_legacy_wcstol(const wchar_t *, wchar_t **, int)
    __asm__("wcstol");

static int call_vswprintf(wchar_t *output, size_t capacity,
                          const wchar_t *format, ...) {
  va_list arguments;
  va_start(arguments, format);
  int result = vswprintf(output, capacity, format, arguments);
  va_end(arguments);
  return result;
}

#if defined(NELIBC_STATIC_MUSL)
extern int nelibc_test_standard_strerror_r(int, char *, size_t)
    __asm__("strerror_r");
#endif

static void system_signal_probe(int signal_number) {
  (void)signal_number;
}

static int locale_float_parser_probe(void) {
  locale_t c_locale = newlocale(LC_NUMERIC_MASK, "C", (locale_t)0);
  if (c_locale == (locale_t)0) return 1;
  locale_t ctype_locale = newlocale(LC_CTYPE_MASK, "C", (locale_t)0);
  locale_t utf8_ctype_locale = newlocale(LC_CTYPE_MASK, "C.UTF-8", (locale_t)0);
  if (ctype_locale == (locale_t)0 || utf8_ctype_locale == (locale_t)0) return 26;
  locale_t original_locale = uselocale((locale_t)0);
  if (!isalnum_l('A', ctype_locale) || !isalpha_l('A', ctype_locale) ||
      !isblank_l(' ', ctype_locale) || !iscntrl_l('\n', ctype_locale) ||
      !isdigit_l('4', ctype_locale) || !isgraph_l('!', ctype_locale) ||
      !islower_l('a', ctype_locale) || !isprint_l(' ', ctype_locale) ||
      !ispunct_l('!', ctype_locale) || !isspace_l('\t', ctype_locale) ||
      !isupper_l('A', ctype_locale) || !isxdigit_l('F', ctype_locale) ||
      tolower_l('A', ctype_locale) != 'a' ||
      toupper_l('a', ctype_locale) != 'A' ||
      isalpha_l(0xe9, utf8_ctype_locale) ||
      uselocale((locale_t)0) != original_locale) return 27;
  char *end = NULL;
  errno = 0;
  if (strtof_l("12.5tail", &end, c_locale) != 12.5f ||
      end == NULL || strcmp(end, "tail") != 0 || errno != 0) return 2;
  end = NULL;
  if (strtod_l("12.5tail", &end, c_locale) != 12.5 ||
      end == NULL || strcmp(end, "tail") != 0 || errno != 0) return 3;
  end = NULL;
  if (strtold_l("12.5tail", &end, c_locale) != 12.5L ||
      end == NULL || strcmp(end, "tail") != 0 || errno != 0) return 4;
  end = NULL;
  if (strtol_l("-42tail", &end, 10, c_locale) != -42 ||
      end == NULL || strcmp(end, "tail") != 0) return 10;
  end = NULL;
  if (strtoul_l("42tail", &end, 10, c_locale) != 42UL ||
      end == NULL || strcmp(end, "tail") != 0) return 11;
  end = NULL;
  if (strtoll_l("-9223372036854775808!", &end, 10, c_locale) != LLONG_MIN ||
      end == NULL || *end != '!') return 12;
  end = NULL;
  if (strtoull_l("0xffffffffffffffff!", &end, 0, c_locale) != ULLONG_MAX ||
      end == NULL || *end != '!') return 13;
  const wchar_t wide_signed[] = L"-42tail";
  wchar_t *wide_end = NULL;
  if (wcstol_l(wide_signed, &wide_end, 10, c_locale) != -42 ||
      wide_end == NULL || wcscmp(wide_end, L"tail") != 0) return 14;
  const wchar_t wide_unsigned[] = L"42tail";
  wide_end = NULL;
  if (wcstoul_l(wide_unsigned, &wide_end, 10, c_locale) != 42UL ||
      wide_end == NULL || wcscmp(wide_end, L"tail") != 0) return 15;
  wide_end = NULL;
  if (wcstoll_l(L"-9223372036854775808!", &wide_end, 10, c_locale) != LLONG_MIN ||
      wide_end == NULL || *wide_end != L'!') return 16;
  wide_end = NULL;
  if (wcstoull_l(L"0xffffffffffffffff!", &wide_end, 0, c_locale) != ULLONG_MAX ||
      wide_end == NULL || *wide_end != L'!') return 17;
  end = NULL;
  if (__isoc23_strtol_l("0b101!", &end, 0, c_locale) != 5 || end == NULL || *end != '!') return 18;
  end = NULL;
  if (__isoc23_strtoul_l("0B101!", &end, 0, c_locale) != 5 || end == NULL || *end != '!') return 19;
  end = NULL;
  if (__isoc23_strtoll_l("0b101!", &end, 0, c_locale) != 5 || end == NULL || *end != '!') return 20;
  end = NULL;
  if (__isoc23_strtoull_l("0B101!", &end, 0, c_locale) != 5 || end == NULL || *end != '!') return 21;
  wide_end = NULL;
  if (__isoc23_wcstol_l(L"0b101!", &wide_end, 0, c_locale) != 5 ||
      wide_end == NULL || *wide_end != L'!') return 22;
  wide_end = NULL;
  if (__isoc23_wcstoul_l(L"0B101!", &wide_end, 0, c_locale) != 5 ||
      wide_end == NULL || *wide_end != L'!') return 23;
  wide_end = NULL;
  if (__isoc23_wcstoll_l(L"0b101!", &wide_end, 0, c_locale) != 5 ||
      wide_end == NULL || *wide_end != L'!') return 24;
  wide_end = NULL;
  if (__isoc23_wcstoull_l(L"0B101!", &wide_end, 0, c_locale) != 5 ||
      wide_end == NULL || *wide_end != L'!') return 25;
  if (uselocale((locale_t)0) != original_locale) return 5;
  locale_t german_locale = newlocale(LC_NUMERIC_MASK, "de_DE.UTF-8", (locale_t)0);
  if (german_locale != (locale_t)0) {
    locale_t saved_locale = uselocale(german_locale);
    int german_radix_available =
        strcmp(localeconv()->decimal_point, ",") == 0;
    uselocale(saved_locale);
    if (!german_radix_available) {
      freelocale(german_locale);
      freelocale(c_locale);
      return 0;
    }
    end = NULL;
    if (strtof_l("12,5tail", &end, german_locale) != 12.5f ||
        end == NULL || strcmp(end, "tail") != 0) return 6;
    end = NULL;
    if (strtod_l("12,5tail", &end, german_locale) != 12.5 ||
        end == NULL || strcmp(end, "tail") != 0) return 7;
    end = NULL;
    if (strtold_l("12,5tail", &end, german_locale) != 12.5L ||
        end == NULL || strcmp(end, "tail") != 0) return 8;
    if (uselocale((locale_t)0) != original_locale) return 9;
    freelocale(german_locale);
  }
  freelocale(c_locale);
  freelocale(utf8_ctype_locale);
  freelocale(ctype_locale);
  return 0;
}

#ifdef NELIBC_STANDALONE
typedef struct {
  locale_t locales[7];
  struct lconv *main_locale_data;
  int locale_data_isolated;
} standalone_numeric_locale_args;

static void *standalone_uselocale_worker(void *argument) {
  locale_t c_locale = (locale_t)argument;
  if (uselocale((locale_t)0) != LC_GLOBAL_LOCALE ||
      uselocale(c_locale) != LC_GLOBAL_LOCALE || iswalpha(0xe9) != 0 ||
      uselocale((locale_t)0) != c_locale) return (void *)1;
  errno = 0;
  if (uselocale((locale_t)(uintptr_t)1) != (locale_t)0 || errno != EINVAL ||
      uselocale((locale_t)0) != c_locale ||
      uselocale(LC_GLOBAL_LOCALE) != c_locale || !iswalpha(0xe9))
    return (void *)2;
  return 0;
}

static void *standalone_numeric_locale_worker(void *argument) {
  standalone_numeric_locale_args *args =
      (standalone_numeric_locale_args *)argument;
  locale_t numeric_c = args->locales[0];
  locale_t numeric_de = args->locales[1];
  locale_t monetary_c = args->locales[2];
  locale_t monetary_de = args->locales[3];
  locale_t collate_c = args->locales[4];
  locale_t time_c = args->locales[5];
  locale_t time_de = args->locales[6];
  if (uselocale(numeric_c) != LC_GLOBAL_LOCALE ||
      strcmp(localeconv()->decimal_point, ".") != 0 || !iswalpha(0xe9))
    return (void *)1;
  char *parse_end = NULL;
  if (strtof_l("12,5tail", &parse_end, numeric_de) != 12.5f ||
      parse_end == NULL || strcmp(parse_end, "tail") != 0) return (void *)21;
  parse_end = NULL;
  if (strtod_l("12,5tail", &parse_end, numeric_de) != 12.5 ||
      parse_end == NULL || strcmp(parse_end, "tail") != 0) return (void *)22;
  parse_end = NULL;
  if (strtold_l("12,5tail", &parse_end, numeric_de) != 12.5L ||
      parse_end == NULL || strcmp(parse_end, "tail") != 0) return (void *)23;
  wchar_t *wide_parse_end = NULL;
  if (strtol_l("-42tail", &parse_end, 10, numeric_de) != -42 ||
      parse_end == NULL || strcmp(parse_end, "tail") != 0 ||
      wcstol_l(L"-42tail", &wide_parse_end, 10, numeric_de) != -42 ||
      wide_parse_end == NULL || wcscmp(wide_parse_end, L"tail") != 0)
    return (void *)26;
  if (strcmp(localeconv()->decimal_point, ".") != 0) return (void *)24;
  if (uselocale((locale_t)0) != numeric_c) return (void *)25;
  struct lconv *thread_locale_data = localeconv();
  args->locale_data_isolated = thread_locale_data != args->main_locale_data &&
      strcmp(thread_locale_data->decimal_point, ".") == 0;
  locale_t global_copy = duplocale(LC_GLOBAL_LOCALE);
  if (global_copy != numeric_de ||
      newlocale(LC_NUMERIC_MASK, "C", global_copy) != numeric_c)
    return (void *)5;
  char *end = NULL;
  if (strtod("12.5", &end) != 12.5 || end == NULL || *end != '\0')
    return (void *)2;
  char formatted[16];
  if (snprintf(formatted, sizeof formatted, "%.1f", 12.5) != 4 ||
      strcmp(formatted, "12.5") != 0 ||
      snprintf(formatted, sizeof formatted, "%'.2f", 1234567.5) != 10 ||
      strcmp(formatted, "1234567.50") != 0 ||
      uselocale(numeric_de) != numeric_c ||
      strcmp(localeconv()->decimal_point, ",") != 0)
    return (void *)3;
  end = NULL;
  if (strtod("12,5", &end) != 12.5 || end == NULL || *end != '\0' ||
      snprintf(formatted, sizeof formatted, "%.1f", 12.5) != 4 ||
      strcmp(formatted, "12,5") != 0 ||
      snprintf(formatted, sizeof formatted, "%'.2f", 1234567.5) != 12 ||
      strcmp(formatted, "1.234.567,50") != 0 ||
      uselocale(LC_GLOBAL_LOCALE) != numeric_de ||
      strcmp(localeconv()->decimal_point, ",") != 0 || !iswalpha(0xe9))
    return (void *)4;
  end = NULL;
  if (strtof_l("12.5tail", &end, numeric_c) != 12.5f ||
      end == NULL || strcmp(end, "tail") != 0) return (void *)31;
  end = NULL;
  if (strtod_l("12.5tail", &end, numeric_c) != 12.5 ||
      end == NULL || strcmp(end, "tail") != 0) return (void *)32;
  end = NULL;
  if (strtold_l("12.5tail", &end, numeric_c) != 12.5L ||
      end == NULL || strcmp(end, "tail") != 0) return (void *)33;
  if (strcmp(localeconv()->decimal_point, ",") != 0) return (void *)34;
  if (uselocale((locale_t)0) != LC_GLOBAL_LOCALE) return (void *)35;
  if (strcmp(localeconv()->decimal_point, ",") != 0)
    return (void *)6;
  if (uselocale(monetary_de) != LC_GLOBAL_LOCALE ||
      strcmp(localeconv()->currency_symbol, "\342\202\254") != 0 ||
      strcmp(localeconv()->mon_decimal_point, ",") != 0 ||
      localeconv()->frac_digits != 2 ||
      strcmp(localeconv()->decimal_point, ".") != 0 ||
      uselocale(monetary_c) != monetary_de ||
      localeconv()->currency_symbol[0] != '\0' ||
      strcmp(localeconv()->decimal_point, ".") != 0 ||
      uselocale(LC_GLOBAL_LOCALE) != monetary_c ||
      localeconv()->currency_symbol[0] != '\0')
    return (void *)7;
  char transformed[8];
  if (uselocale(collate_c) != LC_GLOBAL_LOCALE ||
      uselocale((locale_t)0) != collate_c ||
      strcoll("a", "B") <= 0 ||
      strxfrm(transformed, "aB", sizeof transformed) != 2 ||
      strcmp(transformed, "aB") != 0 ||
      uselocale(LC_GLOBAL_LOCALE) != collate_c)
    return (void *)8;
  struct tm sample_time = {
      .tm_sec = 9, .tm_min = 5, .tm_hour = 13, .tm_mday = 1,
      .tm_mon = 2, .tm_year = 124, .tm_wday = 5, .tm_yday = 60,
      .tm_isdst = 0, .tm_gmtoff = 0, .tm_zone = "UTC"};
  char time_text[128];
  wchar_t wide_time_text[128];
  wchar_t short_wide_time_text[8];
  struct tm parsed_time = {0};
  if (strftime_l(time_text, sizeof time_text, "%A|%B|%x", &sample_time,
          time_de) == 0 ||
      strcmp(time_text, "Freitag|März|01.03.2024") != 0 ||
      wcsftime_l(wide_time_text, 128, L"%A|%B|%x", &sample_time, time_de) == 0 ||
      wcscmp(wide_time_text, L"Freitag|März|01.03.2024") != 0 ||
      wcsftime_l(short_wide_time_text, 8, L"%A|%B|%x", &sample_time,
          time_de) != 0 || short_wide_time_text[0] != 0 ||
      wcsftime_l(wide_time_text, 128, L"%A|%B|%x", &sample_time, time_c) == 0 ||
      wcscmp(wide_time_text, L"Friday|March|03/01/24") != 0 ||
      uselocale((locale_t)0) != LC_GLOBAL_LOCALE ||
      uselocale(time_de) != LC_GLOBAL_LOCALE ||
      wcsftime(wide_time_text, 128, L"%A|%B|%x", &sample_time) == 0 ||
      wcscmp(wide_time_text, L"Freitag|März|01.03.2024") != 0 ||
      uselocale(LC_GLOBAL_LOCALE) != time_de ||
      strptime_l(time_text, "%A|%B|%x", &parsed_time, time_de) == NULL ||
      parsed_time.tm_wday != 5 || parsed_time.tm_mon != 2 ||
      parsed_time.tm_mday != 1 || parsed_time.tm_year != 124 ||
      uselocale((locale_t)0) != LC_GLOBAL_LOCALE ||
      uselocale(time_de) != LC_GLOBAL_LOCALE ||
      strftime(time_text, sizeof time_text, "%A|%B|%x", &sample_time) == 0 ||
      strcmp(time_text, "Freitag|März|01.03.2024") != 0 ||
      strptime(time_text, "%A|%B|%x", &parsed_time) == NULL ||
      parsed_time.tm_wday != 5 || parsed_time.tm_mon != 2 ||
      parsed_time.tm_mday != 1 || parsed_time.tm_year != 124 ||
      strftime(time_text, sizeof time_text, "%c", &sample_time) == 0 ||
      strcmp(time_text, "Fr 01. Mär 2024, 13:05:09") != 0 ||
      strptime(time_text, "%c", &parsed_time) == NULL ||
      parsed_time.tm_wday != 5 || parsed_time.tm_mon != 2 ||
      parsed_time.tm_mday != 1 || parsed_time.tm_year != 124 ||
      parsed_time.tm_hour != 13 || parsed_time.tm_min != 5 ||
      parsed_time.tm_sec != 9 ||
      uselocale(time_c) != time_de ||
      strftime(time_text, sizeof time_text, "%A|%B|%x", &sample_time) == 0 ||
      strcmp(time_text, "Friday|March|03/01/24") != 0 ||
      uselocale(LC_GLOBAL_LOCALE) != time_c)
    return (void *)9;
  return 0;
}
#endif

#ifdef NELIBC_STANDALONE
static int standalone_locale_smoke(void) {
  static const int categories[] = {
      LC_COLLATE, LC_CTYPE, LC_MONETARY, LC_NUMERIC, LC_TIME,
#ifdef LC_MESSAGES
      LC_MESSAGES,
#endif
  };
  static const char expected_utf8_all[] =
      "LC_CTYPE=C.UTF-8;LC_NUMERIC=C;LC_TIME=C;LC_COLLATE=C;"
      "LC_MONETARY=C;LC_MESSAGES=C";
  static const char expected_de_all[] =
      "LC_CTYPE=C;LC_NUMERIC=de_DE.UTF-8;LC_TIME=C;LC_COLLATE=C;"
      "LC_MONETARY=C;LC_MESSAGES=C";
  static const char expected_de_monetary_all[] =
      "LC_CTYPE=C;LC_NUMERIC=de_DE.UTF-8;LC_TIME=C;LC_COLLATE=C;"
      "LC_MONETARY=de_DE.UTF-8;LC_MESSAGES=C";
  static const char expected_de_time_all[] =
      "LC_CTYPE=C;LC_NUMERIC=de_DE.UTF-8;LC_TIME=de_DE.UTF-8;LC_COLLATE=C;"
      "LC_MONETARY=C;LC_MESSAGES=C";
  const char *current = setlocale(LC_ALL, NULL);
  struct lconv *numeric = localeconv();
  if (numeric == NULL || numeric->decimal_point == NULL ||
      strcmp(numeric->decimal_point, ".") != 0 ||
      numeric->thousands_sep == NULL || numeric->thousands_sep[0] != '\0') return 9;
  if (current == NULL || strcmp(current, "C") != 0) return 1;
  for (size_t i = 0; i < sizeof categories / sizeof categories[0]; ++i) {
    current = setlocale(categories[i], NULL);
    if (current == NULL || strcmp(current, "C") != 0) return 2;
  }
  if (setlocale(LC_NUMERIC, "POSIX") == NULL ||
      setlocale(LC_NUMERIC, "unsupported_locale") != NULL ||
      strcmp(setlocale(LC_NUMERIC, NULL), "C") != 0) return 3;
  if (setlocale(LC_NUMERIC, "de_DE.UTF-8") == NULL ||
      strcmp(setlocale(LC_NUMERIC, NULL), "de_DE.UTF-8") != 0) return 10;
  if (strcmp(setlocale(LC_ALL, NULL), expected_de_all) != 0) return 15;
  numeric = localeconv();
  if (numeric == NULL || strcmp(numeric->decimal_point, ",") != 0 ||
      strcmp(numeric->thousands_sep, ".") != 0 || numeric->grouping[0] != 3) return 11;
  if (setlocale(LC_MONETARY, "de_DE.UTF-8") == NULL ||
      strcmp(setlocale(LC_MONETARY, NULL), "de_DE.UTF-8") != 0 ||
      strcmp(setlocale(LC_ALL, NULL), expected_de_monetary_all) != 0) return 29;
  numeric = localeconv();
  if (strcmp(numeric->int_curr_symbol, "EUR ") != 0 ||
      strcmp(numeric->currency_symbol, "\342\202\254") != 0 ||
      strcmp(numeric->mon_decimal_point, ",") != 0 ||
      strcmp(numeric->mon_thousands_sep, ".") != 0 ||
      numeric->mon_grouping[0] != 3 || numeric->frac_digits != 2 ||
      numeric->p_cs_precedes != 0 || numeric->p_sep_by_space != 1 ||
      numeric->n_sign_posn != 1) return 30;
  if (setlocale(LC_MONETARY, "C") == NULL ||
      strcmp(setlocale(LC_ALL, NULL), expected_de_all) != 0) return 31;
  if (setlocale(LC_TIME, "de_DE.UTF-8") == NULL ||
      strcmp(setlocale(LC_TIME, NULL), "de_DE.UTF-8") != 0 ||
      setlocale(LC_ALL, expected_de_time_all) == NULL ||
      strcmp(setlocale(LC_ALL, NULL), expected_de_time_all) != 0)
    return 34;
  struct tm global_time_sample = {
      .tm_sec = 9, .tm_min = 5, .tm_hour = 13, .tm_mday = 1,
      .tm_mon = 2, .tm_year = 124, .tm_wday = 5, .tm_yday = 60,
      .tm_isdst = 0, .tm_gmtoff = 0, .tm_zone = "UTC"};
  char global_time_text[64];
  locale_t global_time_snapshot = duplocale(LC_GLOBAL_LOCALE);
  if (global_time_snapshot == (locale_t)0 ||
      strftime(global_time_text, sizeof global_time_text, "%A|%B|%x",
          &global_time_sample) == 0 ||
      strcmp(global_time_text, "Freitag|März|01.03.2024") != 0 ||
      setlocale(LC_TIME, "C") == NULL ||
      strcmp(setlocale(LC_ALL, NULL), expected_de_all) != 0 ||
      uselocale(global_time_snapshot) != LC_GLOBAL_LOCALE ||
      strftime(global_time_text, sizeof global_time_text, "%A|%B|%x",
          &global_time_sample) == 0 ||
      strcmp(global_time_text, "Freitag|März|01.03.2024") != 0 ||
      uselocale(LC_GLOBAL_LOCALE) != global_time_snapshot)
    return 35;
  freelocale(global_time_snapshot);
  char *end = NULL;
  if (strtod("12,5", &end) != 12.5 || end == NULL || *end != '\0') return 12;
  char formatted[16];
  if (snprintf(formatted, sizeof formatted, "%.1f", 12.5) != 4 ||
      strcmp(formatted, "12,5") != 0) return 13;
  if (snprintf(formatted, sizeof formatted, "%'.2f", 1234567.5) != 12 ||
      strcmp(formatted, "1.234.567,50") != 0) return 24;
  if (snprintf(formatted, sizeof formatted, "%'.8g", 1234567.5) != 11 ||
      strcmp(formatted, "1.234.567,5") != 0) return 25;
  if (snprintf(formatted, sizeof formatted, "%.4g", 9999.9) != 5 ||
      strcmp(formatted, "1e+04") != 0) return 26;
  if (snprintf(formatted, sizeof formatted, "%.4g", 0.000099999) != 6 ||
      strcmp(formatted, "0,0001") != 0) return 27;
  if (snprintf(formatted, sizeof formatted, "%.0f", 2.5) != 1 ||
      strcmp(formatted, "2") != 0 ||
      snprintf(formatted, sizeof formatted, "%.0f", 3.5) != 1 ||
      strcmp(formatted, "4") != 0 ||
      snprintf(formatted, sizeof formatted, "%.1f", 1.25) != 3 ||
      strcmp(formatted, "1,2") != 0) return 28;
  int formatted_length = snprintf(formatted, sizeof formatted, "%'d", 1234567);
  if (formatted_length != 9) return 18;
  if (strcmp(formatted, "1.234.567") != 0) return 19;
  formatted_length = snprintf(formatted, sizeof formatted, "%'010d", 1234);
  if (formatted_length != 10) return 20;
  if (strcmp(formatted, "000001.234") != 0) return 21;
  formatted_length = snprintf(formatted, sizeof formatted, "%'.10d", 1234);
  if (formatted_length != 11 || strcmp(formatted, "0000001.234") != 0) return 22;
  if (setlocale(LC_NUMERIC, "C") == NULL ||
      strcmp(localeconv()->decimal_point, ".") != 0) return 14;
  if (snprintf(formatted, sizeof formatted, "%'d", 1234567) != 7 ||
      strcmp(formatted, "1234567") != 0) return 23;
  if (setlocale(LC_CTYPE, "C.UTF-8") == NULL) return 4;
  current = setlocale(LC_ALL, NULL);
  if (current == NULL || strcmp(current, expected_utf8_all) != 0) return 5;
  char saved_locale[sizeof expected_utf8_all];
  size_t length = strlen(current);
  if (length >= sizeof saved_locale) return 6;
  memcpy(saved_locale, current, length + 1);
  if (setlocale(LC_CTYPE, "C") == NULL ||
      setlocale(LC_ALL, saved_locale) == NULL ||
      strcmp(setlocale(LC_CTYPE, NULL), "C.UTF-8") != 0) return 7;
  if (setlocale(LC_ALL, "C") == NULL ||
      strcmp(setlocale(LC_ALL, NULL), "C") != 0) return 8;
  return 0;
}
#endif

static int allocator_probe(void) {
  unsigned char *bytes = nelibc_malloc(7);
  if (bytes == NULL || (uintptr_t)bytes % sizeof(long double) != 0 ||
      !nelibc_allocator_owns(bytes)) return 1;
  for (size_t i = 0; i < 7; ++i) bytes[i] = (unsigned char)(0x30 + i);
  bytes = nelibc_realloc(bytes, 128);
  if (bytes == NULL) return 2;
  for (size_t i = 0; i < 7; ++i)
    if (bytes[i] != (unsigned char)(0x30 + i)) return 3;

  uint32_t *zeroed = nelibc_calloc(8, sizeof *zeroed);
  if (zeroed == NULL) return 4;
  for (size_t i = 0; i < 8; ++i)
    if (zeroed[i] != 0) return 5;

  uint32_t *standard_zeroed = calloc(8, sizeof *standard_zeroed);
  if (standard_zeroed == NULL || !nelibc_allocator_owns(standard_zeroed)) return 15;
  for (size_t i = 0; i < 8; ++i)
    if (standard_zeroed[i] != 0) return 16;
  errno = 0;
  volatile size_t oversized_count = SIZE_MAX;
  if (calloc(oversized_count, 2) != NULL || errno != ENOMEM) return 17;
  errno = 0;
  void *standard_aligned = aligned_alloc(64, 128);
  if (standard_aligned == NULL || (uintptr_t)standard_aligned % 64 != 0 ||
      !nelibc_allocator_owns(standard_aligned))
    return 18;
  free(standard_aligned);
  errno = 0;
  if (aligned_alloc(64, 127) != NULL || errno != EINVAL) return 19;

  void *aligned = nelibc_aligned_alloc(64, 128);
  if (aligned == NULL || (uintptr_t)aligned % 64 != 0) return 6;
  void *posix_aligned = NULL;
  errno = E2BIG;
  int posix_result = nelibc_posix_memalign(&posix_aligned, 128, 19);
  if (posix_result != 0 || (uintptr_t)posix_aligned % 128 != 0 || errno != E2BIG)
    return 7;
  void *standard_posix_aligned = NULL;
  errno = E2BIG;
  posix_result = posix_memalign(&standard_posix_aligned, 128, 19);
  if (posix_result != 0 || (uintptr_t)standard_posix_aligned % 128 != 0 ||
      errno != E2BIG || !nelibc_allocator_owns(standard_posix_aligned)) return 20;
  free(standard_posix_aligned);
  standard_posix_aligned = (void *)(uintptr_t)1;
  if (posix_memalign(&standard_posix_aligned, 3, 19) != EINVAL ||
      standard_posix_aligned != (void *)(uintptr_t)1) return 21;

  void *large = nelibc_malloc(32768);
  if (large == NULL || !nelibc_allocator_owns(large)) return 10;
  ((unsigned char *)large)[0] = 0x6d;
  ((unsigned char *)large)[32767] = 0xb2;
  void *large_grown = nelibc_realloc(large, 65537);
  if (large_grown == NULL ||
      ((unsigned char *)large_grown)[0] != 0x6d ||
      ((unsigned char *)large_grown)[32767] != 0xb2 ||
      !nelibc_allocator_owns(large_grown)) return 22;
  large = large_grown;
  nelibc_free(large);
  if (nelibc_allocator_owns(large)) return 11;

  void *aligned_direct = NULL;
  if (posix_memalign(&aligned_direct, 65536, 32768) != 0 ||
      aligned_direct == NULL || (uintptr_t)aligned_direct % 65536 != 0)
    return 25;
  ((unsigned char *)aligned_direct)[0] = 0x3c;
  ((unsigned char *)aligned_direct)[32767] = 0xc3;
  void *aligned_direct_grown = nelibc_realloc(aligned_direct, 131073);
  if (aligned_direct_grown == NULL ||
      (uintptr_t)aligned_direct_grown % 65536 != 0 ||
      ((unsigned char *)aligned_direct_grown)[0] != 0x3c ||
      ((unsigned char *)aligned_direct_grown)[32767] != 0xc3 ||
      !nelibc_allocator_owns(aligned_direct_grown)) return 26;
  nelibc_free(aligned_direct_grown);

  void *standard = malloc(32);
  if (standard == NULL) return 12;
  if (!nelibc_allocator_owns(standard)) return 13;
  free(standard);
  free(standard_zeroed);

  errno = 0;
  if (nelibc_calloc(SIZE_MAX, 2) != NULL || errno != ENOMEM) return 8;
  errno = 0;
  if (nelibc_reallocarray(NULL, SIZE_MAX, 2) != NULL || errno != ENOMEM) return 9;

  nelibc_free(bytes);
  nelibc_free(zeroed);
  nelibc_free(aligned);
  nelibc_free(posix_aligned);
  return 0;
}

static int getdate_probe(void) {
  unsetenv("DATEMSK");
  if (getdate("2024-02-29") != NULL || getdate_err != 1) return 1;
  char template_path[] = "/tmp/nelibc-getdate-XXXXXX";
  int template_fd = mkstemp(template_path);
  if (template_fd < 0) return 2;
  static const char templates[] = "%Y-%m-%d %H:%M:%S\n%Y-%m-%d\n%Y-%j\n";
  if (write(template_fd, templates, sizeof templates - 1) !=
          (ssize_t)(sizeof templates - 1) || close(template_fd) != 0 ||
      setenv("DATEMSK", template_path, 1) != 0) {
    unlink(template_path);
    return 3;
  }
  struct tm *parsed = getdate("2024-02-29 13:05:09");
  if (parsed == NULL || getdate_err != 0 || parsed->tm_year != 124 ||
      parsed->tm_mon != 1 || parsed->tm_mday != 29 || parsed->tm_hour != 13 ||
      parsed->tm_min != 5 || parsed->tm_sec != 9) {
    unsetenv("DATEMSK");
    unlink(template_path);
    return 4;
  }
  parsed = getdate("2024-060");
  if (parsed == NULL || getdate_err != 0 || parsed->tm_year != 124 ||
      parsed->tm_mon != 1 || parsed->tm_mday != 29) {
    unsetenv("DATEMSK");
    unlink(template_path);
    return 8;
  }
  if (getdate("2024-02-31") != NULL || getdate_err != 8 ||
      getdate("not a date") != NULL || getdate_err != 7) {
    unsetenv("DATEMSK");
    unlink(template_path);
    return 5;
  }
  if (setenv("DATEMSK", "/nelibc/this/file/does/not/exist", 1) != 0 ||
      getdate("2024-02-29") != NULL || getdate_err != 2) {
    unsetenv("DATEMSK");
    unlink(template_path);
    return 6;
  }
  unsetenv("DATEMSK");
  unlink(template_path);
  return getdate_err == 2 ? 0 : 7;
}

static int utimes_probe(void) {
  char path[] = "/tmp/nelibc-utimes-XXXXXX";
  int descriptor = mkstemp(path);
  if (descriptor < 0 || close(descriptor) != 0) return 1;
  struct timeval timestamps[2] = {
      {.tv_sec = 1000000000, .tv_usec = 123456},
      {.tv_sec = 1000000001, .tv_usec = 654321}};
  struct stat status;
  if (utimes(path, timestamps) != 0 || stat(path, &status) != 0 ||
      status.st_atim.tv_sec != 1000000000 || status.st_atim.tv_nsec != 123456000 ||
      status.st_mtim.tv_sec != 1000000001 || status.st_mtim.tv_nsec != 654321000) {
    unlink(path);
    return 2;
  }
  timestamps[0].tv_usec = 1000000;
  errno = 0;
  if (utimes(path, timestamps) != -1 || errno != EINVAL || utimes(path, NULL) != 0) {
    unlink(path);
    return 3;
  }
  return unlink(path) == 0 ? 0 : 4;
}

static int futimes_probe(void) {
  char path[] = "/tmp/nelibc-futimes-XXXXXX";
  int descriptor = mkstemp(path);
  if (descriptor < 0) return 1;
  struct timeval timestamps[2] = {
      {.tv_sec = 1000000002, .tv_usec = 234567},
      {.tv_sec = 1000000003, .tv_usec = 765432}};
  struct stat status;
  if (futimes(descriptor, timestamps) != 0 || fstat(descriptor, &status) != 0 ||
      status.st_atim.tv_sec != 1000000002 || status.st_atim.tv_nsec != 234567000 ||
      status.st_mtim.tv_sec != 1000000003 || status.st_mtim.tv_nsec != 765432000) {
    close(descriptor);
    unlink(path);
    return 2;
  }
  timestamps[1].tv_usec = -1;
  errno = 0;
  if (futimes(descriptor, timestamps) != -1 || errno != EINVAL ||
      futimes(descriptor, NULL) != 0) {
    close(descriptor);
    unlink(path);
    return 3;
  }
  if (close(descriptor) != 0 || unlink(path) != 0) return 4;
  errno = 0;
  return futimes(-1, NULL) == -1 && errno == EBADF ? 0 : 5;
}

static int futimesat_probe(void) {
  char path[] = "/tmp/nelibc-futimesat-XXXXXX";
  int descriptor = mkstemp(path);
  if (descriptor < 0 || close(descriptor) != 0) return 1;
  const char *name = strrchr(path, '/') + 1;
  int directory = open("/tmp", O_RDONLY | O_DIRECTORY);
  if (directory < 0) { unlink(path); return 2; }
  struct timeval timestamps[2] = {
      {.tv_sec = 1000000004, .tv_usec = 345678},
      {.tv_sec = 1000000005, .tv_usec = 876543}};
  struct stat status;
  if (futimesat(directory, name, timestamps) != 0 || stat(path, &status) != 0 ||
      status.st_atim.tv_sec != 1000000004 || status.st_atim.tv_nsec != 345678000 ||
      status.st_mtim.tv_sec != 1000000005 || status.st_mtim.tv_nsec != 876543000) {
    close(directory); unlink(path); return 3;
  }
  timestamps[0].tv_usec = 1000000;
  errno = 0;
  if (futimesat(directory, name, timestamps) != -1 || errno != EINVAL ||
      futimesat(directory, name, NULL) != 0) {
    close(directory); unlink(path); return 4;
  }
  if (close(directory) != 0 || unlink(path) != 0) return 5;
  errno = 0;
  return futimesat(-1, "missing-nelibc-futimesat-path", NULL) == -1 && errno == EBADF ? 0 : 6;
}

static int lutimes_probe(void) {
  char target[] = "/tmp/nelibc-lutimes-target-XXXXXX";
  char linkpath[] = "/tmp/nelibc-lutimes-link-XXXXXX";
  int descriptor = mkstemp(target);
  if (descriptor < 0 || close(descriptor) != 0) return 1;
  descriptor = mkstemp(linkpath);
  if (descriptor < 0 || close(descriptor) != 0 || unlink(linkpath) != 0) {
    unlink(target);
    return 2;
  }
  struct timeval target_times[2] = {
      {.tv_sec = 1000000006, .tv_usec = 111111},
      {.tv_sec = 1000000007, .tv_usec = 222222}};
  struct timeval link_times[2] = {
      {.tv_sec = 1000000008, .tv_usec = 333333},
      {.tv_sec = 1000000009, .tv_usec = 444444}};
  struct stat target_status, link_status;
  if (utimes(target, target_times) != 0 || symlink(target, linkpath) != 0 ||
      lutimes(linkpath, link_times) != 0 || lstat(linkpath, &link_status) != 0 ||
      stat(linkpath, &target_status) != 0 ||
      !S_ISLNK(link_status.st_mode) ||
      link_status.st_atim.tv_sec != 1000000008 || link_status.st_atim.tv_nsec != 333333000 ||
      link_status.st_mtim.tv_sec != 1000000009 || link_status.st_mtim.tv_nsec != 444444000 ||
      target_status.st_atim.tv_sec != 1000000006 || target_status.st_atim.tv_nsec != 111111000 ||
      target_status.st_mtim.tv_sec != 1000000007 || target_status.st_mtim.tv_nsec != 222222000) {
    unlink(linkpath); unlink(target); return 3;
  }
  link_times[1].tv_usec = 1000000;
  errno = 0;
  if (lutimes(linkpath, link_times) != -1 || errno != EINVAL ||
      lutimes(linkpath, NULL) != 0) {
    unlink(linkpath); unlink(target); return 4;
  }
  return unlink(linkpath) == 0 && unlink(target) == 0 ? 0 : 5;
}

static int utime_probe(void) {
  char path[] = "/tmp/nelibc-utime-XXXXXX";
  int descriptor = mkstemp(path);
  if (descriptor < 0 || close(descriptor) != 0) return 1;
  struct utimbuf timestamps = {.actime = 1000000010, .modtime = 1000000011};
  struct stat status;
  if (utime(path, &timestamps) != 0 || stat(path, &status) != 0 ||
      status.st_atim.tv_sec != 1000000010 || status.st_atim.tv_nsec != 0 ||
      status.st_mtim.tv_sec != 1000000011 || status.st_mtim.tv_nsec != 0) {
    unlink(path);
    return 2;
  }
  if (utime(path, NULL) != 0 || stat(path, &status) != 0 ||
      status.st_atim.tv_sec <= 0 || status.st_mtim.tv_sec <= 0) {
    unlink(path);
    return 3;
  }
  return unlink(path) == 0 ? 0 : 4;
}

static int semaphore_clock_probe(void) {
  sem_t semaphore;
  if (sem_init(&semaphore, 0, 1) != 0) return 1;

  struct timespec invalid = { .tv_sec = 0, .tv_nsec = 1000000000L };
  if (sem_clockwait(&semaphore, CLOCK_MONOTONIC, &invalid) != 0) return 2;

  struct timespec expired = { .tv_sec = 0, .tv_nsec = 0 };
  if (sem_clockwait(&semaphore, CLOCK_MONOTONIC, &expired) != -1 ||
      errno != ETIMEDOUT) return 3;
  if (sem_destroy(&semaphore) != 0) return 4;
  return 0;
}

#ifndef NELIBC_STANDALONE
static int atfork_probe_order[8];
static int atfork_probe_count;
static void atfork_probe_add(int value) {
  if (atfork_probe_count < 8) atfork_probe_order[atfork_probe_count++] = value;
}
static void atfork_probe_prepare_a(void) { atfork_probe_add(1); }
static void atfork_probe_prepare_b(void) { atfork_probe_add(2); }
static void atfork_probe_parent_a(void) { atfork_probe_add(3); }
static void atfork_probe_parent_b(void) { atfork_probe_add(4); }
static void atfork_probe_child_a(void) { atfork_probe_add(5); }
static void atfork_probe_child_b(void) { atfork_probe_add(6); }

static int pthread_protocol_probe(void) {
  pthread_mutexattr_t attributes;
  pthread_mutex_t mutex;
  int protocol = -1;
  if (pthread_mutexattr_init(&attributes) != 0 ||
      pthread_mutexattr_setprotocol(&attributes, PTHREAD_PRIO_INHERIT) != 0 ||
      pthread_mutexattr_getprotocol(&attributes, &protocol) != 0 ||
      protocol != PTHREAD_PRIO_INHERIT ||
      pthread_mutex_init(&mutex, &attributes) != 0 ||
      pthread_mutexattr_destroy(&attributes) != 0 ||
      pthread_mutex_lock(&mutex) != 0 || pthread_mutex_unlock(&mutex) != 0 ||
      pthread_mutex_destroy(&mutex) != 0)
    return 1;
  return 0;
}

static int pthread_sigmask_probe(void) {
  sigset_t signal_set;
  sigset_t previous_set;
  sigset_t observed_set;
  clockid_t cpu_clock;
  clockid_t process_cpu_clock;
  struct timespec cpu_time;
  struct timespec process_cpu_time;
  if (sigemptyset(&signal_set) != 0 || sigaddset(&signal_set, SIGUSR1) != 0 ||
      pthread_sigmask(SIG_BLOCK, &signal_set, &previous_set) != 0 ||
      pthread_sigmask(0, NULL, &observed_set) != 0 ||
      sigismember(&observed_set, SIGUSR1) != 1 ||
      pthread_sigmask(SIG_SETMASK, &previous_set, NULL) != 0 ||
      pthread_kill(pthread_self(), 0) != 0 ||
      pthread_getcpuclockid(pthread_self(), &cpu_clock) != 0 ||
      clock_gettime(cpu_clock, &cpu_time) != 0 ||
      clock_getcpuclockid(0, &process_cpu_clock) != 0 ||
      clock_gettime(process_cpu_clock, &process_cpu_time) != 0 ||
      process_cpu_time.tv_sec < 0 || process_cpu_time.tv_nsec < 0 ||
      process_cpu_time.tv_nsec >= 1000000000L)
    return 1;
  int previous_errno = errno;
  errno = EOVERFLOW;
  if (clock_getcpuclockid((pid_t)-1, &process_cpu_clock) != EINVAL ||
      errno != EOVERFLOW || clock_getcpuclockid(0, NULL) != EINVAL ||
      errno != EOVERFLOW)
    return 1;
  errno = previous_errno;
  return 0;
}

static int archive_unistd_adapter_probe(void) {
  /* Force archive extraction of the variadic and credential C ABI adapters. */
  void (*volatile immediate_exit_symbol)(int) = _Exit;
  int (*volatile setuid_symbol)(uid_t) = setuid;
  int (*volatile seteuid_symbol)(uid_t) = seteuid;
  int (*volatile setgid_symbol)(gid_t) = setgid;
  int (*volatile setegid_symbol)(gid_t) = setegid;
  int (*volatile setreuid_symbol)(uid_t, uid_t) = setreuid;
  int (*volatile setregid_symbol)(gid_t, gid_t) = setregid;
  int (*volatile setresuid_symbol)(uid_t, uid_t, uid_t) = setresuid;
  int (*volatile setresgid_symbol)(gid_t, gid_t, gid_t) = setresgid;
  if (immediate_exit_symbol == NULL || setuid_symbol == NULL || seteuid_symbol == NULL ||
      setgid_symbol == NULL ||
      setegid_symbol == NULL || setreuid_symbol == NULL || setregid_symbol == NULL ||
      setresuid_symbol == NULL || setresgid_symbol == NULL)
    return 10;

  if (pthread_atfork(atfork_probe_prepare_a, atfork_probe_parent_a,
                     atfork_probe_child_a) != 0 ||
      pthread_atfork(atfork_probe_prepare_b, atfork_probe_parent_b,
                     atfork_probe_child_b) != 0)
    return 26;
  pid_t child = fork();
  if (child < 0) return 15;
  if (child == 0) {
    if (atfork_probe_count != 4 || atfork_probe_order[0] != 2 ||
        atfork_probe_order[1] != 1 || atfork_probe_order[2] != 5 ||
        atfork_probe_order[3] != 6)
      _Exit(38);
    _Exit(37);
  }
  int status = 0;
  if (waitpid(child, &status, 0) != child || !WIFEXITED(status) ||
      WEXITSTATUS(status) != 37 || atfork_probe_count != 4 ||
      atfork_probe_order[0] != 2 || atfork_probe_order[1] != 1 ||
      atfork_probe_order[2] != 3 || atfork_probe_order[3] != 4)
    return 16;
  atfork_probe_count = 0;

  child = _Fork();
  if (child < 0) return 39;
  if (child == 0) {
    if (atfork_probe_count != 0) _Exit(40);
    _Exit(41);
  }
  status = 0;
  if (waitpid(child, &status, 0) != child || !WIFEXITED(status) ||
      WEXITSTATUS(status) != 41 || atfork_probe_count != 0)
    return 42;

  if (fcntl(STDOUT_FILENO, F_GETFD) < 0) return 11;
  int large_file_fd = open64("/dev/null", O_RDONLY);
  if (large_file_fd < 0 || close(large_file_fd) != 0) return 22;
  large_file_fd = openat64(AT_FDCWD, "/dev/null", O_RDONLY);
  if (large_file_fd < 0 || close(large_file_fd) != 0) return 23;
  void *large_mapping = mmap64(NULL, 4096, PROT_READ | PROT_WRITE,
                               MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (large_mapping == MAP_FAILED || munmap(large_mapping, 4096) != 0) return 24;
  FILE *offset_file = tmpfile();
  if (offset_file == NULL) return 25;
  int offset_fd = fileno(offset_file);
  const char scalar_write[] = "N";
  char scalar_read = 0;
  struct iovec write_vector = {(void *)"L", 1};
  struct iovec read_vector = {&scalar_read, 1};
  if (offset_fd < 0 || pwrite64(offset_fd, scalar_write, 1, 0) != 1 ||
      pread64(offset_fd, &scalar_read, 1, 0) != 1 || scalar_read != 'N' ||
      pwritev64(offset_fd, &write_vector, 1, 1) != 1 ||
      preadv64(offset_fd, &read_vector, 1, 1) != 1 || scalar_read != 'L' ||
      lseek64(offset_fd, 0, SEEK_SET) != 0 ||
      ftruncate64(offset_fd, 0) != 0 || fclose(offset_file) != 0)
    return 26;
  unsigned char *mapping = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
                                MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (mapping == MAP_FAILED) return 12;
  mapping[0] = 0x5a;
  unsigned char *grown = mremap(mapping, 4096, 8192, MREMAP_MAYMOVE);
  if (grown == MAP_FAILED) {
    munmap(mapping, 4096);
    return 13;
  }
  if (grown[0] != 0x5a || munmap(grown, 8192) != 0) return 14;

  unsigned char *array = reallocarray(NULL, 8, 3);
  if (array == NULL || !nelibc_allocator_owns(array)) return 17;
  for (size_t i = 0; i < 24; ++i) array[i] = (unsigned char)(i + 9);
  unsigned char *larger_array = reallocarray(array, 16, 3);
  if (larger_array == NULL || !nelibc_allocator_owns(larger_array)) return 18;
  for (size_t i = 0; i < 24; ++i)
    if (larger_array[i] != (unsigned char)(i + 9)) return 19;
  errno = 0;
  volatile size_t oversized_count = SIZE_MAX;
  if (reallocarray(larger_array, oversized_count, 2) != NULL || errno != ENOMEM)
    return 20;
  for (size_t i = 0; i < 24; ++i)
    if (larger_array[i] != (unsigned char)(i + 9)) return 21;
  free(larger_array);
  return 0;
}

typedef struct {
  pthread_mutex_t mutex;
  pthread_cond_t condition;
  int ready;
  int go;
} MbrlenThreadGate;

typedef struct {
  MbrlenThreadGate *gate;
  const char *prefix;
  const char *middle;
  const char *last;
  size_t prefix_result;
  size_t middle_result;
  size_t last_result;
} MbrlenThreadProbe;

static void *mbrlen_thread_worker(void *argument) {
  MbrlenThreadProbe *probe = argument;
  probe->prefix_result = mbrlen(probe->prefix, 1, NULL);
  pthread_mutex_lock(&probe->gate->mutex);
  ++probe->gate->ready;
  pthread_cond_broadcast(&probe->gate->condition);
  while (!probe->gate->go)
    pthread_cond_wait(&probe->gate->condition, &probe->gate->mutex);
  pthread_mutex_unlock(&probe->gate->mutex);
  probe->middle_result = mbrlen(probe->middle, 1, NULL);
  if (probe->last != NULL) probe->last_result = mbrlen(probe->last, 1, NULL);
  return NULL;
}

static int mbrlen_thread_isolation(void) {
  if (setlocale(LC_CTYPE, "C.UTF-8") == NULL) return 0;
  MbrlenThreadGate gate = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER, 0, 0};
  MbrlenThreadProbe probes[2] = {
    {&gate, "\xc3", "\xa9", NULL, 0, 0, 0},
    {&gate, "\xe2", "\x82", "\xac", 0, 0, 0}
  };
  pthread_t threads[2];
  if (pthread_create(&threads[0], NULL, mbrlen_thread_worker, &probes[0]) != 0)
    return 1;
  if (pthread_create(&threads[1], NULL, mbrlen_thread_worker, &probes[1]) != 0) {
    pthread_mutex_lock(&gate.mutex);
    gate.go = 1;
    pthread_cond_broadcast(&gate.condition);
    pthread_mutex_unlock(&gate.mutex);
    (void)pthread_join(threads[0], NULL);
    (void)setlocale(LC_CTYPE, "C");
    return 1;
  }
  pthread_mutex_lock(&gate.mutex);
  while (gate.ready != 2)
    pthread_cond_wait(&gate.condition, &gate.mutex);
  gate.go = 1;
  pthread_cond_broadcast(&gate.condition);
  pthread_mutex_unlock(&gate.mutex);
  int failed = 0;
  if (pthread_join(threads[0], NULL) != 0) failed = 1;
  if (pthread_join(threads[1], NULL) != 0) failed = 1;
  if (setlocale(LC_CTYPE, "C") == NULL) failed = 1;
  if (probes[0].prefix_result != (size_t)-2 || probes[0].middle_result != 1 ||
      probes[1].prefix_result != (size_t)-2 || probes[1].middle_result != (size_t)-2 ||
      probes[1].last_result != 1)
    failed = 1;
  return failed;
}

typedef struct {
  unsigned int id;
  int failed;
} AllocThreadProbe;

static void *allocator_thread_worker(void *argument) {
  AllocThreadProbe *probe = argument;
  for (size_t iteration = 0; iteration < 2500; ++iteration) {
    size_t size = 1 + (iteration * 37 + probe->id * 13) % 7000;
    unsigned char *bytes = nelibc_malloc(size);
    if (bytes == NULL) { probe->failed = 1; return NULL; }
    bytes[0] = (unsigned char)probe->id;
    if (size > 1) bytes[size - 1] = 0xa5;
    unsigned char *grown = nelibc_realloc(bytes, size + 1);
    if (grown == NULL) {
      nelibc_free(bytes);
      probe->failed = 2;
      return NULL;
    }
    if (grown[0] != (unsigned char)probe->id ||
        (size > 1 && grown[size - 1] != 0xa5)) {
      nelibc_free(grown);
      probe->failed = 3;
      return NULL;
    }
    nelibc_free(grown);

    /* Exercise concurrent direct-map publication, ownership reads, and free. */
    unsigned char *direct = nelibc_malloc(32768 + probe->id);
    if (direct == NULL || !nelibc_allocator_owns(direct)) {
      nelibc_free(direct);
      probe->failed = 6;
      return NULL;
    }
    direct[0] = (unsigned char)probe->id;
    direct[32767] = 0x5a;
    if (direct[0] != (unsigned char)probe->id || direct[32767] != 0x5a) {
      nelibc_free(direct);
      probe->failed = 7;
      return NULL;
    }
    unsigned char *direct_grown = nelibc_realloc(direct, 65536 + probe->id);
    if (direct_grown == NULL ||
        direct_grown[0] != (unsigned char)probe->id ||
        direct_grown[32767] != 0x5a ||
        !nelibc_allocator_owns(direct_grown)) {
      nelibc_free(direct_grown);
      probe->failed = 8;
      return NULL;
    }
    direct = direct_grown;
    nelibc_free(direct);

    uint32_t *zeroed = nelibc_calloc(4, sizeof *zeroed);
    if (zeroed == NULL) { probe->failed = 4; return NULL; }
    for (size_t index = 0; index < 4; ++index) {
      if (zeroed[index] != 0) {
        nelibc_free(zeroed);
        probe->failed = 5;
        return NULL;
      }
    }
    nelibc_free(zeroed);
  }
  return NULL;
}

static int allocator_thread_isolation(void) {
  for (unsigned int wave = 0; wave < 2; ++wave) {
    pthread_t threads[4];
    AllocThreadProbe probes[4];
    size_t created = 0;
    for (; created < 4; ++created) {
      probes[created].id = (unsigned int)created + 1;
      probes[created].failed = 0;
      if (pthread_create(&threads[created], NULL, allocator_thread_worker,
                         &probes[created]) != 0)
        break;
    }
    int failed = created != 4;
    for (size_t index = 0; index < created; ++index) {
      if (pthread_join(threads[index], NULL) != 0 || probes[index].failed != 0)
        failed = 1;
    }
    if (failed) return 1;
  }
  return 0;
}

typedef struct {
  pthread_mutex_t mutex;
  pthread_cond_t condition;
  int started;
  int stop;
  int failed;
  unsigned long completed;
} ForkStressState;

static void fork_stress_fail(ForkStressState *state, int error) {
  pthread_mutex_lock(&state->mutex);
  if (state->failed == 0) state->failed = error;
  pthread_cond_broadcast(&state->condition);
  pthread_mutex_unlock(&state->mutex);
}

static void *fork_allocator_stdio_worker(void *argument) {
  ForkStressState *state = argument;
  pthread_mutex_lock(&state->mutex);
  state->started = 1;
  pthread_cond_signal(&state->condition);
  pthread_mutex_unlock(&state->mutex);

  for (size_t iteration = 0;; ++iteration) {
    pthread_mutex_lock(&state->mutex);
    int stop = state->stop;
    pthread_mutex_unlock(&state->mutex);
    if (stop) break;

    size_t size = 32 + iteration % 4096;
    unsigned char *memory = malloc(size);
    if (memory == NULL) {
      fork_stress_fail(state, 1);
      break;
    }
    memory[0] = (unsigned char)iteration;
    unsigned char *grown = realloc(memory, size + 17);
    if (grown == NULL || grown[0] != (unsigned char)iteration) {
      free(grown != NULL ? grown : memory);
      fork_stress_fail(state, 2);
      break;
    }
    free(grown);

    FILE *stream = tmpfile();
    if (stream == NULL) {
      fork_stress_fail(state, 3);
      break;
    }
    const char record[] = "fork with active stdio";
    char readback[sizeof record];
    int io_ok = fwrite(record, 1, sizeof record, stream) == sizeof record &&
        fflush(stream) == 0 && fseek(stream, 0, SEEK_SET) == 0 &&
        fread(readback, 1, sizeof readback, stream) == sizeof readback &&
        memcmp(record, readback, sizeof record) == 0;
    if (fclose(stream) != 0) io_ok = 0;
    if (!io_ok) {
      fork_stress_fail(state, 4);
      break;
    }
    pthread_mutex_lock(&state->mutex);
    ++state->completed;
    pthread_cond_signal(&state->condition);
    pthread_mutex_unlock(&state->mutex);
  }
  return NULL;
}

static int fork_allocator_stdio_stress(const char *self_path) {
  ForkStressState state = {PTHREAD_MUTEX_INITIALIZER,
                           PTHREAD_COND_INITIALIZER, 0, 0, 0, 0};
  pthread_t worker;
  if (pthread_create(&worker, NULL, fork_allocator_stdio_worker, &state) != 0)
    return 1;
  pthread_mutex_lock(&state.mutex);
  while (!state.started) pthread_cond_wait(&state.condition, &state.mutex);
  pthread_mutex_unlock(&state.mutex);

  char *child_arguments[] = {(char *)self_path,
                             (char *)"--fork-exec-stdio-probe", NULL};
  int result = 0;
  for (int iteration = 0; iteration < 32; ++iteration) {
    pthread_mutex_lock(&state.mutex);
    while (state.completed <= (unsigned long)iteration && state.failed == 0)
      pthread_cond_wait(&state.condition, &state.mutex);
    if (state.failed != 0) result = 5;
    pthread_mutex_unlock(&state.mutex);
    if (result != 0) break;

    pid_t child = fork();
    if (child == 0) {
      execve(self_path, child_arguments, environ);
      _Exit(90);
    }
    if (child < 0) {
      result = 2;
      break;
    }
    int status = 0;
    pid_t waited;
    do {
      waited = waitpid(child, &status, 0);
    } while (waited < 0 && errno == EINTR);
    if (waited != child || !WIFEXITED(status) || WEXITSTATUS(status) != 0) {
      result = 3;
      break;
    }
  }

  for (int iteration = 0; result == 0 && iteration < 4; ++iteration) {
    pthread_mutex_lock(&state.mutex);
    unsigned long next_cycle = state.completed + 1;
    while (state.completed < next_cycle && state.failed == 0)
      pthread_cond_wait(&state.condition, &state.mutex);
    if (state.failed != 0) result = 5;
    pthread_mutex_unlock(&state.mutex);
    if (result != 0) break;
    int shell_status = system("exit 0");
    if (shell_status == -1 || !WIFEXITED(shell_status) ||
        WEXITSTATUS(shell_status) != 0)
      result = 6;
  }

  pthread_mutex_lock(&state.mutex);
  state.stop = 1;
  pthread_cond_signal(&state.condition);
  pthread_mutex_unlock(&state.mutex);
  if (pthread_join(worker, NULL) != 0 || state.failed != 0) result = 4;
  pthread_cond_destroy(&state.condition);
  pthread_mutex_destroy(&state.mutex);
  return result;
}

static void *concurrent_system_worker(void *unused) {
  (void)unused;
  int status = system("sleep 0.02; kill -INT $PPID; exit 0");
  return (void *)(uintptr_t)(status == -1 || !WIFEXITED(status) || WEXITSTATUS(status) != 0);
}

#endif

static void *cancelled_system_worker(void *unused) {
  (void)unused;
  (void)system("exec sleep 5");
  return NULL;
}

static int tempfile_probe(void) {
  char invalid[] = "/tmp/nelibc-invalid-XXXXXXx";
  char plain[] = "/tmp/nelibc-mkstemp-XXXXXX";
  char suffix[] = "/tmp/nelibc-mkstemps-XXXXXX.txt";
  char append[] = "/tmp/nelibc-mkostemp-XXXXXX";
  char append_suffix[] = "/tmp/nelibc-mkostemps-XXXXXX.log";
  char directory[] = "/tmp/nelibc-mkdtemp-XXXXXX";
  char script[] = "/tmp/nelibc-execvp-XXXXXX";
  struct stat state;
  int descriptor = -1;
  int created_plain = 0;
  int created_suffix = 0;
  int created_append = 0;
  int created_append_suffix = 0;
  int created_directory = 0;
  int created_script = 0;
  int result = 0;
  char byte = 'N';

  errno = 0;
  if (mkstemp(invalid) != -1 || errno != EINVAL ||
      strcmp(invalid, "/tmp/nelibc-invalid-XXXXXXx") != 0) {
    result = 1;
    goto done;
  }
  descriptor = mkstemp(plain);
  if (descriptor < 0) { result = 2; goto done; }
  created_plain = 1;
  if (fstat(descriptor, &state) != 0 || (state.st_mode & 0077) != 0 ||
      write(descriptor, &byte, 1) != 1 || lseek(descriptor, 0, SEEK_SET) != 0 ||
      read(descriptor, &byte, 1) != 1 || byte != 'N') {
    result = 3;
    goto done;
  }
  if (close(descriptor) != 0) { descriptor = -1; result = 4; goto done; }
  descriptor = -1;

  descriptor = mkstemps(suffix, 4);
  if (descriptor < 0) { result = 5; goto done; }
  created_suffix = 1;
  if (strcmp(suffix + strlen(suffix) - 4, ".txt") != 0 ||
      fstat(descriptor, &state) != 0 || (state.st_mode & 0077) != 0) {
    result = 6;
    goto done;
  }
  if (close(descriptor) != 0) { descriptor = -1; result = 7; goto done; }
  descriptor = -1;

  descriptor = mkostemp(append, O_APPEND | O_CLOEXEC);
  if (descriptor < 0) { result = 8; goto done; }
  created_append = 1;
  if ((fcntl(descriptor, F_GETFL) & O_APPEND) == 0 ||
      (fcntl(descriptor, F_GETFD) & FD_CLOEXEC) == 0) {
    result = 9;
    goto done;
  }
  if (close(descriptor) != 0) { descriptor = -1; result = 10; goto done; }
  descriptor = -1;

  /* The GNU form accepts the same extra open flags with a preserved suffix. */
  descriptor = mkostemps(append_suffix, 4, O_CLOEXEC);
  if (descriptor < 0) { result = 11; goto done; }
  created_append_suffix = 1;
  if (strcmp(append_suffix + strlen(append_suffix) - 4, ".log") != 0 ||
      (fcntl(descriptor, F_GETFD) & FD_CLOEXEC) == 0) {
    result = 12;
    goto done;
  }
  if (close(descriptor) != 0) { descriptor = -1; result = 13; goto done; }
  descriptor = -1;

  if (mkdtemp(directory) == NULL) { result = 14; goto done; }
  created_directory = 1;
  if (stat(directory, &state) != 0 || !S_ISDIR(state.st_mode) ||
      (state.st_mode & 0077) != 0) result = 15;
  descriptor = mkstemp(script);
  if (descriptor < 0) { result = 16; goto done; }
  created_script = 1;
  static const char script_body[] = "exit 37\n";
  if (write(descriptor, script_body, sizeof script_body - 1) !=
          (ssize_t)(sizeof script_body - 1) || fchmod(descriptor, 0700) != 0 ||
      close(descriptor) != 0) {
    descriptor = -1;
    result = 17;
    goto done;
  }
  descriptor = -1;
  pid_t script_child = fork();
  if (script_child < 0) { result = 18; goto done; }
  if (script_child == 0) {
    char *script_arguments[] = {script, NULL};
    execvp(script, script_arguments);
    _Exit(127);
  }
  int script_status = 0;
  if (waitpid(script_child, &script_status, 0) != script_child ||
      !WIFEXITED(script_status) || WEXITSTATUS(script_status) != 37) result = 19;

done:
  if (descriptor >= 0) close(descriptor);
  if (created_plain) unlink(plain);
  if (created_suffix) unlink(suffix);
  if (created_append) unlink(append);
  if (created_append_suffix) unlink(append_suffix);
  if (created_directory) rmdir(directory);
  if (created_script) unlink(script);
  return result;
}

static int byte_order_probe(void) {
  for (uint32_t value = 0; value <= UINT16_MAX; ++value) {
    uint16_t expected = (uint16_t)((value << 8) | (value >> 8));
    if (htons((uint16_t)value) != expected ||
        ntohs(expected) != (uint16_t)value || ntohs(htons((uint16_t)value)) != value)
      return 1;
  }
  uint32_t value = 0x12345678U;
  for (unsigned int i = 0; i < 10000; ++i) {
    uint32_t expected = ((value & 0x000000ffU) << 24) |
        ((value & 0x0000ff00U) << 8) | ((value & 0x00ff0000U) >> 8) |
        ((value & 0xff000000U) >> 24);
    if (htonl(value) != expected || ntohl(expected) != value ||
        ntohl(htonl(value)) != value) return 2;
    value = value * 1664525U + 1013904223U;
  }
  return 0;
}

static int inet_conversion_probe(void) {
  static const struct {
    int family;
    const char *input;
    const char *canonical;
  } valid[] = {
    {AF_INET, "192.0.2.1", "192.0.2.1"},
    {AF_INET, "0.0.0.0", "0.0.0.0"},
    {AF_INET6, "::", "::"},
    {AF_INET6, "::1", "::1"},
    {AF_INET6, "2001:0DB8:0:0:0:0:0:1", "2001:db8::1"},
    {AF_INET6, "2001:db8:0:1:1:1:1:1", "2001:db8:0:1:1:1:1:1"},
    {AF_INET6, "1:0:0:2:0:0:3:4", "1::2:0:0:3:4"},
    {AF_INET6, "::ffff:192.0.2.1", "::ffff:192.0.2.1"},
    {AF_INET6, "1:2:3:4:5:6:192.0.2.1", "1:2:3:4:5:6:c000:201"},
  };
  unsigned char address[16];
  char text[INET6_ADDRSTRLEN];
  for (size_t i = 0; i < sizeof valid / sizeof valid[0]; ++i) {
    if (inet_pton(valid[i].family, valid[i].input, address) != 1 ||
        inet_ntop(valid[i].family, address, text, sizeof text) == NULL ||
        strcmp(text, valid[i].canonical) != 0) return 1;
  }
  struct in_addr legacy_address;
  if (inet_aton("203.0.113.7", &legacy_address) != 1 ||
      inet_addr("203.0.113.7") != legacy_address.s_addr ||
      strcmp(inet_ntoa(legacy_address), "203.0.113.7") != 0) return 8;
  struct in_addr unchanged = legacy_address;
  if (inet_aton("203.0.113.999", &legacy_address) != 0 ||
      legacy_address.s_addr != unchanged.s_addr ||
      inet_addr("203.0.113.999") != INADDR_NONE) return 9;
  if (inet_addr("255.255.255.255") != INADDR_BROADCAST) return 10;
  /* inet_aton(3) grammar: one to four parts, each decimal, 0x hex or 0 octal. */
  static const struct { const char *text; uint32_t host_order; } classic[] = {
    {"1.2.0x33.4", 0x01023304u}, {"1.2.0XAB.4", 0x0102ab04u},
    {"1.2.0xabcd", 0x0102abcdu}, {"1.0xabcdef", 0x01abcdefu},
    {"00377.0x0ff.65534", 0xfffffffeu}, {"0x7f000001", 0x7f000001u},
    {"127.1", 0x7f000001u}, {"0", 0u}, {"1.2.3.04", 0x01020304u},
    {"4294967295", 0xffffffffu},
  };
  for (size_t i = 0; i < sizeof classic / sizeof classic[0]; ++i) {
    uint32_t expected = htonl(classic[i].host_order);
    if (inet_aton(classic[i].text, &legacy_address) != 1 ||
        legacy_address.s_addr != expected) return 11;
    if (classic[i].host_order != 0xffffffffu && inet_addr(classic[i].text) != expected)
      return 11;
  }
  static const char *const classic_invalid[] = {
    "1.2.3.4.5", "1.2.3.256", "0x", "1.2.3.4x", "1..3", "256.1", "1.0x1000000",
    "4294967296", "", " 1.2.3.4", "1.2.3.4 ", "0x1g",
  };
  for (size_t i = 0; i < sizeof classic_invalid / sizeof classic_invalid[0]; ++i)
    if (inet_addr(classic_invalid[i]) != INADDR_NONE ||
        inet_aton(classic_invalid[i], &legacy_address) != 0) return 12;
  /* inet_pton(3) stays dotted-decimal and refuses leading zeros. */
  static const char *const pton_invalid[] = {"1.2.03.4", "01.2.3.4", "1.2.3.004", "0x1.2.3.4", "127.1"};
  for (size_t i = 0; i < sizeof pton_invalid / sizeof pton_invalid[0]; ++i)
    if (inet_pton(AF_INET, pton_invalid[i], address) != 0) return 13;
  if (inet_pton(AF_INET6, "::012.34.56.78", address) != 0 ||
      inet_pton(AF_INET6, "::ffff:1.2.03.4", address) != 0) return 14;
  static const char *const invalid_v4[] = {
    "", ".1.2.3", "1.2.3", "1.2.3.256", "1.2.3.4.", "1..3.4", "1.2.3.4x"
  };
  for (size_t i = 0; i < sizeof invalid_v4 / sizeof invalid_v4[0]; ++i)
    if (inet_pton(AF_INET, invalid_v4[i], address) != 0) return 2;
  static const char *const invalid_v6[] = {
    "", ":1", "1:", ":::1", "1::2::3", "1:2:3:4:5:6:7",
    "1:2:3:4:5:6:7:8:9", "12345::1", "::ffff:192.0.2.256", "fe80::1%lo"
  };
  for (size_t i = 0; i < sizeof invalid_v6 / sizeof invalid_v6[0]; ++i)
    if (inet_pton(AF_INET6, invalid_v6[i], address) != 0) return 3;
  errno = 0;
  if (inet_pton(AF_UNIX, "127.0.0.1", address) != -1 || errno != EAFNOSUPPORT)
    return 4;
  if (inet_pton(AF_UNIX, "::1", address) != -1 || errno != EAFNOSUPPORT)
    return 5;
  errno = 0;
  if (inet_ntop(AF_INET, address, text, 4) != NULL || errno != ENOSPC) return 6;
  errno = 0;
  if (inet_ntop(AF_UNIX, address, text, sizeof text) != NULL || errno != EAFNOSUPPORT)
    return 7;
  return 0;
}

/* strptime %z: "+hh", "+hhmm", "+hh:mm" and "Z" (RFC 3339), as glibc reads them. */
static int timezone_parse_probe(void) {
  struct tm parsed;
  static const struct { const char *text; long offset; } zones[] = {
    {"-06", -6 * 3600}, {"+0530", 5 * 3600 + 30 * 60},
    {"-06:30", -(6 * 3600 + 30 * 60)}, {"+00", 0}, {"Z", 0}, {"+2359", 23 * 3600 + 59 * 60},
  };
  for (size_t i = 0; i < sizeof zones / sizeof zones[0]; ++i) {
    memset(&parsed, 0, sizeof parsed);
    const char *end = strptime(zones[i].text, "%z", &parsed);
    if (end == NULL || *end != 0 || parsed.tm_gmtoff != zones[i].offset) return (int)i + 1;
  }
  static const char *const rejected[] = {"-6", "+06:", "+24", "+0660", "06", "", "+1:30", "+06:3"};
  for (size_t i = 0; i < sizeof rejected / sizeof rejected[0]; ++i) {
    memset(&parsed, 0, sizeof parsed);
    if (strptime(rejected[i], "%z", &parsed) != NULL) return 10 + (int)i;
  }
  return 0;
}

/* 32 and 33 are the libc's internal realtime signals; sets never carry them. */
static int signal_set_internal_probe(void) {
  sigset_t set;
  if (sigemptyset(&set) != 0) return 1;
  errno = 0;
  if (sigaddset(&set, 32) != -1 || errno != EINVAL) return 2;
  errno = 0;
  if (sigaddset(&set, 33) != -1 || errno != EINVAL) return 3;
  if (sigismember(&set, 33) != 0) return 4;
  if (sigfillset(&set) != 0 || sigismember(&set, 32) != 0 || sigismember(&set, 33) != 0 ||
      sigismember(&set, SIGUSR1) != 1 || sigismember(&set, 34) != 1 ||
      sigismember(&set, 64) != 1) return 5;
  if (sigdelset(&set, 33) != 0 || sigdelset(&set, 34) != 0 || sigismember(&set, 34) != 0) return 6;
  return 0;
}

/* POSIX.1-2008 locale-object string functions and strsignal. */
static int string_locale_object_probe(void) {
  locale_t c_locale = newlocale(LC_ALL_MASK, "C", (locale_t)0);
  if (c_locale == (locale_t)0) return 1;
  if (strcasecmp_l("Nelua", "nELUA", c_locale) != 0 ||
      strcasecmp_l("abc", "abd", c_locale) >= 0 ||
      strncasecmp_l("ABCdef", "abcXYZ", 3, c_locale) != 0 ||
      strncasecmp_l("ABCdef", "abcXYZ", 4, c_locale) >= 0) return 2;
  if (strcoll_l("apple", "banana", c_locale) >= 0 ||
      strcoll_l("same", "same", c_locale) != 0) return 3;
  char transformed[16];
  if (strxfrm_l(transformed, "abc", sizeof transformed, c_locale) != 3 ||
      strcmp(transformed, "abc") != 0) return 4;
  if (strcmp(strerror_l(ENOENT, c_locale), strerror(ENOENT)) != 0) return 5;
  freelocale(c_locale);
  if (strcmp(strsignal(SIGINT), "Interrupt") != 0 ||
      strcmp(strsignal(SIGSEGV), "Segmentation fault") != 0 ||
      strcmp(strsignal(SIGSYS), "Bad system call") != 0 ||
      strcmp(strsignal(34), "Real-time signal 0") != 0 ||
      strcmp(strsignal(64), "Real-time signal 30") != 0 ||
      strcmp(strsignal(0), "Unknown signal 0") != 0 ||
      strcmp(strsignal(33), "Unknown signal 33") != 0 ||
      strcmp(strsignal(-7), "Unknown signal -7") != 0 ||
      strcmp(strsignal(65), "Unknown signal 65") != 0) return 6;
  return 0;
}

/* musl libc-test functional/strftime: POSIX flags, widths and the + sign on
 * wide years, plus the ISO week of a day early in January. */
static int strftime_check(const char *format, const struct tm *value, const char *expected) {
  char text[100];
  size_t length = strftime(text, sizeof text, format, value);
  if (length == 0) return expected[0] != 0;
  return strcmp(text, expected) != 0;
}

static int strftime_posix_probe(void) {
  struct tm y2016 = {.tm_sec = 45, .tm_min = 23, .tm_hour = 13, .tm_mday = 3, .tm_mon = 0,
                     .tm_year = 2016 - 1900, .tm_wday = 0, .tm_yday = 2};
  struct tm y10009 = {.tm_sec = 53, .tm_min = 17, .tm_hour = 5, .tm_mday = 5, .tm_mon = 0,
                      .tm_year = 10009 - 1900, .tm_wday = 1, .tm_yday = 4};
  struct tm y0 = {.tm_hour = 12, .tm_mday = 23, .tm_mon = 1, .tm_year = 0 - 1900,
                  .tm_wday = 3, .tm_yday = 53};
  struct tm yneg = {.tm_mday = 1, .tm_mon = 0, .tm_year = -123 - 1900, .tm_wday = 1, .tm_yday = 0};
  struct tm ymax = {.tm_mday = 1, .tm_mon = 0, .tm_year = INT_MAX, .tm_wday = 3, .tm_yday = 0};
  if (strftime_check("%c", &y2016, "Sun Jan  3 13:23:45 2016") ||
      strftime_check("%c", &y10009, "Mon Jan  5 05:17:53 +10009") ||
      strftime_check("%c", &y0, "Wed Feb 23 12:00:00 0000")) return 1;
  if (strftime_check("%C", &y2016, "20") || strftime_check("%03C", &y2016, "020") ||
      strftime_check("%+3C", &y2016, "+20") || strftime_check("%C", &y10009, "100") ||
      strftime_check("%C", &y0, "00") || strftime_check("%01C", &y0, "0")) return 2;
  if (strftime_check("%F", &y2016, "2016-01-03") || strftime_check("%012F", &y2016, "002016-01-03") ||
      strftime_check("%+10F", &y2016, "2016-01-03") || strftime_check("%+11F", &y2016, "+2016-01-03") ||
      strftime_check("%F", &y10009, "+10009-01-05") || strftime_check("%011F", &y10009, "10009-01-05") ||
      strftime_check("%F", &y0, "0000-02-23") || strftime_check("%01F", &y0, "0-02-23") ||
      strftime_check("%06F", &y0, "0-02-23") || strftime_check("%010F", &y0, "0000-02-23") ||
      strftime_check("%F", &yneg, "-123-01-01") || strftime_check("%011F", &yneg, "-0123-01-01")) return 3;
  if (strftime_check("%g", &y2016, "15") || strftime_check("%g", &y10009, "09") ||
      strftime_check("%G", &y2016, "2015") || strftime_check("%+5G", &y2016, "+2015") ||
      strftime_check("%04G", &y10009, "10009")) return 4;
  if (strftime_check("%U", &y2016, "01") || strftime_check("%U", &y10009, "01") ||
      strftime_check("%U", &y0, "08") || strftime_check("%V", &y2016, "53") ||
      strftime_check("%V", &y10009, "02") || strftime_check("%V", &y0, "08") ||
      strftime_check("%W", &y2016, "00") || strftime_check("%W", &y10009, "01") ||
      strftime_check("%W", &y0, "08")) return 5;
  if (strftime_check("%Y", &y2016, "2016") || strftime_check("%05Y", &y2016, "02016") ||
      strftime_check("%+4Y", &y2016, "2016") || strftime_check("%+5Y", &y2016, "+2016") ||
      strftime_check("%Y", &y10009, "+10009") || strftime_check("%05Y", &y10009, "10009") ||
      strftime_check("%Y", &y0, "0000") || strftime_check("%02Y", &y0, "00") ||
      strftime_check("%+5Y", &y0, "+0000") || strftime_check("%Y", &yneg, "-123") ||
      strftime_check("%+4Y", &yneg, "-123") || strftime_check("%+5Y", &yneg, "-0123") ||
      strftime_check("%y", &ymax, "47") || strftime_check("%Y", &ymax, "+2147485547") ||
      strftime_check("%011Y", &ymax, "02147485547")) return 6;
  /* GNU/BSD padding flags on the plain numeric directives. */
  if (strftime_check("%-d|%_d|%0e|%-j|%_j|%-H", &y2016, "3| 3|03|3|  3|13") ||
      strftime_check("%s", &y2016, "1451827425") || strftime_check("%s", &y10009, "253686748673")) return 7;
  return 0;
}

/* musl libc-test functional/fnmatch: a backslash inside brackets is a
 * member, and a '[' that opens no bracket expression matches itself. */
static int fnmatch_bracket_probe(void) {
  if (fnmatch("[[?*\\]", "\\", 0) != 0 || fnmatch("[]?*\\]", "]", 0) != 0 ||
      fnmatch("[/b", "[/b", 0) != 0 || fnmatch("[/b", "/b", 0) != FNM_NOMATCH) return 1;
  if (fnmatch("[\\]", "\\", 0) != 0 || fnmatch("[\\]x", "\\x", 0) != 0 ||
      fnmatch("[a-c]", "b", 0) != 0 || fnmatch("[!a-c]", "b", 0) != FNM_NOMATCH ||
      fnmatch("[[:alpha:]]", "q", 0) != 0 || fnmatch("[[:bogus:]]", "[", 0) != FNM_NOMATCH ||
      fnmatch("*[![:digit:]]*/[[:d-d]", "a/[", FNM_PATHNAME) != FNM_NOMATCH) return 2;
  return 0;
}

/* strtold and friends: "0x" without hex digits is the number 0 ending at
 * the 'x'; nan(n-char-sequence) keeps a numeric payload and consumes the
 * parentheses only for letters, digits and '_'; and %Lg of an unnormal
 * prints the sign of its own bits. Expected values are glibc 2.36's. */
static int strtod_special_probe(void) {
  static const struct { const char *text; long consumed; uint16_t se; uint64_t m; } ld[] = {
    { "0x", 1, 0, 0 }, { "0x.", 1, 0, 0 }, { "0xp1", 1, 0, 0 }, { "-0x", 2, 0x8000, 0 }, { "0x 1", 1, 0, 0 },
    { "0x1p1", 5, 0x4000, 0x8000000000000000ULL }, { "0x.8", 4, 0x3ffe, 0x8000000000000000ULL },
    { "nan(12)", 7, 0x7fff, 0xc00000000000000cULL }, { "nan(1-)", 3, 0x7fff, 0xc000000000000000ULL },
    { "-nan(0x7)", 9, 0xffff, 0xc000000000000007ULL }, { "nan(abc_9)", 10, 0x7fff, 0xc000000000000000ULL },
    { "nan()", 5, 0x7fff, 0xc000000000000000ULL }, { "nan(08)", 7, 0x7fff, 0xc000000000000000ULL },
    { "nan(010)", 8, 0x7fff, 0xc000000000000008ULL },
  };
  for (size_t i = 0; i < sizeof ld / sizeof ld[0]; i++) {
    char *end;
    union { long double f; struct { uint64_t m; uint16_t se; } i; } u;
    u.f = strtold(ld[i].text, &end);
    if (end - ld[i].text != ld[i].consumed || u.i.se != ld[i].se || u.i.m != ld[i].m) return 1 + (int)i;
  }
  char *end;
  double d;
  const char *hx = "0xg";
  d = strtod(hx, &end);
  if (d != 0 || end != hx + 1) return 20;
  union { double f; uint64_t b; } ud;
  ud.f = strtod("nan(12)", NULL);
  if (ud.b != 0x7ff800000000000cULL) return 21;
  union { float f; uint32_t b; } uf;
  uf.f = strtof("nan(12)", NULL);
  if (uf.b != 0x7fc0000cU) return 22;
  uf.f = strtof("-nan(0x3fffff)", NULL);
  if (uf.b != 0xffffffffU) return 23;
  union { long double f; struct { uint64_t m; uint16_t se; } i; } u;
  char text[64];
  u.i.m = 0x0706050403020100ULL; u.i.se = 0x0908;
  if (snprintf(text, sizeof text, "%Lg|%Lf|%Le|%La", u.f, u.f, u.f, u.f) < 0 || strcmp(text, "nan|nan|nan|nan") != 0) return 24;
  u.i.se = 0x8908;
  if (snprintf(text, sizeof text, "%Lg|%Lf|%Le|%La", u.f, u.f, u.f, u.f) < 0 || strcmp(text, "-nan|-nan|-nan|-nan") != 0) return 25;
  u.i.m = 0; u.i.se = 0x7fff;
  if (snprintf(text, sizeof text, "%Lg", u.f) < 0 || strcmp(text, "nan") != 0) return 26;
  return 0;
}

/* Widths and precisions up to INT_MAX, as glibc allows: %e of a double past
 * 18 digits takes the exact binary80 path, long zero tails stream out, and
 * values beyond INT_MAX are EOVERFLOW. Expected strings are glibc 2.36's. */
static int printf_precision_probe(void) {
  char text[256];
  if (snprintf(text, sizeof text, "%.19e|%.25e|%.20E|%.19e|%.19e", 1.0, 0.5, -2.0, 0.0, -0.0) < 0 ||
      strcmp(text, "1.0000000000000000000e+00|5.0000000000000000000000000e-01|-2.00000000000000000000E+00|"
                   "0.0000000000000000000e+00|-0.0000000000000000000e+00") != 0) return 1;
  if (snprintf(text, sizeof text, "%.30e|%26.19e|%-26.19e|", 0.1, 3.0, 3.0) < 0 ||
      strcmp(text, "1.000000000000000055511151231258e-01| 3.0000000000000000000e+00|"
                   "3.0000000000000000000e+00 |") != 0) return 2;
  if (snprintf(text, sizeof text, "%.20000g", 0.1) < 0 ||
      strcmp(text, "0.1000000000000000055511151231257827021181583404541015625") != 0) return 3;
  char *big = malloc(400000);
  if (big == NULL) return 4;
  int n = snprintf(big, 400000, "%.200000f", 1.0);
  if (n != 200002 || strncmp(big, "1.000", 5) != 0 || big[n - 1] != '0') { free(big); return 5; }
  n = snprintf(big, 400000, "%.200000e", 1.0);
  if (n != 200006 || strcmp(big + n - 4, "e+00") != 0 || big[n - 5] != '0') { free(big); return 6; }
  n = snprintf(big, 400000, "%#.20000g", 1.0);
  if (n != 20001 || big[1] != '.' || big[n - 1] != '0') { free(big); return 7; }
  n = snprintf(big, 400000, "%.20000Le", 1.0L / 3.0L);
  if (n != 20006 || strncmp(big, "3.33333333333333333342", 22) != 0 || strcmp(big + n - 4, "e-01") != 0) { free(big); return 8; }
  n = snprintf(big, 400000, "%.300a|%150000d|", 1.0, 7);
  if (n != 307 + 1 + 150000 + 1 || strncmp(big, "0x1.000", 7) != 0 || strncmp(big + 304, "p+0|", 4) != 0 ||
      big[n - 2] != '7' || big[n - 3] != ' ') { free(big); return 9; }
  free(big);
  errno = 0;
  if (snprintf(text, sizeof text, "%2147483648d", 1) != -1 || errno != EOVERFLOW) return 10;
  errno = 0;
  if (snprintf(text, sizeof text, "%.2147483648f", 1.0) != -1 || errno != EOVERFLOW) return 11;
  errno = 0;
  if (snprintf(text, sizeof text, "%*d", INT_MIN, 1) != -1 || errno != EOVERFLOW) return 12;
  return 0;
}

/* %La on x87 long double, including the encodings the FPU never makes
 * (musl libc-test regression/fpclassify-invalid-ld80); %Lf for values that
 * are doubles; %Ld as glibc reads it. */
static int long_double_format_probe(void) {
  char text[128];
  union { long double f; struct { uint64_t m; uint16_t se; } i; } u;
  if (snprintf(text, sizeof text, "%La", 1.0L) < 0 || strcmp(text, "0x1p+0") != 0) return 1;
  if (snprintf(text, sizeof text, "%La|%.1La|%.0La|%LA", 1.5L, 0x1.08p+3L, 1.5L, -2.0L) < 0 ||
      strcmp(text, "0x1.8p+0|0x1.0p+3|0x2p+0|-0X1P+1") != 0) return 2;
  if (snprintf(text, sizeof text, "%La", 0x1.0000000000000002p-16382L) < 0 ||
      strcmp(text, "0x1.0000000000000002p-16382") != 0) return 3;
  u.f = 0; u.i.m = (uint64_t)1 << 63;
  if (snprintf(text, sizeof text, "%La", u.f) < 0 || strcmp(text, "0x1p-16382") != 0) return 4;
  u.i.m++;
  if (snprintf(text, sizeof text, "%La", u.f) < 0 || strcmp(text, "0x1.0000000000000002p-16382") != 0) return 5;
  u.f = 1; u.i.m = 0;
  if (snprintf(text, sizeof text, "%La", u.f) < 0 || strcmp(text, "nan") != 0) return 6;
  long double infinite = strtold("inf", NULL);
  u.f = infinite; u.i.m = 0;
  if (snprintf(text, sizeof text, "%La", u.f) < 0 || strcmp(text, "nan") != 0) return 7;
  if (snprintf(text, sizeof text, "%La|%La", 0.0L, infinite) < 0 || strcmp(text, "0x0p+0|inf") != 0) return 8;
  if (snprintf(text, sizeof text, "%Lf|%.3Le|%Lg|%Ld|%Lu", 1.5L, 1234.5L, 0.25L, -7LL, 9ULL) < 0 ||
      strcmp(text, "1.500000|1.234e+03|0.25|-7|9") != 0) return 9;
  /* '#': %#X prints 0X, and %#a without a precision keeps the exact digits
   * (trailing zeros dropped) with the radix character, as C requires. */
  if (snprintf(text, sizeof text, "%#X|%#x|%#X|%#a|%#La|%#a|%#.0a|%#.2a|%#8X", 255u, 255u, 0u, 1.0, 0.0L, 0.5, 1.0,
               1.0, 10u) < 0 ||
      strcmp(text, "0XFF|0xff|0|0x1.p+0|0x0.p+0|0x1.p-1|0x1.p+0|0x1.00p+0|     0XA") != 0) return 13;
  /* The '0' flag does not apply to inf and nan: they pad with spaces. */
  if (snprintf(text, sizeof text, "%06f|%#06g|%-06e|%+08a|%06LG|%06.2f", strtod("inf", NULL), strtod("-inf", NULL),
               strtod("nan", NULL), strtod("inf", NULL), strtold("inf", NULL), 1.5) < 0 ||
      strcmp(text, "   inf|  -inf|nan   |    +inf|   INF|001.50") != 0) return 14;
  /* Values that are not doubles take the exact binary80 decimal path; the
   * expected strings are glibc 2.36's output for the same calls. */
  static const struct { const char *format; long double value; const char *want; } exact[] = {
    { "%Lf", 1.0L / 3.0L, "0.333333" },
    { "%.25Lf", 1.0L / 3.0L, "0.3333333333333333333423684" },
    { "%.20Le", 1.0L / 3.0L, "3.33333333333333333342e-01" },
    { "%Lg", 1.0L / 3.0L, "0.333333" },
    { "%.30Lg", 0.1L, "0.100000000000000000001355252716" },
    { "%Lg", 1e4000L, "1e+4000" },
    { "%Le", 0x1p-16445L, "3.645200e-4951" },
    { "%.3Le", 0x1p-16445L, "3.645e-4951" },
    { "%.62Lf", 1.0L + 0x1p-63L, "1.00000000000000000010842021724855044340074528008699417114257812" },
    { "%.61Lf", 1.0L + 0x1p-63L, "1.0000000000000000001084202172485504434007452800869941711425781" },
    { "%.62Lf", 1.0L + 0x3p-63L, "1.00000000000000000032526065174565133020223584026098251342773438" },
    { "%Lf", -1e-4000L, "-0.000000" },
    { "%LG", 1e-4000L, "1E-4000" },
    { "%LE", 12345.678L, "1.234568E+04" },
    { "%+15.3Le", 2.0L / 3.0L, "     +6.667e-01" },
    { "%-12.2Lf|", -2.0L / 3.0L, "-0.67       |" },
    { "%012.4Lf", 2.0L / 3.0L, "0000000.6667" },
    { "%#.0Lf", 0x1.4000000000000002p+1L, "3." },
    { "%.0Le", 9.5L + 0x1p-60L, "1e+01" },
    { "%#Lg", 1.0L / 3.0L, "0.333333" },
    { "%Lg", 123456789.0L / 7.0L, "1.76367e+07" },
    { "%Lg", 1e-5L / 3.0L, "3.33333e-06" },
    { "%.0Lg", 0.0001L / 3.0L, "3e-05" },
    { "% .3Lf", 1e20L / 3.0L, " 33333333333333333334.000" },
    { "%.10Lg", 9.9999999999L + 0x1p-50L, "10" },
    { "%.40Le", 1.18973149535723176502e+4932L, "1.1897314953572317650212638530309702051691e+4932" },
    { "%Lg", 0x1p-16382L, "3.3621e-4932" },
  };
  for (size_t index = 0; index < sizeof exact / sizeof exact[0]; ++index) {
    if (snprintf(text, sizeof text, exact[index].format, exact[index].value) < 0 ||
        strcmp(text, exact[index].want) != 0) {
      fprintf(stderr, "long double %s: got [%s] want [%s]\n", exact[index].format, text, exact[index].want);
      return 10;
    }
  }
  /* The sign comes from the sign bit: -0.0 and a negative NaN keep their
   * minus sign (glibc 2.36 output). */
  volatile double negative_zero = -0.0;
  volatile double negative_nan = -strtod("nan", NULL);
  if (snprintf(text, sizeof text, "%f|%.1e|%g|%f|%Lf", negative_zero, negative_zero,
               negative_zero, negative_nan, -0.0L) < 0 ||
      strcmp(text, "-0.000000|-0.0e+00|-0|-nan|-0.000000") != 0) {
    fprintf(stderr, "signed zero: got [%s]\n", text);
    return 12;
  }
  static char huge[8192];
  int huge_length = snprintf(huge, sizeof huge, "%Lf", 1.18973149535723176502e+4932L);
  if (huge_length != 4940 || strncmp(huge, "1189731495357231765021263853030970205169", 40) != 0 ||
      strcmp(huge + 4933, ".000000") != 0) return 11;
  return 0;
}

static int malloc_usable_size_probe(void) {
  if (malloc_usable_size(NULL) != 0) return 1;
  char *block = malloc(100);
  if (block == NULL) return 2;
  size_t usable = malloc_usable_size(block);
  if (usable < 100 || usable > 100 + 65536) return 3;
  memset(block, 0x5a, usable);
  char *grown = realloc(block, 3000);
  if (grown == NULL) return 4;
  if (malloc_usable_size(grown) < 3000) return 5;
  free(grown);
  return 0;
}

/* 1 when wordexp returns other than want_ret or, on success, words other
 * than want (each word followed by '|'). */
static int wordexp_check(const char *words, int flags, int want_ret, const char *want) {
  wordexp_t we;
  int r = wordexp(words, &we, flags);
  if (r != want_ret) {
    fprintf(stderr, "wordexp(\"%s\", %d) returned %d, want %d\n", words, flags, r, want_ret);
    return 1;
  }
  if (r != 0) return 0;
  char joined[256] = "";
  size_t used = 0;
  for (size_t i = 0; i < we.we_wordc && used < sizeof joined; i++)
    used += (size_t)snprintf(joined + used, sizeof joined - used, "%s|", we.we_wordv[i]);
  int bad = we.we_wordv[we.we_wordc] != NULL || strcmp(joined, want) != 0;
  if (bad) fprintf(stderr, "wordexp(\"%s\", %d) gave [%s], want [%s]\n", words, flags, joined, want);
  wordfree(&we);
  return bad;
}

static int wordexp_probe(void) {
  if (setenv("WEXP_PROBE", "a b", 1) != 0 || unsetenv("WEXP_UNSET_PROBE") != 0) return 1;
  if (wordexp_check("one 'two three'", 0, 0, "one|two three|") ||
      wordexp_check("$WEXP_PROBE", 0, 0, "a|b|") ||
      wordexp_check("\"$WEXP_PROBE\"", 0, 0, "a b|") ||
      wordexp_check("$((2*21))", WRDE_NOCMD, 0, "42|") ||
      wordexp_check("$(echo hi)", 0, 0, "hi|") ||
      wordexp_check("\"${WEXP_PROBE%'b'}\"", WRDE_NOCMD, 0, "a |")) return 2;
  if (wordexp_check("$(echo x)", WRDE_NOCMD, WRDE_CMDSUB, "") ||
      wordexp_check("`echo x`", WRDE_NOCMD, WRDE_CMDSUB, "") ||
      wordexp_check("a;b", WRDE_NOCMD, WRDE_BADCHAR, "") ||
      wordexp_check("'unterminated", 0, WRDE_SYNTAX, "")) return 3;
  wordexp_t we;
  we.we_offs = 2;
  if (wordexp("x y", &we, WRDE_DOOFFS) != 0 || we.we_wordc != 2 || we.we_wordv[0] != NULL ||
      we.we_wordv[1] != NULL || strcmp(we.we_wordv[2], "x") != 0 ||
      strcmp(we.we_wordv[3], "y") != 0 || we.we_wordv[4] != NULL) return 4;
  if (wordexp("z", &we, WRDE_DOOFFS | WRDE_APPEND) != 0 || we.we_wordc != 3 ||
      we.we_wordv[1] != NULL || strcmp(we.we_wordv[4], "z") != 0 || we.we_wordv[5] != NULL) return 5;
  if (wordexp("q", &we, WRDE_REUSE) != 0 || we.we_wordc != 1 || we.we_offs != 0 ||
      strcmp(we.we_wordv[0], "q") != 0 || we.we_wordv[1] != NULL) return 6;
  wordfree(&we);
#if defined(NELIBC_STANDALONE) || defined(__GLIBC__)
  /* musl ignores WRDE_UNDEF and rejects the last two as WRDE_BADCHAR */
  if (wordexp_check("$WEXP_UNSET_PROBE", WRDE_UNDEF, WRDE_BADVAL, "") ||
      wordexp_check("${WEXP_PROBE#a }", WRDE_NOCMD, 0, "b|") ||
      wordexp_check("$((case x in x) echo a;; esac) )", WRDE_NOCMD, WRDE_CMDSUB, "")) return 7;
#endif
#ifdef NELIBC_STANDALONE
  /* glibc has no $'...' and no comments, stops at the case pattern's ")",
   * and takes $1 and $# from the program's argv; musl from its own shell. */
  if (wordexp_check("$# $1", 0, 0, "0|") ||
      wordexp_check("$'a\\tb' x #(y", WRDE_NOCMD, 0, "a\tb|x|") ||
      wordexp_check("$'\\''$(echo bad)", WRDE_NOCMD, WRDE_CMDSUB, "") ||
      wordexp_check("${X-\"$\"{A}B}", WRDE_NOCMD, WRDE_BADCHAR, "") ||
      wordexp_check("$(case a in a) echo x;; esac)", 0, 0, "x|") ||
      wordexp_check("$( (case a in (a) echo $'y\\'z';; esac) )", 0, 0, "y'z|")) return 8;
#endif
  return 0;
}

#ifdef NELIBC_STANDALONE
/* Each expected result was produced by musl 1.2.5's crypt_r. glibc 2.36's
 * libcrypt gives the same hashes except where marked: "glibc *0" is its
 * failure result, which it also gives instead of musl's "*" and "x". */
static const char *const crypt_probe_cases[][3] = {
  {"password", "ab", "abJnggxhB/yWI"},
  {"\x80\xff high", "\x80x", "\x80xO5uqMD4k/lI"},              /* glibc *0 */
  {"a", "*", "x"},                                             /* glibc *0 */
  {"a", "", "*"},                                              /* glibc *0 */
  {"a", "a\n", "*"},                                           /* glibc *0 */
  {"U*U*U*U*", "_J9..CCCC", "_J9..CCCCXBrJUJV154M"},
  {"a long key past eight bytes", "_J9..CCCC", "_J9..CCCCq1nBFqQozg."},
  {"x", "_....", "*"},                                         /* glibc *0 */
  {"x", "_J9..CC!C", "*"},                                     /* glibc *0 */
  {"password", "$1$saltsaltsalt", "$1$saltsalt$qjXMvbEw8oaL.CzflDtaK/"},
  {"password", "$5$rounds=1000$saltsalt$", "$5$rounds=1000$saltsalt$azOwbpkvuuBKkE82dQPwTsQE8JyT9Fflpr9aKid3aT9"},
  /* glibc *0: */
  {"password", "$5$rounds=10$saltsalt", "$5$rounds=1000$saltsalt$azOwbpkvuuBKkE82dQPwTsQE8JyT9Fflpr9aKid3aT9"},
  /* glibc accepts 10000000 rounds: */
  {"password", "$5$rounds=10000000$saltsalt$", "*"},
  {"password", "$5$rounds=1234saltsalt", "*"},                 /* glibc *0 */
  {"password", "$5$sa:lt$", "*"},                              /* glibc *0 */
  {"password", "$6$rounds=1000$saltsalt$", "$6$rounds=1000$saltsalt$Z/J9iYO1iE9xnr8JPQL57ZWsVRtVjrUv3CiWc/wKWseqXgSqn3HFYJ/Ng7YXa8XlLj.wpdAwHOJJzuGFqBBRa0"},
  /* glibc *0: */
  {"password", "$6$rounds=01000$saltsaltsaltsaltsalt$", "$6$rounds=1000$saltsaltsaltsalt$3.brVxJ/6VAQv6Cd3dm5xeNUkjPvlI9Eao6nz5O6JfSs2klDra/PNNFRXvu4MBsuD1w4JnIFFHaBvPRi2HqVn1"},
  {"\xa3password", "$2a$05$abcdefghijklmnopqrstuu", "$2a$05$abcdefghijklmnopqrstuunrqu/sPNnUA2w92pmdMVy0k67Hopucy"},
  {"\xa3password", "$2b$05$abcdefghijklmnopqrstuu", "$2b$05$abcdefghijklmnopqrstuunrqu/sPNnUA2w92pmdMVy0k67Hopucy"},
  {"\xa3password", "$2x$05$abcdefghijklmnopqrstuu", "$2x$05$abcdefghijklmnopqrstuuRjJ9MMIx8tBIXJ4aVZU6ZceZ0BW7E9a"},
  {"\xa3password", "$2y$05$abcdefghijklmnopqrstuv", "$2y$05$abcdefghijklmnopqrstuunrqu/sPNnUA2w92pmdMVy0k67Hopucy"},
  /* the $2a$ countermeasure: same key, different hash from $2b$ */
  {"\xff\xa3" "34" "\xff\xff\xff\xa3" "345", "$2a$04$abcdefghijklmnopqrstuu", "$2a$04$abcdefghijklmnopqrstuuE8Lpo1/qkGPTBDBxEsJjeEzh9nkZ9uW"},
  {"\xff\xa3" "34" "\xff\xff\xff\xa3" "345", "$2b$04$abcdefghijklmnopqrstuu", "$2b$04$abcdefghijklmnopqrstuu9f4sA9SRA0scUKcRyC5kce8dao2.GKe"},
  {"password", "$2a$03$abcdefghijklmnopqrstuu", "*"},          /* glibc *0 */
  {"password", "$2c$05$abcdefghijklmnopqrstuu", "*"},          /* glibc *0 */
  {"password", "$2a$05$abcdefghijklmnopqrst!u", "*"},          /* glibc *0 */
  /* not a bcrypt prefix: DES with salt "$2" (glibc *0) */
  {"password", "$2$05$abcdefghijklmnopqrstuu", "$2mV0NZp92R3g"},
};

static int crypt_probe(void) {
  struct crypt_data data;
  for (size_t i = 0; i < sizeof crypt_probe_cases / sizeof crypt_probe_cases[0]; i++) {
    const char *key = crypt_probe_cases[i][0], *setting = crypt_probe_cases[i][1];
    const char *want = crypt_probe_cases[i][2];
    char *r = crypt_r(key, setting, &data);
    if (r == NULL || strcmp(r, want) != 0) {
      fprintf(stderr, "crypt_r case %zu (\"%s\") gave \"%s\", want \"%s\"\n", i, setting, r ? r : "(null)", want);
      return 1;
    }
    r = crypt(key, setting);
    if (r == NULL || strcmp(r, want) != 0) {
      fprintf(stderr, "crypt case %zu (\"%s\") gave \"%s\", want \"%s\"\n", i, setting, r ? r : "(null)", want);
      return 2;
    }
  }
  /* A successful hash is written into the caller's buffer. */
  if (crypt_r("password", "ab", &data) != (char *)&data) return 3;
  /* FIPS 46 test vector: key 133457799BBCDFF1, block 0123456789ABCDEF. */
  char key[64], block[64];
  unsigned long long k = 0x133457799BBCDFF1ULL, p = 0x0123456789ABCDEFULL, c;
  for (int i = 0; i < 64; i++) { key[i] = k >> (63 - i) & 1; block[i] = p >> (63 - i) & 1; }
  setkey(key);
  encrypt(block, 0);
  c = 0;
  for (int i = 0; i < 64; i++) c = c << 1 | (unsigned char)block[i];
  if (c != 0x85E813540F0AB405ULL) return 4;
  encrypt(block, 1);
  c = 0;
  for (int i = 0; i < 64; i++) c = c << 1 | (unsigned char)block[i];
  if (c != p) return 5;
  return 0;
}
#endif

int main(int argc, char **argv) {
  int byte_order_result = byte_order_probe();
  if (byte_order_result != 0) return 640 + byte_order_result;
  int inet_result = inet_conversion_probe();
  if (inet_result != 0) return 650 + inet_result;
  int timezone_result = timezone_parse_probe();
  if (timezone_result != 0) return 660 + timezone_result;
  int signal_set_result = signal_set_internal_probe();
  if (signal_set_result != 0) return 680 + signal_set_result;
  int string_locale_result = string_locale_object_probe();
  if (string_locale_result != 0) return 690 + string_locale_result;
  int strftime_posix_result = strftime_posix_probe();
  if (strftime_posix_result != 0) return 700 + strftime_posix_result;
  int fnmatch_bracket_result = fnmatch_bracket_probe();
  if (fnmatch_bracket_result != 0) return 710 + fnmatch_bracket_result;
  int long_double_format_result = long_double_format_probe();
  if (long_double_format_result != 0) return 720 + long_double_format_result;
  {
    /* An unknown conversion is copied out as text (glibc 2.36); a format that
     * ends inside a directive is still an error. %#.0f keeps the radix
     * character for doubles past 2^64 too. */
    char unknown_text[96];
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat"
#pragma GCC diagnostic ignored "-Wformat-extra-args"
    if (snprintf(unknown_text, sizeof unknown_text, "[%-5.3.4d][%y][%5]", 7) != 18 ||
        strcmp(unknown_text, "[%-5.3.4d][%y][%5]") != 0) return 782;
    if (snprintf(unknown_text, sizeof unknown_text, "ab%") != -1) return 783;
    if (snprintf(unknown_text, sizeof unknown_text, "[%#.0f|%#.0f|%#.0f|%.0f]", 18446744073709551616.0, 1e20, 3.0, 1e20) != 71 ||
        strcmp(unknown_text, "[18446744073709551616.|100000000000000000000.|3.|100000000000000000000]") != 0) return 784;
#pragma GCC diagnostic pop
  }
  errno = 0;
  if (execvp("", (char *[]){"", 0}) != -1 || errno != ENOENT) return 780;
  /* The last representable local year west of UTC: the UTC instant is already
   * in year INT_MAX + 1901, which only the DST rule lookup needs (glibc 2.36
   * gives tm_year INT_MAX, 18:00 Dec 31 in New York). */
  {
    setenv("TZ", "EST5EDT,M3.2.0,M11.1.0", 1);
    tzset();
    time_t last = (time_t)67768036191676799LL;
    struct tm *lt = localtime(&last);
    if (lt == NULL || lt->tm_year != 2147483647 || lt->tm_mon != 11 || lt->tm_mday != 31 ||
        lt->tm_hour != 18) return 781;
    unsetenv("TZ");
    tzset();
  }
  int strtod_special_result = strtod_special_probe();
  if (strtod_special_result != 0) return 760 + strtod_special_result;
  int printf_precision_result = printf_precision_probe();
  if (printf_precision_result != 0) return 740 + printf_precision_result;
  int malloc_usable_size_result = malloc_usable_size_probe();
  if (malloc_usable_size_result != 0) return 730 + malloc_usable_size_result;
  int wordexp_result = wordexp_probe();
  if (wordexp_result != 0) return 790 + wordexp_result;
#ifdef NELIBC_STANDALONE
  int crypt_result = crypt_probe();
  if (crypt_result != 0) return 800 + crypt_result;
#endif
  int locale_float_parser_result = locale_float_parser_probe();
  if (locale_float_parser_result != 0) return 89 + locale_float_parser_result;
  void *minimal_aligned = memalign(1, 17);
  if (minimal_aligned == NULL || (uintptr_t)minimal_aligned % sizeof(void *) != 0)
    return 82;
  free(minimal_aligned);
  void *legacy_aligned = memalign(128, 257);
  if (legacy_aligned == NULL || (uintptr_t)legacy_aligned % 128 != 0)
    return 84;
  free(legacy_aligned);
  char format_count_buffer[32];
  int format_count = -1;
  if (snprintf(format_count_buffer, sizeof format_count_buffer,
               "prefix%n-suffix", &format_count) != 13 || format_count != 6 ||
      strcmp(format_count_buffer, "prefix-suffix") != 0) return 553;
  if (allocator_probe() != 0) return 83;
  int semaphore_result = semaphore_clock_probe();
  if (semaphore_result != 0) return 85 + semaphore_result;
  int tempfile_result = tempfile_probe();
  if (tempfile_result != 0) return 570 + tempfile_result;
  int getdate_result = getdate_probe();
  if (getdate_result != 0) return 580 + getdate_result;
  int utimes_result = utimes_probe();
  if (utimes_result != 0) return 590 + utimes_result;
  int futimes_result = futimes_probe();
  if (futimes_result != 0) return 600 + futimes_result;
  int futimesat_result = futimesat_probe();
  if (futimesat_result != 0) return 610 + futimesat_result;
  int lutimes_result = lutimes_probe();
  if (lutimes_result != 0) return 620 + lutimes_result;
  int utime_result = utime_probe();
  if (utime_result != 0) return 630 + utime_result;
  char cwd_buffer[4096];
  if (getcwd(cwd_buffer, sizeof cwd_buffer) == NULL) return 20;
  char *allocated_cwd = get_current_dir_name();
  if (allocated_cwd == NULL || strcmp(allocated_cwd, cwd_buffer) != 0) return 21;
  free(allocated_cwd);
  struct rlimit descriptor_limit;
  if (getrlimit(RLIMIT_NOFILE, &descriptor_limit) != 0 ||
      getdtablesize() != (int)descriptor_limit.rlim_cur) return 30;
  if (usleep(1000) != 0) return 31;
  errno = 0;
  if (usleep(1000000) != -1 || errno != EINVAL) return 32;
  struct itimerval timer = {{0, 0}, {60, 0}};
  struct itimerval previous_timer;
  if (setitimer(ITIMER_REAL, &timer, &previous_timer) != 0) return 33;
  struct itimerval observed_timer;
  if (getitimer(ITIMER_REAL, &observed_timer) != 0 ||
      observed_timer.it_value.tv_sec < 1 || observed_timer.it_value.tv_sec > 60)
    return 34;
  if (ualarm(0, 0) > 60000000U) return 35;
  if (getitimer(ITIMER_REAL, &observed_timer) != 0 ||
      observed_timer.it_value.tv_sec != 0 || observed_timer.it_value.tv_usec != 0)
    return 36;
  if (ualarm(60000000U, 0) != 0) return 37;
  unsigned int previous_alarm = ualarm(0, 0);
  if (previous_alarm < 50000000U || previous_alarm > 60000000U) return 38;
  int poll_pipe[2];
  if (pipe(poll_pipe) != 0 || write(poll_pipe[1], "p", 1) != 1) return 39;
  struct pollfd poll_entry = {poll_pipe[0], POLLIN, 0};
  struct timespec poll_timeout = {5, 123456789};
  sigset_t poll_mask;
  if (sigemptyset(&poll_mask) != 0 ||
      ppoll(&poll_entry, 1, &poll_timeout, &poll_mask) != 1 ||
      (poll_entry.revents & POLLIN) == 0 || poll_timeout.tv_sec != 5 ||
      poll_timeout.tv_nsec != 123456789) return 40;
  fd_set pselect_readfds;
  FD_ZERO(&pselect_readfds);
  FD_SET(poll_pipe[0], &pselect_readfds);
  struct timespec pselect_timeout = {5, 123456789};
  if (pselect(poll_pipe[0] + 1, &pselect_readfds, NULL, NULL,
              &pselect_timeout, &poll_mask) != 1 ||
      !FD_ISSET(poll_pipe[0], &pselect_readfds) ||
      pselect_timeout.tv_sec != 5 || pselect_timeout.tv_nsec != 123456789)
    return 41;
  close(poll_pipe[0]);
  close(poll_pipe[1]);
  struct sigevent posix_timer_event = {0};
  posix_timer_event.sigev_notify = SIGEV_NONE;
  timer_t posix_timer;
  if (timer_create(CLOCK_MONOTONIC, &posix_timer_event, &posix_timer) != 0)
    return 42;
  struct itimerspec posix_timer_value = {{0, 0}, {60, 0}};
  struct itimerspec observed_posix_timer;
  if (timer_settime(posix_timer, 0, &posix_timer_value, NULL) != 0 ||
      timer_gettime(posix_timer, &observed_posix_timer) != 0 ||
      observed_posix_timer.it_value.tv_sec < 1 ||
      observed_posix_timer.it_value.tv_sec > 60 ||
      timer_getoverrun(posix_timer) != 0)
    return 43;
  if (timer_delete(posix_timer) != 0) return 44;
  int timer_descriptor = timerfd_create(CLOCK_MONOTONIC,
                                        TFD_NONBLOCK | TFD_CLOEXEC);
  if (timer_descriptor < 0 ||
      (fcntl(timer_descriptor, F_GETFL) & O_NONBLOCK) == 0 ||
      (fcntl(timer_descriptor, F_GETFD) & FD_CLOEXEC) == 0) return 42;
  struct itimerspec descriptor_timer = {{0, 0}, {60, 0}};
  if (timerfd_settime(timer_descriptor, 0, &descriptor_timer, NULL) != 0)
    return 43;
  struct itimerspec observed_descriptor_timer;
  if (timerfd_gettime(timer_descriptor, &observed_descriptor_timer) != 0 ||
      observed_descriptor_timer.it_value.tv_sec < 1 ||
      observed_descriptor_timer.it_value.tv_sec > 60) return 44;
  descriptor_timer.it_value.tv_sec = 0;
  if (timerfd_settime(timer_descriptor, 0, &descriptor_timer, NULL) != 0 ||
      timerfd_gettime(timer_descriptor, &observed_descriptor_timer) != 0 ||
      observed_descriptor_timer.it_value.tv_sec != 0 ||
      observed_descriptor_timer.it_value.tv_nsec != 0) return 45;
  close(timer_descriptor);
  sigset_t signalfd_mask, previous_signal_mask;
  if (sigemptyset(&signalfd_mask) != 0 ||
      sigaddset(&signalfd_mask, SIGUSR1) != 0 ||
      sigprocmask(SIG_BLOCK, &signalfd_mask, &previous_signal_mask) != 0)
    return 46;
  int signal_descriptor = signalfd(-1, &signalfd_mask,
                                   SFD_NONBLOCK | SFD_CLOEXEC);
  if (signal_descriptor < 0 ||
      (fcntl(signal_descriptor, F_GETFL) & O_NONBLOCK) == 0 ||
      (fcntl(signal_descriptor, F_GETFD) & FD_CLOEXEC) == 0 ||
      raise(SIGUSR1) != 0) return 47;
  struct signalfd_siginfo received_signal;
  ssize_t signal_bytes = read(signal_descriptor, &received_signal,
                              sizeof received_signal);
  close(signal_descriptor);
  if (sigprocmask(SIG_SETMASK, &previous_signal_mask, NULL) != 0 ||
      signal_bytes != sizeof received_signal ||
      received_signal.ssi_signo != SIGUSR1) return 48;
  const unsigned char swab_source[] = {1, 2, 3, 4, 5};
  unsigned char swab_destination[] = {9, 9, 9, 9, 9};
  swab(swab_source, swab_destination, 5);
  if (swab_destination[0] != 2 || swab_destination[1] != 1 ||
      swab_destination[2] != 4 || swab_destination[3] != 3 ||
      swab_destination[4] != 9) return 22;
  volatile ssize_t negative_swab_count = -1;
  swab(swab_source, swab_destination, negative_swab_count);
  if (swab_destination[4] != 9) return 23;
#ifndef NELIBC_STANDALONE
  if (archive_unistd_adapter_probe() != 0) return 84;
  if (pthread_protocol_probe() != 0) return 86;
  if (pthread_sigmask_probe() != 0) return 87;
#endif
  if (ffs(0) != 0 || ffsl(0) != 0 || ffsll(0) != 0 ||
      ffs(-1) != 1 || ffsl(-1L) != 1 || ffsll(-1LL) != 1)
    return 38;
  for (int bit = 0; bit < (int)(sizeof(int) * CHAR_BIT); ++bit)
    if (ffs((int)(1U << bit)) != bit + 1) return 39;
  for (int bit = 0; bit < (int)(sizeof(long) * CHAR_BIT); ++bit)
    if (ffsl((long)(1UL << bit)) != bit + 1) return 40;
  for (int bit = 0; bit < (int)(sizeof(long long) * CHAR_BIT); ++bit)
    if (ffsll((long long)(1ULL << bit)) != bit + 1) return 41;
  char error_text[64];
  char short_error_text[2] = {'x', 'y'};
  if (nelibc_strerror_r(2, error_text, sizeof error_text) != 0 ||
      strcmp(error_text, "No such file or directory") != 0 ||
      nelibc_strerror_r(2, short_error_text, sizeof short_error_text) != ERANGE ||
      short_error_text[0] != 'x' || short_error_text[1] != 'y' ||
      nelibc_strerror_r(41, error_text, sizeof error_text) != EINVAL)
    return 36;
#if defined(NELIBC_STANDALONE) || defined(__GLIBC__)
  char *gnu_error_text = strerror_r(2, error_text, sizeof error_text);
  char *gnu_short_error_text = strerror_r(2, short_error_text, sizeof short_error_text);
  if (gnu_error_text == NULL ||
      strcmp(gnu_error_text, "No such file or directory") != 0 ||
      gnu_short_error_text == NULL ||
      strcmp(gnu_short_error_text, "No such file or directory") != 0)
    return 42;
#else
  if (strerror_r(2, error_text, sizeof error_text) != 0 ||
      strcmp(error_text, "No such file or directory") != 0)
    return 42;
#endif
#if defined(NELIBC_STATIC_MUSL)
  if (nelibc_test_standard_strerror_r(2, error_text, sizeof error_text) != 0 ||
      strcmp(error_text, "No such file or directory") != 0)
    return 43;
#endif
  unsigned int rand_r_seed = 0x12345678U;
  unsigned int rand_r_seed_copy = rand_r_seed;
  int rand_r_first = rand_r(&rand_r_seed);
  int rand_r_second = rand_r(&rand_r_seed);
  if (rand_r_first != 477687324 || rand_r_seed_copy != 0x12345678U ||
      rand_r(&rand_r_seed_copy) != rand_r_first || rand_r_seed_copy != 2441007757U ||
      rand_r_second != 1388675377 || rand_r_seed != 281628322U)
    return 37;
  if (argc == 2 && strcmp(argv[1], "--verify-unsetenv") == 0) {
    const char *preserved = getenv("NELIBC_KEEP");
    return getenv("NELIBC_CONSUMER_SETENV_PROBE") == NULL && preserved != NULL &&
           strcmp(preserved, "present") == 0 ? 0 : 9;
  }
  if (argc == 2 && strcmp(argv[1], "--verify-execvpe") == 0)
    return getenv("NELIBC_EXEC_PROBE") != NULL &&
           strcmp(getenv("NELIBC_EXEC_PROBE"), "yes") == 0 ? 0 : 10;
  if (argc == 2 && strcmp(argv[1], "--verify-fexecve") == 0)
    return getenv("NELIBC_FEXEC_PROBE") != NULL &&
           strcmp(getenv("NELIBC_FEXEC_PROBE"), "yes") == 0 ? 0 : 11;
  if (argc == 2 && strcmp(argv[1], "--fork-exec-stdio-probe") == 0) {
    unsigned char *memory = malloc(257);
    if (memory == NULL) return 12;
    memset(memory, 0x5a, 257);
    FILE *stream = tmpfile();
    if (stream == NULL) { free(memory); return 13; }
    const char record[] = "post-fork exec stdio probe";
    char readback[sizeof record];
    int ok = fwrite(record, 1, sizeof record, stream) == sizeof record &&
        fflush(stream) == 0 && fseek(stream, 0, SEEK_SET) == 0 &&
        fread(readback, 1, sizeof readback, stream) == sizeof readback &&
        memcmp(record, readback, sizeof record) == 0;
    if (fclose(stream) != 0) ok = 0;
    free(memory);
    return ok ? 0 : 14;
  }

  const char input[] = "Nelua libc";
  if (strcasestr(input, "LIBC") != &input[6] ||
      strcasestr(input, "") != input || strcasestr(input, "missing") != NULL)
    return 86;
  if (strchrnul(input, 'l') != &input[2] ||
      strchrnul(input, 'x') != &input[sizeof input - 1] ||
      strchrnul(input, 0) != &input[sizeof input - 1] ||
      strchrnul(input, 0x16c) != &input[2]) return 85;
  char copy[sizeof input];
  memcpy(copy, input, sizeof input);
  if (strlen(copy) != sizeof input - 1 || strcmp(copy, input) != 0) return 1;
  char overlap_copy[] = "abcdefg";
  bcopy(overlap_copy, overlap_copy + 1, 6);
  if (memcmp(overlap_copy, "aabcdef", 7) != 0) return 42;
  char overlap_copy_back[] = "abcdefg";
  bcopy(overlap_copy_back + 1, overlap_copy_back, 6);
  if (memcmp(overlap_copy_back, "bcdefg", 6) != 0) return 43;
  char zeroed[9] = "12345678";
  bzero(zeroed, sizeof zeroed);
  for (size_t zero_index = 0; zero_index < sizeof zeroed; ++zero_index)
    if (zeroed[zero_index] != 0) return 44;
  if (bcmp("equal", "equal", 5) != 0 || bcmp("same", "same", 0) != 0 ||
      bcmp("left", "lest", 4) == 0)
    return 45;
  unsigned char secret_bytes[] = {0xa5, 0x5a, 0xff, 0x81, 0x00};
  explicit_bzero(secret_bytes, sizeof secret_bytes);
  for (size_t secret_index = 0; secret_index < sizeof secret_bytes; ++secret_index)
    if (secret_bytes[secret_index] != 0) return 87;
  const char indexed_bytes[] = {'a', (char)0xff, 'b', 'a', 0};
  if (index(indexed_bytes, 0xff) != &indexed_bytes[1] ||
      rindex(indexed_bytes, 'a') != &indexed_bytes[3] ||
      rindex(indexed_bytes, 0) != &indexed_bytes[4] ||
      index(indexed_bytes, 'z') != NULL)
    return 46;
  wchar_t wide_memory[] = {L'A', 0x100, L'Z', 0};
  wchar_t wide_copy[4] = {0};
  if (wmemcpy(wide_copy, wide_memory, 4) != wide_copy ||
      wmemcmp(wide_copy, wide_memory, 4) != 0 ||
      wmemchr(wide_copy, 0x100, 4) != &wide_copy[1] ||
      wmemchr(wide_copy, L'?', 4) != NULL)
    return 47;
  wmemmove(wide_copy + 1, wide_copy, 3);
  if (wide_copy[0] != L'A' || wide_copy[1] != L'A' || wide_copy[2] != 0x100 ||
      wide_copy[3] != L'Z' || wmemcmp(wide_copy + 1, wide_memory, 3) != 0)
    return 48;
  if (wmemset(wide_copy, 0x1234, 4) != wide_copy)
    return 49;
  for (size_t wide_index = 0; wide_index < 4; ++wide_index)
    if (wide_copy[wide_index] != 0x1234) return 50;
  const wchar_t wide_text[] = {L'A', 0x100, L'B', 0};
  const wchar_t wide_text_less[] = {L'A', 0xff, L'B', 0};
  wchar_t wide_string[16] = {0};
  if (wcslen(wide_text) != 3 || wcscmp(wide_text, wide_text) != 0 ||
      wcscmp(wide_text, wide_text_less) <= 0 ||
      wcsncmp(wide_text, wide_text_less, 1) != 0 ||
      wcsncmp(wide_text, wide_text_less, 2) <= 0 ||
      wcsncmp(wide_text, wide_text_less, 0) != 0)
    return 51;
  if (wcschr(wide_text, 0x100) != &wide_text[1] ||
      wcschr(wide_text, 0) != &wide_text[3] ||
      wcschr(wide_text, L'X') != NULL ||
      wcsrchr(wide_text, L'A') != &wide_text[0] ||
      wcsrchr(wide_text, 0) != &wide_text[3] ||
      wcsrchr(wide_text, L'X') != NULL)
    return 52;
  if (wcscpy(wide_string, wide_text) != wide_string ||
      wcscmp(wide_string, wide_text) != 0 ||
      wcscat(wide_string, L"!") != wide_string ||
      wcslen(wide_string) != 4 || wide_string[3] != L'!')
    return 53;
  for (size_t wide_index = 0; wide_index < 8; ++wide_index) wide_string[wide_index] = 0x777;
  if (wcsncpy(wide_string, L"xy", 5) != wide_string ||
      wide_string[0] != L'x' || wide_string[1] != L'y' ||
      wide_string[2] != 0 || wide_string[3] != 0 || wide_string[4] != 0 ||
      wide_string[5] != 0x777)
    return 54;
  wcscpy(wide_string, L"Q");
  if (wcsncat(wide_string, wide_text, 2) != wide_string ||
      wide_string[0] != L'Q' || wide_string[1] != L'A' ||
      wide_string[2] != 0x100 || wide_string[3] != 0 ||
      wcsncat(wide_string, L"ignored", 0) != wide_string || wide_string[3] != 0)
    return 55;
  const wchar_t scan_text[] = L"wide text";
  if (wcsspn(L"  wide", L" ") != 2 ||
      wcscspn(L"wide text", L"tx") != 5 ||
      wcscspn(L"wide", L"") != 4 ||
      wcspbrk(scan_text, L"tx") != &scan_text[5] ||
      wcspbrk(L"wide", L"xyz") != NULL)
    return 56;
  wchar_t token_text[] = L"  alpha beta gamma  ";
  token_text[7] = 0x100;
  const wchar_t token_delimiters[] = {L' ', 0x100, 0};
  wchar_t *token_state = NULL;
  if (wcscmp(wcstok(token_text, token_delimiters, &token_state), L"alpha") != 0 ||
      wcscmp(wcstok(NULL, token_delimiters, &token_state), L"beta") != 0 ||
      wcscmp(wcstok(NULL, token_delimiters, &token_state), L"gamma") != 0 ||
      wcstok(NULL, token_delimiters, &token_state) != NULL)
    return 57;
  wchar_t wide_haystack[] = {L'x', L'x', 0x100, L'y', L'z', 0};
  const wchar_t wide_needle[] = {0x100, L'y', 0};
  if (wcsnlen(wide_haystack, 0) != 0 || wcsnlen(wide_haystack, 2) != 2 ||
      wcsnlen(wide_haystack, 6) != 5 ||
      wcsstr(wide_haystack, wide_needle) != &wide_haystack[2] ||
      wcsstr(wide_haystack, L"") != wide_haystack ||
      wcsstr(wide_haystack, L"xyz") != NULL)
    return 58;
  wchar_t *wide_duplicate = wcsdup(wide_haystack);
  if (wide_duplicate == NULL || wcscmp(wide_duplicate, wide_haystack) != 0) return 59;
  wide_duplicate[0] = L'Q';
  if (wide_haystack[0] != L'x') {
    free(wide_duplicate);
    return 60;
  }
  free(wide_duplicate);
  wchar_t *wide_end = NULL;
  const wchar_t wide_hex[] = L" -0x2aTail";
  errno = 0;
  if (wcstol(wide_hex, &wide_end, 0) != -42 || wide_end != &wide_hex[6] || errno != 0)
    return 61;
  wchar_t wide_formatted[32] = {0};
  int wide_output_count = -1;
  if (swprintf(wide_formatted, 32, L"%ls:%d:%c%n", L"wide", 17, L'Q',
               &wide_output_count) != 9) return 93;
  if (wcscmp(wide_formatted, L"wide:17:Q") != 0 || wide_output_count != 9) return 94;
  if (call_vswprintf(wide_formatted, 32, L"x%03d", 7) != 4 ||
      wcscmp(wide_formatted, L"x007") != 0) return 95;
  const wchar_t wide_binary[] = L"0b101!";
  if (nelibc_test_legacy_wcstol(wide_binary, &wide_end, 0) != 0 ||
      wide_end != &wide_binary[1]) return 74;
  if (__isoc23_wcstol(wide_binary, &wide_end, 0) != 5 ||
      wide_end != &wide_binary[5]) return 75;
  if (nelibc_test_legacy_wcstol(wide_binary, &wide_end, 2) != 0 ||
      wide_end != &wide_binary[1]) return 78;
  if (__isoc23_wcstol(wide_binary, &wide_end, 2) != 5 ||
      wide_end != &wide_binary[5]) return 79;
  errno = 0;
  if (wcstoll(L"-9223372036854775808!", &wide_end, 10) != LLONG_MIN ||
      *wide_end != L'!' || errno != 0)
    return 62;
  errno = 0;
  if (wcstoul(L"-1!", &wide_end, 10) != ULONG_MAX || *wide_end != L'!' || errno != 0)
    return 63;
  errno = 0;
  if (wcstoull(L"0xffffffffffffffff!", &wide_end, 0) != ULLONG_MAX ||
      *wide_end != L'!' || errno != 0)
    return 64;
  if (wcstoimax(L"-9223372036854775808!", &wide_end, 10) != INTMAX_MIN ||
      *wide_end != L'!' || errno != 0)
    return 80;
  if (wcstod(L" -12.5e2tail", &wide_end) != -1250.0 || *wide_end != L't')
    return 87;
  if (wcstof(L"0.125!", &wide_end) != 0.125f || *wide_end != L'!') return 88;
  if (wcstold(L"3.5x", &wide_end) != 3.5L || *wide_end != L'x') return 89;
  const wchar_t wide_invalid_float[] = L"+Q";
  errno = 0;
  if (wcstod(wide_invalid_float, &wide_end) != 0.0 ||
      wide_end != wide_invalid_float || errno != 0)
    return 90;
  if (wcstoumax(L"0xffffffffffffffff!", &wide_end, 0) != UINTMAX_MAX ||
      *wide_end != L'!' || errno != 0)
    return 81;
  if (__isoc23_wcstoimax(L"0b101!", &wide_end, 0) != 5 || *wide_end != L'!')
    return 85;
  if (__isoc23_wcstoumax(L"0B101!", &wide_end, 0) != 5 || *wide_end != L'!')
    return 86;
  imaxdiv_t wide_division = imaxdiv(-17, 5);
  if (wide_division.quot != -3 || wide_division.rem != -2 || imaxabs(-42) != 42)
    return 84;
  if (__isoc23_wcstol(L"0b101!", &wide_end, 0) != 5 || *wide_end != L'!')
    return 68;
  if (__isoc23_wcstoll(L"0B1001!", &wide_end, 0) != 9 || *wide_end != L'!')
    return 69;
  if (__isoc23_wcstoul(L"0b101!", &wide_end, 0) != 5 || *wide_end != L'!')
    return 70;
  if (__isoc23_wcstoull(L"0B1001!", &wide_end, 0) != 9 || *wide_end != L'!')
    return 71;
  errno = 0;
  if (wcstol(L"9223372036854775808!", &wide_end, 10) != LONG_MAX ||
      *wide_end != L'!' || errno != ERANGE)
    return 65;
  errno = 0;
  if (wcstol(L"+Q", &wide_end, 10) != 0 || wide_end == NULL || *wide_end != L'+' || errno != 0)
    return 66;
  errno = 0;
  const wchar_t invalid_wide_base[] = L"12";
  if (wcstol(invalid_wide_base, &wide_end, 1) != 0 ||
      wide_end != invalid_wide_base || errno != EINVAL)
    return 67;

  char *allocated = malloc(sizeof input);
  if (allocated == NULL) return 2;
  memcpy(allocated, input, sizeof input);
  if (strcmp(allocated, input) != 0) {
    free(allocated);
    return 3;
  }
  free(allocated);

  char *end = NULL;
  long value = strtol("-42tail", &end, 10);
  if (value != -42 || end == NULL || strcmp(end, "tail") != 0) return 4;
  errno = 0;
  if (strtoimax("-9223372036854775808!", &end, 10) != INTMAX_MIN ||
      *end != '!' || errno != 0)
    return 82;
  if (strtoumax("0xffffffffffffffff!", &end, 0) != UINTMAX_MAX ||
      *end != '!' || errno != 0)
    return 83;
  if (__isoc23_strtoimax("0b101!", &end, 0) != 5 || *end != '!') return 87;
  if (__isoc23_strtoumax("0B101!", &end, 0) != 5 || *end != '!') return 88;
  const char binary_text[] = "0b101!";
  if (nelibc_test_legacy_strtol(binary_text, &end, 0) != 0 ||
      end != &binary_text[1]) return 72;
  if (__isoc23_strtol(binary_text, &end, 0) != 5 ||
      end != &binary_text[5]) return 73;
  if (nelibc_test_legacy_strtol(binary_text, &end, 2) != 0 ||
      end != &binary_text[1]) return 76;
  if (__isoc23_strtol(binary_text, &end, 2) != 5 ||
      end != &binary_text[5]) return 77;
  if (atof("-0x1.8p+2") != -6.0) return 5;
  char *option_args[] = {(char *)"consumer", (char *)"-ab", (char *)"-cattached",
                         (char *)"operand", NULL};
  optind = 1;
  opterr = 0;
  optopt = 0;
  if (getopt(4, option_args, "abc:") != 'a' || getopt(4, option_args, "abc:") != 'b' ||
      getopt(4, option_args, "abc:") != 'c' || optarg == NULL ||
      strcmp(optarg, "attached") != 0 || getopt(4, option_args, "abc:") != -1 || optind != 3)
    return 26;
  char *separate_args[] = {(char *)"consumer", (char *)"-c", (char *)"separate", NULL};
  optind = 0;
  if (getopt(3, separate_args, "c:") != 'c' || optarg == NULL ||
      strcmp(optarg, "separate") != 0 || optind != 3) return 30;
  char *missing_args[] = {(char *)"consumer", (char *)"-c", NULL};
  optind = 1;
  if (getopt(2, missing_args, ":c:") != ':' || optopt != 'c' || optind != 2) return 27;
  char *unknown_args[] = {(char *)"consumer", (char *)"-z", NULL};
  optind = 1;
  if (getopt(2, unknown_args, "ab") != '?' || optopt != 'z' || optind != 2) return 28;
  char *end_options_args[] = {(char *)"consumer", (char *)"-a", (char *)"--",
                              (char *)"-b", NULL};
  optind = 1;
  if (getopt(4, end_options_args, "ab") != 'a' || getopt(4, end_options_args, "ab") != -1 ||
      optind != 3) return 29;
  const struct option long_options[] = {
      {"alpha", no_argument, NULL, 'a'},
      {"beta", required_argument, NULL, 'b'},
      {NULL, 0, NULL, 0},
  };
  char *long_args[] = {(char *)"consumer", (char *)"--alph", (char *)"--beta=value", NULL};
  int long_index = -1;
  optind = 0;
  if (getopt_long(3, long_args, "ab:", long_options, &long_index) != 'a' ||
      long_index != 0 || getopt_long(3, long_args, "ab:", long_options, &long_index) != 'b' ||
      long_index != 1 || optarg == NULL || strcmp(optarg, "value") != 0 ||
      getopt_long(3, long_args, "ab:", long_options, &long_index) != -1) return 31;
  char suboptions[] = "ro=fast,rw";
  char *suboption_cursor = suboptions;
  char *suboption_value = NULL;
  char *suboption_tokens[] = {"ro", "rw", NULL};
  if (getsubopt(&suboption_cursor, suboption_tokens, &suboption_value) != 0 ||
      suboption_value == NULL || strcmp(suboption_value, "fast") != 0 ||
      strcmp(suboption_cursor, "rw") != 0 ||
      getsubopt(&suboption_cursor, suboption_tokens, &suboption_value) != 1 ||
      suboption_value != NULL || suboption_cursor == NULL || *suboption_cursor != '\0' ||
      getsubopt(&suboption_cursor, suboption_tokens, &suboption_value) != -1) return 32;
  wchar_t wide_buffer[4] = {0};
  char multibyte_buffer[4] = {0};
  if (mblen("A", 1) != 1 || mbtowc(wide_buffer, "A", 1) != 1 ||
      wide_buffer[0] != L'A' || mbstowcs(wide_buffer, "BC", 4) != 2 ||
      wide_buffer[0] != L'B' || wide_buffer[1] != L'C' || wide_buffer[2] != 0 ||
      wcstombs(multibyte_buffer, wide_buffer, sizeof multibyte_buffer) != 2 ||
      multibyte_buffer[0] != 'B' || multibyte_buffer[1] != 'C' ||
      wctomb(multibyte_buffer, L'Z') != 1 || multibyte_buffer[0] != 'Z') return 33;
  if (btowc(-1) != WEOF || btowc('Q') != L'Q' || wctob(WEOF) != -1 ||
      wctob(L'Q') != 'Q' || wctob(0xe9) != -1) return 75;
  wchar_t wide_copy_endbuf[16] = {0};
  wchar_t *wide_copy_end = wcpcpy(wide_copy_endbuf, L"copy");
  wchar_t bounded_wide_copy[16];
  for (size_t i = 0; i < 16; ++i) bounded_wide_copy[i] = 0x777;
  wchar_t *bounded_wide_end = wcpncpy(bounded_wide_copy, L"X", 4);
  const wchar_t wide_search[] = L"wide string";
  if (wide_copy_end != wide_copy_endbuf + 4 || wcscmp(wide_copy_endbuf, L"copy") != 0 ||
      bounded_wide_end != bounded_wide_copy + 1 || bounded_wide_copy[0] != L'X' ||
      bounded_wide_copy[1] != 0 || bounded_wide_copy[2] != 0 ||
      bounded_wide_copy[3] != 0 || wcswcs(wide_search, L"string") != wide_search + 5 ||
      wcscasecmp(L"AbC", L"aBc") != 0 ||
      wcsncasecmp(L"AbD", L"aBc", 2) != 0 ||
      wcsncasecmp(L"AbD", L"aBc", 3) <= 0)
    return 76;
#ifndef NELIBC_STANDALONE
  if (mbrlen_thread_isolation()) return 82;
  if (allocator_thread_isolation()) return 84;
  if (fork_allocator_stdio_stress(argv[0]) != 0) return 87;
#endif
#ifdef NELIBC_STANDALONE
  int locale_smoke_result = standalone_locale_smoke();
  if (locale_smoke_result != 0) return 84 + locale_smoke_result;
  if (setlocale(LC_CTYPE, "C.UTF-8") == NULL) return 34;
  if (btowc(0xc3) != WEOF || wctob(0xe9) != -1) return 76;
  locale_t ctype_c = newlocale(LC_CTYPE_MASK, "C", (locale_t)0);
  locale_t ctype_utf8 = newlocale(LC_CTYPE_MASK, "C.UTF-8", ctype_c);
  locale_t all_utf8 = newlocale(LC_ALL_MASK, "C.UTF-8", (locale_t)0);
  locale_t ctype_current = duplocale(LC_GLOBAL_LOCALE);
  wctype_t alpha_class = wctype("alpha");
  wctype_t space_class = wctype_l("space", ctype_c);
  if (ctype_c == (locale_t)0 || ctype_utf8 == (locale_t)0 ||
      all_utf8 == (locale_t)0 || ctype_current == (locale_t)0 ||
      alpha_class == 0 || space_class == 0 || wctype_l("alpha", all_utf8) == 0 ||
      wctype("not-a-class") != 0 || iswctype(0x391, alpha_class) == 0 ||
      iswctype_l(0x391, alpha_class, ctype_c) != 0 ||
      iswctype_l(0x391, alpha_class, ctype_utf8) == 0 ||
      iswctype_l(0xa0, space_class, ctype_c) != 0 ||
      iswctype_l(0xa0, space_class, ctype_utf8) == 0 ||
      iswalnum_l(0x391, ctype_utf8) == 0 || iswalpha_l(0x391, ctype_utf8) == 0 ||
      iswblank_l(L'\t', ctype_c) == 0 || iswcntrl_l(L'\n', ctype_utf8) == 0 ||
      iswdigit_l(L'4', ctype_c) == 0 || iswgraph_l(L'!', ctype_c) == 0 ||
      iswlower_l(0x3b1, ctype_utf8) == 0 || iswprint_l(0x3b1, ctype_utf8) == 0 ||
      iswpunct_l(0x2014, ctype_utf8) == 0 || iswspace_l(0xa0, ctype_utf8) == 0 ||
      iswupper_l(0x391, ctype_utf8) == 0 || iswxdigit_l(L'F', ctype_c) == 0 ||
      towlower_l(0x391, ctype_c) != 0x391 ||
      towlower_l(0x391, ctype_utf8) != 0x3b1 ||
      towupper_l(0x3b1, ctype_utf8) != 0x391 ||
      wcscasecmp_l(L"AbC", L"aBc", ctype_c) != 0 ||
      wcscasecmp_l(L"Ä", L"ä", ctype_utf8) != 0 ||
      wcscasecmp_l(L"Ä", L"ä", ctype_c) == 0 ||
      wcsncasecmp_l(L"Äx", L"äy", 1, ctype_utf8) != 0 ||
      wcsncasecmp_l(L"Äx", L"äy", 2, ctype_utf8) == 0 ||
      wcsncasecmp_l(L"Ab", L"aB", 0, ctype_utf8) != 0 ||
      iswalpha_l(0x391, ctype_current) == 0)
    return 80;
  wchar_t wide_key[8];
  wchar_t short_wide_key[2] = {0x777, 0x777};
  if (wcscoll(L"alpha", L"beta") >= 0 ||
      wcscoll_l(L"ä", L"z", ctype_utf8) <= 0 ||
      wcsxfrm(wide_key, L"ä", 8) != 1 || wide_key[0] != L'ä' || wide_key[1] != 0 ||
      wcsxfrm_l(wide_key, L"ä", 8, ctype_c) != 1 ||
      wide_key[0] != L'ä' || wide_key[1] != 0 ||
      wcsxfrm_l(short_wide_key, L"ab", 1, ctype_utf8) != 2 ||
      short_wide_key[0] != L'a' || short_wide_key[1] != 0x777 ||
      wcsxfrm_l(short_wide_key, L"ab", 0, ctype_utf8) != 2 ||
      short_wide_key[0] != L'a' || short_wide_key[1] != 0x777)
    return 81;
  locale_t numeric_c = newlocale(LC_NUMERIC_MASK, "C", ctype_utf8);
  locale_t numeric_de = newlocale(LC_NUMERIC_MASK, "de_DE.UTF-8", numeric_c);
  locale_t monetary_c = newlocale(LC_MONETARY_MASK, "C", numeric_c);
  locale_t monetary_de = newlocale(LC_MONETARY_MASK, "de_DE.UTF-8", monetary_c);
  locale_t german_collate = newlocale(LC_COLLATE_MASK, "de_DE.UTF-8", ctype_utf8);
  locale_t german_collate_c = newlocale(LC_COLLATE_MASK, "de_DE.UTF-8", ctype_c);
  locale_t numeric_de_monetary_de =
      newlocale(LC_MONETARY_MASK, "de_DE.UTF-8", numeric_de);
  locale_t collate_c = newlocale(LC_COLLATE_MASK, "C", numeric_de);
  locale_t time_c = newlocale(LC_TIME_MASK, "C", numeric_de);
  locale_t time_de = newlocale(LC_TIME_MASK, "de_DE.UTF-8", time_c);
  if (numeric_c == (locale_t)0 || numeric_de == (locale_t)0 ||
      monetary_c == (locale_t)0 || monetary_de == (locale_t)0 ||
      german_collate == (locale_t)0 || german_collate_c == (locale_t)0 ||
      numeric_de_monetary_de == (locale_t)0 || collate_c != numeric_de ||
      time_c != numeric_de || time_de == (locale_t)0)
    return 86;
  errno = 0;
  if (newlocale(LC_CTYPE_MASK, "de_DE.UTF-8", numeric_de) != (locale_t)0 ||
      errno != EINVAL || setlocale(LC_NUMERIC, "de_DE.UTF-8") == NULL)
    return 89;
  if (wcscoll_l(L"a", L"ä", german_collate) >= 0 ||
      wcscoll_l(L"ä", L"aa", german_collate) >= 0 ||
      wcscoll_l(L"ss", L"ß", german_collate) >= 0 ||
      wcscoll_l(L"ß", L"st", german_collate) >= 0 ||
      wcscoll_l(L"a", L"A", german_collate) >= 0 ||
      wcscoll_l(L"café", L"cafe", german_collate) <= 0 ||
      wcscoll_l(L"café", L"cafè", german_collate) <= 0 ||
      wcscoll_l(L"café", L"caff", german_collate) >= 0 ||
      wcscoll_l(L"café", L"cafe\u0301", german_collate) != 0 ||
      wcscoll_l(L"É", L"E\u0301", german_collate) != 0 ||
      wcscoll_l(L"a\u0301\u0327", L"a\u0327\u0301", german_collate) != 0 ||
      wcscoll_l(L"á\u0327", L"a\u0327\u0301", german_collate) != 0 ||
      wcscoll_l(L"a\u0301\u0308", L"a\u0308\u0301", german_collate) <= 0 ||
      wcscoll_l(L"a\u0315\u0327", L"a\u0327\u0315", german_collate) != 0 ||
      wcscoll_l(L"a\u05b0\u0327", L"a\u0327\u05b0", german_collate) != 0 ||
      wcscoll_l(L"a\u0344", L"a\u0308\u0301", german_collate) != 0 ||
      wcscoll_l(L"a\u0340", L"a\u0300", german_collate) != 0 ||
      wcscoll_l(L"É", L"é", german_collate) <= 0 ||
      wcscoll_l(L"c", L"č", german_collate) >= 0 ||
      wcscoll_l(L"č", L"d", german_collate) >= 0 ||
      wcscoll_l(L"Č", L"č", german_collate) <= 0)
    return 90;
  for (size_t i = 0;
       i < sizeof german_mark_expansion_cases / sizeof german_mark_expansion_cases[0];
       ++i) {
    const german_mark_expansion_case *test = &german_mark_expansion_cases[i];
    wchar_t composed_key[32], decomposed_key[32];
    size_t composed_length =
        wcsxfrm_l(composed_key, test->composed_wide, 32, german_collate);
    size_t decomposed_length =
        wcsxfrm_l(decomposed_key, test->decomposed_wide, 32, german_collate);
    if (wcscoll_l(test->composed_wide, test->decomposed_wide, german_collate) != 0 ||
        composed_length != decomposed_length ||
        wcscmp(composed_key, decomposed_key) != 0)
      return 110 + (int)i;
  }
  for (size_t i = 0;
       i < sizeof german_combining_class_cases / sizeof german_combining_class_cases[0];
       ++i) {
    for (size_t j = 0;
         j < sizeof german_combining_class_cases / sizeof german_combining_class_cases[0];
         ++j) {
      if (german_combining_class_cases[i].combining_class <=
          german_combining_class_cases[j].combining_class)
        continue;
      wchar_t high_first[] = {L'a', german_combining_class_cases[i].wide,
          german_combining_class_cases[j].wide, 0};
      wchar_t canonical[] = {L'a', german_combining_class_cases[j].wide,
          german_combining_class_cases[i].wide, 0};
      wchar_t high_key[32], canonical_key[32];
      size_t high_length = wcsxfrm_l(high_key, high_first, 32, german_collate);
      size_t canonical_length = wcsxfrm_l(canonical_key, canonical, 32, german_collate);
      if (wcscoll_l(high_first, canonical, german_collate) != 0 ||
          high_length != canonical_length || wcscmp(high_key, canonical_key) != 0)
        return 115;
    }
  }
  const wchar_t *german_words[] = {
      L"a", L"ä", L"aa", L"ab", L"ac", L"ad", L"ae", L"af", L"az",
      L"b", L"c", L"cafe", L"cafè", L"café", L"caff", L"cc", L"cč",
      L"cd", L"o", L"ö", L"oa", L"oe",
      L"p", L"ss", L"ß", L"ssa", L"st", L"t"};
  for (size_t i = 0; i < sizeof german_words / sizeof german_words[0]; ++i) {
    for (size_t j = i + 1; j < sizeof german_words / sizeof german_words[0]; ++j) {
      wchar_t left_key[64], right_key[64];
      size_t left_length = wcsxfrm_l(left_key, german_words[i], 64, german_collate);
      size_t right_length = wcsxfrm_l(right_key, german_words[j], 64, german_collate);
      if (wcscoll_l(german_words[i], german_words[j], german_collate) >= 0 ||
          left_length >= 64 || right_length >= 64 || wcscmp(left_key, right_key) >= 0)
        return 94;
    }
  }
  wchar_t precomposed_key[64], decomposed_key[64];
  size_t precomposed_length =
      wcsxfrm_l(precomposed_key, L"café", 64, german_collate);
  size_t decomposed_length =
      wcsxfrm_l(decomposed_key, L"cafe\u0301", 64, german_collate);
  if (precomposed_length >= 64 || decomposed_length >= 64 ||
      precomposed_length != decomposed_length ||
      wcscmp(precomposed_key, decomposed_key) != 0)
    return 95;
  wcsxfrm_l(precomposed_key, L"á\u0327", 64, german_collate);
  wcsxfrm_l(decomposed_key, L"a\u0327\u0301", 64, german_collate);
  if (wcscmp(precomposed_key, decomposed_key) != 0) return 96;
  wcsxfrm_l(precomposed_key, L"a\u0301\u0308", 64, german_collate);
  wcsxfrm_l(decomposed_key, L"a\u0308\u0301", 64, german_collate);
  if (wcscmp(precomposed_key, decomposed_key) <= 0) return 98;
  wcsxfrm_l(precomposed_key, L"a\u0315\u0327", 64, german_collate);
  wcsxfrm_l(decomposed_key, L"a\u0327\u0315", 64, german_collate);
  if (wcscmp(precomposed_key, decomposed_key) != 0) return 99;
  wcsxfrm_l(precomposed_key, L"a\u05b0\u0327", 64, german_collate);
  wcsxfrm_l(decomposed_key, L"a\u0327\u05b0", 64, german_collate);
  if (wcscmp(precomposed_key, decomposed_key) != 0) return 100;
  wcsxfrm_l(precomposed_key, L"a\u0344", 64, german_collate);
  wcsxfrm_l(decomposed_key, L"a\u0308\u0301", 64, german_collate);
  if (wcscmp(precomposed_key, decomposed_key) != 0) return 101;
  wchar_t german_ss_key[32], german_sharp_s_key[32];
  size_t german_ss_length = wcsxfrm_l(german_ss_key, L"ss", 32, german_collate);
  size_t german_sharp_s_length = wcsxfrm_l(german_sharp_s_key, L"ß", 32, german_collate);
  if (german_ss_length >= 32 || german_sharp_s_length >= 32 ||
      wcscmp(german_ss_key, german_sharp_s_key) >= 0 ||
      wcscmp(L"ss", L"ß") >= 0)
    return 91;
  locale_t old_collate_locale = uselocale(german_collate);
  char german_a_key[128], german_umlaut_key[128];
  size_t german_a_key_length = strxfrm(german_a_key, "a", sizeof german_a_key);
  size_t german_umlaut_key_length = strxfrm(german_umlaut_key, "ä", sizeof german_umlaut_key);
  char german_precomposed_key[128], german_decomposed_key[128];
  size_t german_precomposed_key_length =
      strxfrm(german_precomposed_key, "café", sizeof german_precomposed_key);
  size_t german_decomposed_key_length =
      strxfrm(german_decomposed_key, "cafe\xcc\x81", sizeof german_decomposed_key);
  char german_marks_first_key[128], german_marks_second_key[128];
  strxfrm(german_marks_first_key, "á\xcc\xa7", sizeof german_marks_first_key);
  strxfrm(german_marks_second_key, "a\xcc\xa7\xcc\x81", sizeof german_marks_second_key);
  char german_extended_marks_first[128], german_extended_marks_second[128];
  strxfrm(german_extended_marks_first, "a\xcc\x95\xcc\xa7",
          sizeof german_extended_marks_first);
  strxfrm(german_extended_marks_second, "a\xcc\xa7\xcc\x95",
          sizeof german_extended_marks_second);
  char german_hebrew_marks_first[128], german_hebrew_marks_second[128];
  strxfrm(german_hebrew_marks_first, "a\xd6\xb0\xcc\xa7",
          sizeof german_hebrew_marks_first);
  strxfrm(german_hebrew_marks_second, "a\xcc\xa7\xd6\xb0",
          sizeof german_hebrew_marks_second);
  char german_expanded_mark_first[128], german_expanded_mark_second[128];
  strxfrm(german_expanded_mark_first, "a\xcd\x84",
          sizeof german_expanded_mark_first);
  strxfrm(german_expanded_mark_second, "a\xcc\x88\xcc\x81",
          sizeof german_expanded_mark_second);
  if (old_collate_locale == (locale_t)0 || wcscoll(L"ä", L"aa") >= 0 ||
      strcoll("a", "ä") >= 0 || german_a_key_length >= sizeof german_a_key ||
      german_umlaut_key_length >= sizeof german_umlaut_key ||
      strcmp(german_a_key, german_umlaut_key) >= 0 ||
      strcoll("café", "cafe\xcc\x81") != 0 ||
      strcoll("a\xcc\x81\xcc\xa7", "a\xcc\xa7\xcc\x81") != 0 ||
      strcoll("a\xcc\x95\xcc\xa7", "a\xcc\xa7\xcc\x95") != 0 ||
      strcoll("a\xd6\xb0\xcc\xa7", "a\xcc\xa7\xd6\xb0") != 0 ||
      strcoll("a\xcd\x84", "a\xcc\x88\xcc\x81") != 0 ||
      strcoll("á\xcc\xa7", "a\xcc\xa7\xcc\x81") != 0 ||
      german_precomposed_key_length >= sizeof german_precomposed_key ||
      german_decomposed_key_length >= sizeof german_decomposed_key ||
      german_precomposed_key_length != german_decomposed_key_length ||
      strcmp(german_precomposed_key, german_decomposed_key) != 0 ||
      strcmp(german_marks_first_key, german_marks_second_key) != 0 ||
      strcmp(german_extended_marks_first, german_extended_marks_second) != 0 ||
      strcmp(german_hebrew_marks_first, german_hebrew_marks_second) != 0 ||
      strcmp(german_expanded_mark_first, german_expanded_mark_second) != 0 ||
      uselocale(old_collate_locale) != german_collate)
    return 92;
  old_collate_locale = uselocale(german_collate);
  if (old_collate_locale == (locale_t)0) return 107;
  for (size_t i = 0;
       i < sizeof german_mark_expansion_cases / sizeof german_mark_expansion_cases[0];
       ++i) {
    const german_mark_expansion_case *test = &german_mark_expansion_cases[i];
    char composed_key[128], decomposed_key[128];
    size_t composed_length =
        strxfrm(composed_key, test->composed_utf8, sizeof composed_key);
    size_t decomposed_length =
        strxfrm(decomposed_key, test->decomposed_utf8, sizeof decomposed_key);
    if (strcoll(test->composed_utf8, test->decomposed_utf8) != 0)
      return 106;
    if (composed_length != decomposed_length ||
        strcmp(composed_key, decomposed_key) != 0)
      return 106;
  }
  for (size_t i = 0;
       i < sizeof german_combining_class_cases / sizeof german_combining_class_cases[0];
       ++i) {
    for (size_t j = 0;
         j < sizeof german_combining_class_cases / sizeof german_combining_class_cases[0];
         ++j) {
      if (german_combining_class_cases[i].combining_class <=
          german_combining_class_cases[j].combining_class)
        continue;
      char high_first[32] = "a", canonical[32] = "a";
      strcat(high_first, german_combining_class_cases[i].utf8);
      strcat(high_first, german_combining_class_cases[j].utf8);
      strcat(canonical, german_combining_class_cases[j].utf8);
      strcat(canonical, german_combining_class_cases[i].utf8);
      char high_key[128], canonical_key[128];
      size_t high_length = strxfrm(high_key, high_first, sizeof high_key);
      size_t canonical_length = strxfrm(canonical_key, canonical, sizeof canonical_key);
      if (strcoll(high_first, canonical) != 0 || high_length != canonical_length ||
          strcmp(high_key, canonical_key) != 0)
        return 116;
    }
  }
  if (uselocale(old_collate_locale) != german_collate) return 108;
  old_collate_locale = uselocale(german_collate_c);
  if (old_collate_locale == (locale_t)0 || strcoll("a", "ä") >= 0 ||
      uselocale(old_collate_locale) != german_collate_c)
    return 93;
  struct lconv *main_locale_data = localeconv();
  if (strcmp(main_locale_data->decimal_point, ",") != 0) return 87;
  standalone_numeric_locale_args numeric_locale_args = {
      .locales = {numeric_c, numeric_de, monetary_c, monetary_de, collate_c,
          time_c, time_de},
      .main_locale_data = main_locale_data,
      .locale_data_isolated = 0};
  pthread_t numeric_worker;
  void *numeric_worker_result = 0;
  if (pthread_create(&numeric_worker, 0, standalone_numeric_locale_worker,
          &numeric_locale_args) != 0 ||
      pthread_join(numeric_worker, &numeric_worker_result) != 0 ||
      numeric_worker_result != 0 || !numeric_locale_args.locale_data_isolated ||
      strcmp(main_locale_data->decimal_point, ",") != 0 ||
      main_locale_data->currency_symbol[0] != '\0' ||
      strcmp(localeconv()->decimal_point, ",") != 0 ||
      setlocale(LC_MONETARY, "de_DE.UTF-8") == NULL ||
      duplocale(LC_GLOBAL_LOCALE) != numeric_de_monetary_de ||
      newlocale(LC_MONETARY_MASK, "C", numeric_de_monetary_de) != numeric_de ||
      setlocale(LC_MONETARY, "C") == NULL ||
      setlocale(LC_NUMERIC, "C") == NULL)
    return 88 + (int)(uintptr_t)numeric_worker_result;
  pthread_t locale_worker;
  void *locale_worker_result = 0;
  if (pthread_create(&locale_worker, 0, standalone_uselocale_worker, ctype_c) != 0 ||
      pthread_join(locale_worker, &locale_worker_result) != 0 ||
      locale_worker_result != 0 || !iswalpha(0xe9)) return 85;
  locale_t bad_locale = newlocale(LC_CTYPE_MASK, "missing_LOCALE", ctype_c);
  if (bad_locale != (locale_t)0 || errno != EINVAL) return 81;
  freelocale(ctype_current);
  freelocale(all_utf8);
  freelocale(ctype_utf8);
  freelocale(ctype_c);
  if (towlower(0x391) != 0x3b1 || towupper(0x3b1) != 0x391 ||
      towlower(0x410) != 0x430 || towupper(0x430) != 0x410 ||
      towlower(0x10400) != 0x10428 || towupper(0x10428) != 0x10400 ||
      towlower(0x1f80) != 0x1f80 || towupper(0x1f80) != 0x1f88 ||
      towlower(WEOF) != WEOF || towupper(WEOF) != WEOF)
    return 78;
  if (!iswalpha(0x391) || !iswalpha(0x2160) || !iswlower(0x3b1) ||
      !iswlower(0x345) || !iswupper(0x391) || !iswupper(0x1c5) ||
      !iswdigit(L'7') || iswdigit(0x660) || iswalpha(0x660) ||
      !iswxdigit(L'F') || !iswspace(0xa0) || iswblank(0xa0) ||
      !iswblank(L' ') || !iswblank(L'\t') ||
      !iswspace(0x2028) || iswspace(0x1c) || !iswcntrl(0x2028) ||
      !iswprint(0x200d) || iswprint(0x2028) || iswprint(0x378) ||
      iswgraph(0xa0) || iswgraph(L' ') ||
      !iswalnum(0x391) || !iswpunct(0x2014) || iswpunct(0xa0) || iswalpha(WEOF) ||
      iswprint(0x110000))
    return 79;
  const wchar_t width_text[] = {L'A', 0x301, 0x4e00, 0};
  if (wcwidth(L'A') != 1 || wcwidth(0x301) != 0 || wcwidth(0x4e00) != 2 ||
      wcswidth(width_text, 3) != 3 || wcswidth(width_text, 2) != 1 ||
      wcwidth(L'\t') != -1 || wcwidth(0x0378) != -1 ||
      wcwidth(0xe000) != 1 || wcwidth(0x00ad) != 1 ||
      wcwidth(0x0600) != 1 || wcwidth(0x115f) != 2 ||
      wcwidth(0x1160) != 0 || wcwidth(0x3164) != 0 ||
      wcwidth(0xffa0) != 0 || wcwidth(0x2028) != -1)
    return 77;
  const char utf8_text[] = "\xc3\xa9";
  wchar_t unicode_character = 0;
  char utf8_output[4] = {0};
  if (mbtowc(&unicode_character, utf8_text, sizeof utf8_text - 1) != 2 ||
      unicode_character != 0xe9 || wcstombs(utf8_output, &unicode_character, 2) != 2 ||
      (unsigned char)utf8_output[0] != 0xc3 || (unsigned char)utf8_output[1] != 0xa9)
    return 35;
  mbstate_t decode_state = {0};
  const char utf8_lead[] = {(char)0xc3, 0};
  const char utf8_tail[] = {(char)0xa9, 0};
  mbstate_t length_state = {0};
  if (mbsinit(NULL) == 0 || mbsinit(&length_state) == 0 ||
      mbrlen(utf8_lead, 1, &length_state) != (size_t)-2 ||
      mbsinit(&length_state) != 0 || mbrlen(utf8_tail, 1, &length_state) != 1 ||
      mbsinit(&length_state) == 0)
    return 74;
  errno = 0;
  if (mbrlen(utf8_lead, 1, NULL) != (size_t)-2 || errno != 0) return 80;
  errno = 0;
  if (mbrlen(NULL, 0, NULL) != (size_t)-1 || errno != EILSEQ) return 81;
  if (mbrtowc(&unicode_character, utf8_lead, 1, &decode_state) != (size_t)-2 ||
      mbrtowc(&unicode_character, utf8_tail, 1, &decode_state) != 1 ||
      unicode_character != 0xe9)
    return 68;
  mbstate_t null_input_state = {0};
  if (mbrtowc(NULL, NULL, 0, &null_input_state) != 0 ||
      mbrtowc(&unicode_character, utf8_lead, 1, &null_input_state) != (size_t)-2)
    return 77;
  errno = 0;
  if (mbrtowc(NULL, NULL, 0, &null_input_state) != (size_t)-1 || errno != EILSEQ)
    return 78;
  null_input_state = (mbstate_t){0};
  if (mbrtowc(&unicode_character, utf8_text, sizeof utf8_text - 1,
          &null_input_state) != 2 || unicode_character != 0xe9)
    return 79;
  mbstate_t encode_state = {0};
  if (wcrtomb(utf8_output, 0x1f642, &encode_state) != 4 ||
      (unsigned char)utf8_output[0] != 0xf0 || (unsigned char)utf8_output[1] != 0x9f ||
      (unsigned char)utf8_output[2] != 0x99 || (unsigned char)utf8_output[3] != 0x82 ||
      wcrtomb(NULL, 0x1f642, &encode_state) != 1)
    return 69;
  const char *restart_decode = utf8_text;
  wchar_t restart_wide[2] = {0};
  mbstate_t restart_decode_state = {0};
  if (mbsrtowcs(NULL, &restart_decode, 0, &restart_decode_state) != 1 ||
      restart_decode != utf8_text ||
      mbsrtowcs(restart_wide, &restart_decode, 1, &restart_decode_state) != 1 ||
      restart_wide[0] != 0xe9 || restart_decode == NULL || *restart_decode != 0)
    return 70;
  const wchar_t *restart_encode = restart_wide;
  char restart_bytes[4] = {0};
  mbstate_t restart_encode_state = {0};
  if (wcsrtombs(NULL, &restart_encode, 0, &restart_encode_state) != 2 ||
      restart_encode != restart_wide ||
      wcsrtombs(restart_bytes, &restart_encode, sizeof restart_bytes,
          &restart_encode_state) != 2 ||
      (unsigned char)restart_bytes[0] != 0xc3 || (unsigned char)restart_bytes[1] != 0xa9 ||
      restart_encode != NULL)
    return 71;
  const char split_text[] = {(char)0xc3, (char)0xa9, 0};
  const char *split_cursor = split_text;
  wchar_t split_wide[2] = {0x777, 0x777};
  mbstate_t split_state = {0};
  if (mbsnrtowcs(split_wide, &split_cursor, 1, 2, &split_state) != 0 ||
      split_cursor != split_text + 1 || split_wide[0] != 0x777 ||
      mbsnrtowcs(split_wide, &split_cursor, 2, 2, &split_state) != 1 ||
      split_wide[0] != 0xe9 || split_cursor != NULL)
    return 72;
  const wchar_t bounded_wide[] = {L'A', 0xe9, 0};
  const wchar_t *bounded_wide_cursor = bounded_wide;
  mbstate_t bounded_encode_state = {0};
  char bounded_output[8] = {0};
  if (wcsnrtombs(NULL, &bounded_wide_cursor, 2, 0, &bounded_encode_state) != 3 ||
      bounded_wide_cursor != bounded_wide ||
      wcsnrtombs(bounded_output, &bounded_wide_cursor, 1, sizeof bounded_output,
          &bounded_encode_state) != 1 || bounded_wide_cursor != bounded_wide + 1 ||
      wcsnrtombs(bounded_output + 1, &bounded_wide_cursor, 2,
          sizeof bounded_output - 1, &bounded_encode_state) != 2 ||
      (unsigned char)bounded_output[0] != 'A' ||
      (unsigned char)bounded_output[1] != 0xc3 ||
      (unsigned char)bounded_output[2] != 0xa9 || bounded_output[3] != 0 ||
      bounded_wide_cursor != NULL)
    return 73;
  /* POSIX 2024: in the C locale each byte is one character; 0xc3 is the
   * code unit 0xdfc3, as in musl. */
  if (setlocale(LC_CTYPE, "C") == NULL || mbtowc(&unicode_character, utf8_text, 2) != 1 ||
      unicode_character != 0xdfc3 ||
      wcwidth(0x4e00) != -1 || wcwidth(L'A') != 1 ||
      wcswidth(width_text, 3) != -1 || towlower(L'A') != L'a' ||
      towupper(L'a') != L'A' || towlower(0x391) != 0x391 ||
      towupper(0x3b1) != 0x3b1 || iswalpha(L'A') == 0 ||
      iswalpha(0x391) != 0 || iswspace(L' ') == 0 || iswspace(0xa0) != 0)
    return 35;
#endif
  if (system(NULL) == 0) return 10;
  int shell_status;
  struct sigaction sigint_before, sigint_after, sigquit_before, sigquit_after;
  sigset_t mask_before, mask_after;
  if (sigaction(SIGINT, NULL, &sigint_before) != 0 ||
      sigaction(SIGQUIT, NULL, &sigquit_before) != 0 ||
      sigprocmask(SIG_BLOCK, NULL, &mask_before) != 0) return 13;
  if (sigismember(&mask_before, SIGCHLD) != 0) return 14;
  shell_status = system("kill -INT $PPID; kill -QUIT $PPID; exit 0");
  if (shell_status == -1 || !WIFEXITED(shell_status) || WEXITSTATUS(shell_status) != 0) return 15;
  if (sigaction(SIGINT, NULL, &sigint_after) != 0 ||
      sigaction(SIGQUIT, NULL, &sigquit_after) != 0 ||
      sigprocmask(SIG_BLOCK, NULL, &mask_after) != 0 ||
      sigint_after.sa_handler != sigint_before.sa_handler ||
      sigquit_after.sa_handler != sigquit_before.sa_handler ||
      sigismember(&mask_after, SIGCHLD) != sigismember(&mask_before, SIGCHLD)) return 16;
  struct sigaction custom_action = {0};
  custom_action.sa_handler = system_signal_probe;
  if (sigemptyset(&custom_action.sa_mask) != 0 ||
      sigaction(SIGINT, &custom_action, NULL) != 0) return 17;
  shell_status = system("exit 0");
  if (shell_status == -1 || !WIFEXITED(shell_status) || WEXITSTATUS(shell_status) != 0 ||
      sigaction(SIGINT, NULL, &sigint_after) != 0 ||
      sigint_after.sa_handler != system_signal_probe ||
      sigaction(SIGINT, &sigint_before, NULL) != 0) return 18;
  sigset_t inherited_mask, original_mask;
  if (sigemptyset(&inherited_mask) != 0 ||
      sigaddset(&inherited_mask, SIGUSR1) != 0 ||
      sigprocmask(SIG_BLOCK, &inherited_mask, &original_mask) != 0) return 27;
  shell_status = system("kill -USR1 $$; exit 0");
  int child_mask_restored = sigprocmask(SIG_SETMASK, &original_mask, NULL) == 0;
  if (!child_mask_restored || shell_status == -1 || !WIFEXITED(shell_status) ||
      WEXITSTATUS(shell_status) != 0) return 28;
#ifndef NELIBC_STANDALONE
  pthread_t system_threads[2];
  if (pthread_create(&system_threads[0], NULL, concurrent_system_worker, NULL) != 0 ||
      pthread_create(&system_threads[1], NULL, concurrent_system_worker, NULL) != 0) return 19;
  void *system_thread_result;
  if (pthread_join(system_threads[0], &system_thread_result) != 0 || system_thread_result != NULL ||
      pthread_join(system_threads[1], &system_thread_result) != 0 || system_thread_result != NULL) return 20;
  pthread_t cancelled_thread;
  if (pthread_create(&cancelled_thread, NULL, cancelled_system_worker, NULL) != 0) return 21;
  struct timespec cancellation_delay = {.tv_sec = 0, .tv_nsec = 50000000};
  nanosleep(&cancellation_delay, NULL);
  if (pthread_cancel(cancelled_thread) != 0 ||
      pthread_join(cancelled_thread, &system_thread_result) != 0 ||
      system_thread_result != PTHREAD_CANCELED) return 22;
  errno = 0;
  if (waitpid(-1, NULL, WNOHANG) != -1 || errno != ECHILD) return 25;
  if (sigaction(SIGINT, NULL, &sigint_after) != 0 ||
      sigaction(SIGQUIT, NULL, &sigquit_after) != 0 ||
      sigprocmask(SIG_BLOCK, NULL, &mask_after) != 0 ||
      sigint_after.sa_handler != sigint_before.sa_handler ||
      sigquit_after.sa_handler != sigquit_before.sa_handler ||
      sigismember(&mask_after, SIGCHLD) != sigismember(&mask_before, SIGCHLD)) return 23;
  shell_status = system("kill -INT $PPID; exit 0");
  if (shell_status == -1 || !WIFEXITED(shell_status) || WEXITSTATUS(shell_status) != 0) return 24;
#else
  pthread_t cancelled_thread;
  void *system_thread_result;
  if (pthread_create(&cancelled_thread, NULL, cancelled_system_worker, NULL) != 0) return 21;
  struct timespec cancellation_delay = {.tv_sec = 0, .tv_nsec = 50000000};
  nanosleep(&cancellation_delay, NULL);
  if (pthread_cancel(cancelled_thread) != 0 ||
      pthread_join(cancelled_thread, &system_thread_result) != 0 ||
      system_thread_result != PTHREAD_CANCELED) return 22;
  errno = 0;
  if (waitpid(-1, NULL, WNOHANG) != -1 || errno != ECHILD) return 25;
  shell_status = system("exit 0");
  if (shell_status == -1 || !WIFEXITED(shell_status) || WEXITSTATUS(shell_status) != 0) return 26;
#endif
  shell_status = system("exit 23");
  if (shell_status == -1 || !WIFEXITED(shell_status) || WEXITSTATUS(shell_status) != 23) return 11;
  if (setenv("NELIBC_CONSUMER_SETENV_PROBE", "first", 1) != 0 ||
      strcmp(getenv("NELIBC_CONSUMER_SETENV_PROBE"), "first") != 0 ||
      setenv("NELIBC_CONSUMER_SETENV_PROBE", "ignored", 0) != 0 ||
      strcmp(getenv("NELIBC_CONSUMER_SETENV_PROBE"), "first") != 0 ||
      setenv("NELIBC_CONSUMER_SETENV_PROBE", "second", 1) != 0 ||
      strcmp(getenv("NELIBC_CONSUMER_SETENV_PROBE"), "second") != 0) return 6;
  shell_status = system("test \"$NELIBC_CONSUMER_SETENV_PROBE\" = second");
  if (shell_status == -1 || !WIFEXITED(shell_status) || WEXITSTATUS(shell_status) != 0) return 12;
  if (unsetenv("NELIBC_CONSUMER_SETENV_PROBE") != 0 ||
      getenv("NELIBC_CONSUMER_SETENV_PROBE") != NULL ||
      unsetenv("NELIBC_CONSUMER_SETENV_PROBE") != 0) return 7;
  errno = 0;
  if (unsetenv("BAD=NAME") != -1 || errno != EINVAL) return 8;
  char caller_environment[] = "NELIBC_PUTENV_PROBE=initial";
  char *caller_value = strchr(caller_environment, '=') + 1;
  if (putenv(caller_environment) != 0 || getenv("NELIBC_PUTENV_PROBE") != caller_value)
    return 13;
  if (setenv("NELIBC_SETENV_AFTER_PUTENV", "kept", 1) != 0) return 14;
  strcpy(caller_value, "changed");
  if (strcmp(getenv("NELIBC_PUTENV_PROBE"), "changed") != 0) return 15;
  if (putenv("NELIBC_PUTENV_PROBE") != 0 ||
      getenv("NELIBC_PUTENV_PROBE") != NULL) return 16;
  errno = 0;
  if (putenv("=invalid") != -1 || errno != EINVAL) return 17;
  static char duplicate_first[] = "NELIBC_DUPLICATE=one";
  static char preserved_entry[] = "NELIBC_KEEP=present";
  static char duplicate_second[] = "NELIBC_DUPLICATE=two";
  char *duplicate_environment[] = {
      duplicate_first, preserved_entry, duplicate_second, NULL};
  environ = duplicate_environment;
  if (unsetenv("NELIBC_DUPLICATE") != 0 ||
      getenv("NELIBC_DUPLICATE") != NULL || environ[0] == NULL ||
      strcmp(environ[0], "NELIBC_KEEP=present") != 0 || environ[1] != NULL)
    return 11;
  if (clearenv() != 0 || environ != NULL || getenv("NELIBC_KEEP") != NULL)
    return 18;
  if (setenv("NELIBC_KEEP", "present", 1) != 0) return 19;
  pid_t search_child = fork();
  if (search_child < 0) return 24;
  if (search_child == 0) {
    char *search_arguments[] = {"true", NULL};
    execvp("true", search_arguments);
    _Exit(127);
  }
  int search_status = 0;
  if (waitpid(search_child, &search_status, 0) != search_child ||
      !WIFEXITED(search_status) || WEXITSTATUS(search_status) != 0) return 25;
  pid_t custom_environment_child = fork();
  if (custom_environment_child < 0) return 26;
  if (custom_environment_child == 0) {
    char *custom_arguments[] = {argv[0], "--verify-execvpe", NULL};
    char *custom_environment[] = {"NELIBC_EXEC_PROBE=yes", NULL};
    execvpe(argv[0], custom_arguments, custom_environment);
    _Exit(127);
  }
  int custom_environment_status = 0;
  if (waitpid(custom_environment_child, &custom_environment_status, 0) !=
          custom_environment_child || !WIFEXITED(custom_environment_status) ||
      WEXITSTATUS(custom_environment_status) != 0) return 27;
  pid_t descriptor_child = fork();
  if (descriptor_child < 0) return 28;
  if (descriptor_child == 0) {
    int executable_fd = open(argv[0], O_RDONLY | O_CLOEXEC);
    if (executable_fd < 0) _Exit(127);
    char *descriptor_arguments[] = {argv[0], "--verify-fexecve", NULL};
    char *descriptor_environment[] = {"NELIBC_FEXEC_PROBE=yes", NULL};
    fexecve(executable_fd, descriptor_arguments, descriptor_environment);
    _Exit(127);
  }
  int descriptor_status = 0;
  if (waitpid(descriptor_child, &descriptor_status, 0) != descriptor_child ||
      !WIFEXITED(descriptor_status) || WEXITSTATUS(descriptor_status) != 0)
    return 29;
  char *child_argv[] = {argv[0], "--verify-unsetenv", NULL};
  execv(argv[0], child_argv);
  return 12;
}
