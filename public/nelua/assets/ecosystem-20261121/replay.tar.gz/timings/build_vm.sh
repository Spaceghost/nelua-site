#!/usr/bin/env bash
set -eu
p=$(pwd)
d="$p/timings/vm"
sdk="$p/sdkroot/usr/lib/necc"
export NECC_SYSROOT=$sdk
mkdir -p "$d"
build_unit(){
 "$@" -DLUA_USE_POSIX -DNDEBUG -DLUA_USE_JUMPTABLE=0 -I"$p/nelua/src/lua" -c "$src" -o "$obj"
}
objects=
for src in "$p"/nelua/src/lua/*.c "$p"/nelua/src/{hasher,lfs,sys,luainit}.c "$p"/nelua/src/lpeglabel/lpl{cap,code,print,tree,vm}.c; do
 name=$(basename "$src" .c)
 case "$name" in luac|onelua|lvm) continue;; esac
 obj="$d/$name.o"
 build_unit "$sdk/tcc/tcc" "-B$sdk/tcc" -nostdinc -DNELIBC_STANDALONE "-I$sdk/include" "-I$sdk/tcc/include" "-I$sdk/uapi"
 objects="$objects $obj"
done
for tool in tinycc necc candidate; do
 src="$p/nelua/src/lua/lvm.c"
 obj="$d/$tool-vm.o"
 if [ "$tool" = tinycc ]; then
   build_unit "$sdk/tcc/tcc" "-B$sdk/tcc" -nostdinc -DNELIBC_STANDALONE "-I$sdk/include" "-I$sdk/tcc/include" "-I$sdk/uapi"
 elif [ -x "$p/necc/build/$tool" ]; then build_unit "$p/necc/build/$tool"; else continue; fi
 "$p/nelinker/build/nelinker" --tcc-relocs -e _start -o "$d/$tool-lua" $objects "$obj" --whole-archive "$sdk/libnelibc.a" --no-whole-archive "$sdk/tcc/libtcc1.a"
 "$d/$tool-lua" -e 'local s=0 for i=1,100000 do s=s+i end print(s)'
done
