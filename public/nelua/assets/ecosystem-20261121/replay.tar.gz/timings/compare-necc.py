from pathlib import Path
import csv,runpy,subprocess,sys,time,os
p=Path.cwd()
d=p/'timings/necc'
sdk=p/'sdkroot/usr/lib/necc'
os.environ['NECC_SYSROOT']=str(sdk)
fixture=runpy.run_path('nelua-site/public/nelua/assets/necc-codegen-20261121/runtime-replay.py')
(d/'kernel.c').write_text(fixture['KERNEL'])
(d/'entry.s').write_text(fixture['ENTRY'])
subprocess.run(['as','--64',d/'entry.s','-o',d/'entry.o'],check=True)
cmds={'necc':[p/'necc/build/necc'],'TinyCC':[sdk/'tcc/tcc','-B'+str(sdk/'tcc'),'-nostdinc','-DNELIBC_STANDALONE','-I'+str(sdk/'include'),'-I'+str(sdk/'tcc/include'),'-I'+str(sdk/'uapi')]}
if (p/'necc/build/candidate').exists(): cmds['candidate']=[p/'necc/build/candidate']
w=csv.writer(sys.stdout)
w.writerow(['round','tool','case','phase','elapsed_ns'])
for r in range(12):
    order=list(cmds)
    for name in order[r%len(order):]+order[:r%len(order)]:
        for case,src in [('kernel',d/'kernel.c'),('lua-vm',p/'nelua/src/lua/lvm.c')]:
            cmd=cmds[name]
            obj=d/(name+'-'+case+'.o')
            start=time.perf_counter_ns()
            subprocess.run([*cmd,'-c',src,'-o',obj],check=True)
            w.writerow([r,name,case,'compile',time.perf_counter_ns()-start])
            if case=='kernel':
                exe=d/(name+'-kernel')
                subprocess.run(['ld.bfd','-static','-o',exe,d/'entry.o',obj],check=True)
                start=time.perf_counter_ns()
                val=subprocess.check_output([exe])
                elapsed=time.perf_counter_ns()-start
                assert val==bytes.fromhex('d3860f0000000000')
                w.writerow([r,name,case,'run',elapsed])
            sys.stdout.flush()
