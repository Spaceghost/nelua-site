from pathlib import Path
import csv, subprocess, sys, time

root=Path.cwd()
writer=csv.writer(sys.stdout)
writer.writerow(['round','tool','workload','phase','nanoseconds','output'])
for r in range(8):
    for tool in (['nelua','nelua-reference'] if r%2==0 else ['nelua-reference','nelua']):
        for case in ['helloworld','matmul']:
            exe=root/'timings'/f'{tool}-{case}'
            source=root/'nelua'/'examples'/f'{case}.nelua'
            args=[str(root/tool/'nelua'),'-C','-r','-b','--cc','gcc','--cache-dir',str(root/'timings'/('cache-'+tool)),'-o',str(exe),str(source)]
            for phase,cmd in [('compile',args),('run',[str(exe)])]:
                start=time.monotonic_ns()
                result=subprocess.run(cmd,stdout=subprocess.PIPE,check=True)
                elapsed=time.monotonic_ns()-start
                writer.writerow([r,tool,case,phase,elapsed,result.stdout.decode().strip()])
                sys.stdout.flush()
