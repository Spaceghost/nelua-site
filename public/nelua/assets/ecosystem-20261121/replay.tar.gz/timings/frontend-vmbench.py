import csv,random,subprocess,sys,time
from pathlib import Path
d=Path('timings/vm')
w=csv.writer(sys.stdout); w.writerow(['round','compiler','ns'])
rng=random.Random(1121)
for r in range(10):
    order=['necc','tinycc','candidate']; rng.shuffle(order)
    for tool in order:
        start=time.perf_counter_ns()
        out=d/'matrix.c'
        result=subprocess.check_output([d/(tool+'-lua'),'-lnelua','nelua.lua','-C','-c','-o',out,'nelua/examples/matmul.nelua'])
        elapsed=time.perf_counter_ns()-start
        assert not result
        if r==0 and tool==order[0]: expected=out.read_bytes()
        assert out.read_bytes()==expected
        w.writerow([r,tool,elapsed]);sys.stdout.flush()
