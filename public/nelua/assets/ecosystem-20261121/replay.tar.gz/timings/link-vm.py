from pathlib import Path
import csv, subprocess, sys, time
root=Path.cwd()
vm=root/'timings/vm'
out=root/'timings/link'
sdk=root/'sdkroot/usr/lib/necc'
objs=sorted(p for p in vm.glob('*.o') if not p.name.endswith('-vm.o'))
objs.append(vm/'tinycc-vm.o')
w=csv.writer(sys.stdout);w.writerow(['round','tool','elapsed_ns','peak_kib','size'])
for r in range(16):
    for tool in (['nelinker','TinyCC'] if r%2==0 else ['TinyCC','nelinker']):
        exe=out/'lua'
        if tool=='nelinker':
            cmd=[root/'nelinker/build/nelinker','--tcc-relocs','-e','_start',*objs,'--whole-archive',sdk/'libnelibc.a','--no-whole-archive']
        else:
            cmd=[sdk/'tcc/tcc','-B'+str(sdk/'tcc'),'-nostdlib','-static','-Wl,-e,_start',*objs,'-Wl,--whole-archive',sdk/'libnelibc.a','-Wl,--no-whole-archive']
        cmd += [sdk/'tcc/libtcc1.a','-o',exe]
        exe.unlink(missing_ok=True)
        start=time.monotonic_ns()
        subprocess.run(cmd,check=True)
        ns=time.monotonic_ns()-start
        assert subprocess.check_output([exe,'-e','print(19+23)'])==b'42\n'
        subprocess.run(['/usr/bin/time','-f','%M','-o',out/'rss',*cmd],check=True)
        assert subprocess.check_output([exe,'-e','print(19+23)'])==b'42\n'
        w.writerow([r,tool,ns,int((out/'rss').read_text()),exe.stat().st_size])
