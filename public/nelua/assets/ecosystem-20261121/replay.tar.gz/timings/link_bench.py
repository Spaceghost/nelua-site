import os, subprocess, sys, csv, time, runpy
from pathlib import Path
p=Path.cwd(); out=p/'timings/link'; sdk=p/'sdkroot/usr/lib/necc'
test=runpy.run_path('nelinker/tests/check_archives.py')
start,call,*_=test['basic_fixtures'](out,sdk)
tools=[('nelinker',p/'nelinker/build/nelinker'),('ld.bfd','ld.bfd')]
w=csv.writer(sys.stdout); w.writerow(['round','tool','elapsed_ns','peak_kib','size'])
for i in range(20):
    for name,tool in tools[::1 if i%2==0 else -1]:
        exe=out/'linked'
        exe.unlink(missing_ok=True)
        cmd=[tool,'-o',exe,start,call,sdk/'libnelibc.a']
        before=time.perf_counter_ns()
        subprocess.run(cmd,check=True)
        elapsed=time.perf_counter_ns()-before
        assert subprocess.run([exe]).returncode==42
        # Independent RSS run avoids inheriting the Python harness's RSS.
        subprocess.run(['/usr/bin/time','-o',out/'rss','-f','%M',*cmd],check=True)
        assert subprocess.run([exe]).returncode==42
        w.writerow([i,name,elapsed,int((out/'rss').read_text()),exe.stat().st_size])
