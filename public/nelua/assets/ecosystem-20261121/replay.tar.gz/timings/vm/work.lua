local t = {}
for i = 1,256 do t[i] = i end
local function visit(i, s)
  if i % 3 == 0 then return (s ~ t[(i & 255) + 1]) & 0xfffff end
  return (s + i) & 0xfffff
end
local s = 0
for i=1,1000000 do s = visit(i,s) end
print(s)
