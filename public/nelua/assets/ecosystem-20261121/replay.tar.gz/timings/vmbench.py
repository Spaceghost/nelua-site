import csv,random,subprocess,sys,time
from pathlib import Path
d=Path('timings/vm')
w=csv.writer(sys.stdout); w.writerow(['round','compiler','ns'])
rng=random.Random(1121)
for r in range(16):
    order=['necc','tinycc','candidate']; rng.shuffle(order)
    for tool in order:
        start=time.perf_counter_ns()
        result=subprocess.check_output([d/(tool+'-lua'),d/'work.lua'])
        elapsed=time.perf_counter_ns()-start
        assert result==b'793207\n'
        w.writerow([r,tool,elapsed]);sys.stdout.flush()
