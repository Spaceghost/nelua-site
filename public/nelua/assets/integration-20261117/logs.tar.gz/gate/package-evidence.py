import collections,csv,datetime,hashlib,json,os,re,shutil,subprocess,tarfile
from pathlib import Path
root=Path('/srv/ai/workspaces/nelibc/cosmo');out=Path('/srv/ai/artifacts/nelibc-cosmo/integration-20261117-complete');os.chdir(root)
a=json.loads((out/'status.json').read_text());extra=json.loads((out/'additional.json').read_text())
assert a['passed'] and len(a['results'])==14 and all(x['exit']==0 for x in a['results'])
assert len(extra)==3 and all(x['exit']==0 for x in extra)
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in a['source_files'].items())
a.update(source_commit=a['tested_source_commit'],date_utc=a['finished_utc'],comparison_directory='comparison-20261117-easy-first',additional_results=extra,source_tree_sha256=hashlib.sha256(json.dumps(a['source_files'],sort_keys=True,separators=(',',':')).encode()).hexdigest())
a['skips']=sorted({l for x in a['results'] for l in (out/(x['target']+'.log')).read_text().splitlines() if l.lower().startswith('skip ')})
a['conformance_gate']={}
for profile in ['gcc','zig','standalone-gcc','standalone-zig']:
 p=root/'build'/('libc-test-'+profile)
 unexpected=(p/'new-failures.txt').read_text().splitlines();assert not unexpected
 item={'failures':(p/'failures.txt').read_text().splitlines(),'unexpected':unexpected,'now_passing':(p/'now-passing.txt').read_text().splitlines()}
 if profile.startswith('standalone'):
  item['counts']=dict(collections.Counter(l.split('\t')[1] for l in (p/'results.tsv').read_text().splitlines()))
 else:
  m=re.search(r'(\d+) test binaries, (\d+) failing, (\d+) expected',(out/('libc-test-'+profile+'.log')).read_text());assert m
  item.update(built_binaries=int(m[1]),failing=int(m[2]),expected=int(m[3]))
 a['conformance_gate'][profile]=item
checks=[]
for pattern in ['mem-shootout-*.csv','memcmp-shootout-*.csv','memscan-*.csv','strstr-shootout-*.csv','strcasecmp-shootout-*.csv']:
 for p in sorted((root/'build').glob(pattern)):
  if p.stat().st_mtime<datetime.datetime.fromisoformat(a['started_utc'].replace('Z','+00:00')).timestamp():continue
  rows=list(csv.DictReader(p.open()))
  timed=[r for r in rows if r.get('median_ns_per_call') is not None and int(r.get('iterations','0'))>0]
  if not timed:continue
  bad=[r for r in timed if float(r['median_ns_per_call'])<=0];assert not bad,(p,bad)
  checks.append({'file':str(p.relative_to(root)),'timed_rows':len(timed),'zero_timings':len(bad)})
a['benchmark_timing_checks']=checks
archives=out/'archives';archives.mkdir(exist_ok=True)
for name,h in a['archive_sha256'].items():
 p=root/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 shutil.copy2(p,archives/p.name)
for src,name in [('/srv/ai/artifacts/nelibc-cosmo/integration-20261117-fixed/tcc-x87-tests.log','tinycc-tests.log'),('/srv/ai/artifacts/nelibc-cosmo/integration-20261117-fixed/tcc-x87-build.log','tinycc-build.log'),('/srv/ai/artifacts/nelibc-cosmo/integration-20261117/tcc-clean-fix.log','tinycc-clean-build.log'),('/srv/ai/artifacts/nelibc-cosmo/integration-20261117-verified/tcc-adapter-fixes.log','tinycc-adapter-fixes.log')]:shutil.copy2(src,out/name)
assert 'ALL TESTS PASSED' in (out/'tinycc-tests.log').read_text()
a['toolchains']={'nelua':'dabbd9ef','zig':subprocess.check_output(['/opt/zig/zig','version']).decode().strip(),'gcc':subprocess.check_output(['gcc','-dumpfullversion']).decode().strip(),'tinycc_commit':a['tinycc_commit'],'tinycc_patch_sha256':a['tinycc_patch_sha256'],'bend':'2.0.39','cosmopolitan':'4.0.2'}
(out/'gate.json').write_text(json.dumps(a,indent=2)+'\n')
start=datetime.datetime.fromisoformat(a['started_utc'].replace('Z','+00:00')).timestamp()
with tarfile.open(out/'logs.tar.gz','w:gz') as t:
 for p in sorted(out.iterdir()):
  if p.is_file() and p.suffix in ('.log','.json','.py','.txt'):t.add(p,arcname='gate/'+p.name)
 for p in (root/'build').rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if ('libc-test-' in str(rel) and (p.suffix in ('.err','.log','.txt','.tsv') or p.name=='REPORT')) or (p.suffix=='.csv' and p.stat().st_mtime>=start):t.add(p,arcname=str(rel))
print(json.dumps({'passed':a['passed'],'source_commit':a['source_commit'],'main_targets':len(a['results']),'additional_targets':len(extra),'skips':a['skips'],'timing_files_checked':len(checks),'archives_retained':len(a['archive_sha256']),'logs_bytes':(out/'logs.tar.gz').stat().st_size},indent=2))
