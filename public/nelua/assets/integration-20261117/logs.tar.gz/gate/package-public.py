from pathlib import Path
import datetime,hashlib,json,tarfile
root=Path('/srv/ai/workspaces/nelibc/cosmo');out=Path('/srv/ai/artifacts/nelibc-cosmo/integration-20261117-complete')
a=json.loads((out/'gate.json').read_text())
if 'uncompressed_duplicate_bundle_sha256' in a:a['retained_full_bundle_sha256']=a.pop('uncompressed_duplicate_bundle_sha256')
(out/'gate.json').write_text(json.dumps(a,indent=2)+'\n')
large={x['file']:x['sha256'] for x in a['exhaustive_csv_files']};seen={};start=datetime.datetime.fromisoformat(a['started_utc'].replace('Z','+00:00')).timestamp()
with tarfile.open(out/'logs.tar.gz','w:gz') as t:
 for p in sorted(out.iterdir()):
  if p.is_file() and p.suffix in ('.log','.json','.py','.txt'):t.add(p,arcname='gate/'+p.name)
 for p in sorted((root/'build').rglob('*')):
  if not p.is_file():continue
  rel=str(p.relative_to(root))
  if not (('libc-test-' in rel and (p.suffix in ('.err','.log','.txt','.tsv') or p.name=='REPORT')) or (p.suffix=='.csv' and p.stat().st_mtime>=start)):continue
  h=large.get(rel)
  if h and h in seen:
   info=t.gettarinfo(str(p),arcname=rel);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;t.addfile(info)
  else:
   t.add(p,arcname=rel)
   if h:seen[h]=rel
with tarfile.open(out/'logs.tar.gz','r:gz') as t:
 assert t.extractfile('gate/gate.json').read()==(out/'gate.json').read_bytes()
 for h,name in seen.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
 for name,h in large.items():
  m=t.getmember(name);assert name==seen[h] or (m.islnk() and m.linkname==seen[h])
size=(out/'logs.tar.gz').stat().st_size;assert size<25000000
print('Verified lossless public bundle:',size,'bytes; manifest and all exhaustive CSV hashes match')
