import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/srv/ai/workspaces/nelibc/cosmo');out=Path('/srv/ai/artifacts/nelibc-cosmo/integration-20261117-complete')
os.chdir(root)
os.environ.update(TMPDIR='/srv/ai/tmp/nelibc-cosmo',TMP='/srv/ai/tmp/nelibc-cosmo',TEMP='/srv/ai/tmp/nelibc-cosmo',ZIG_GLOBAL_CACHE_DIR='/srv/ai/cache/nelibc-cosmo/zig',JOBS='2',BEND_NO_TELEMETRY='1')
cache=root/'build/integration-nelua-cache';cache.mkdir(parents=True,exist_ok=True)
files=sorted(set(subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')))
source={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files if n and (root/n).is_file() and '__pycache__' not in n}
common=['NELUA=/opt/nelua-dabbd9ef/nelua --cache-dir '+str(cache),'ZIG=/opt/zig/zig','TCC=/srv/ai/cache/nelibc-cosmo/tcc-integration-x87/bin/tcc','TCC_LIBTCC1=/srv/ai/cache/nelibc-cosmo/tcc-integration-x87/lib/tcc/libtcc1.a','BEND=/opt/bend-2.0.39/bend/bin/bend','LIBC_TEST=/work/libc-test/baseline','COSMOCC=/srv/ai/cache/nelibc-cosmo/toolchain/bin/x86_64-unknown-cosmo-cc']
targets=['smoke-matrix','dogfood-matrix','host-matrix','host-bend-hello-zig','host-bend-parallel-zig','host-snapshot-matrix','sys-ops-check','libc-test-gcc','libc-test-zig','libc-test-standalone-gcc','libc-test-standalone-zig','smoke-cosmo','purity-check','shootout-matrix']
meta={'source_base':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'source_files':source,'tinycc_commit':'32d1c0a5614b9979768b3711726db3d601750ed3','tested_source_commit':'d55e30050d987bc2dbbe1230d4f83f36043465e2','tinycc_patch_sha256':hashlib.sha256((root/'tools/toolchains/tinycc-x87-argument-pop.patch').read_bytes()).hexdigest(),'commands':[],'results':[],'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
(out/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
for i,target in enumerate(targets,1):
 changed=[n for n,h in source.items() if not (root/n).is_file() or hashlib.sha256((root/n).read_bytes()).hexdigest()!=h]
 if changed:raise RuntimeError('Source changed during gate: '+repr(changed))
 command=['make','-k','-j1',target]+common
 meta['commands'].append(command);meta['active']=target
 (out/'status.json').write_text(json.dumps(meta,indent=2)+'\n')
 print(f'START {i}/{len(targets)} {target}',flush=True);start=time.monotonic()
 with (out/(target+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 result={'target':target,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)}
 meta['results'].append(result);meta['active']=None
 (out/'status.json').write_text(json.dumps(meta,indent=2)+'\n')
 print('DONE '+json.dumps(result),flush=True)
meta['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());meta['passed']=all(r['exit']==0 for r in meta['results'])
meta['archive_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'build').glob('libnelibc*.a')}
(out/'status.json').write_text(json.dumps(meta,indent=2)+'\n')
print('GATE COMPLETE: '+('PASS' if meta['passed'] else 'FAIL; inspect per-target logs'),flush=True)

raise SystemExit(0 if meta["passed"] else 1)
