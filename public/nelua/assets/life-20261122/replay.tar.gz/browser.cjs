const {chromium} = require(process.env.PLAYWRIGHT || 'playwright');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch({executablePath:process.env.CHROME || undefined});
  try {
    const page = await browser.newPage();
    await page.goto(process.argv[2]);
    const csv = await page.evaluate(async () => {
      const {run} = await import('./simulate.mjs');
      const {default:rules} = await import('./rule.mjs');
      const modules = {};
      for(const version of ['before','after']){
        const bytes=await (await fetch(version+'/life.wasm')).arrayBuffer();
        modules[version]=(await WebAssembly.instantiate(bytes,{env:{
          survives:(alive,n)=>rules.survives(alive>>>0,n>>>0)
        }})).instance;
        run(modules[version]);
      }
      const samples=[];
      for(let round=1;round<=11;round++){
        for(const version of round%2?['before','after']:['after','before']){
          const [ms,sum]=run(modules[version]);
          samples.push([round,'Chromium + Wasm',version,'',ms,sum].join(','));
        }
      }
      return samples.join('\n')+'\n';
    });
    fs.writeFileSync('browser.csv','round,tool,variant,compile_object_ms,simulation_ms,checksum\n'+csv);
    console.log('Chromium',browser.version());
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
