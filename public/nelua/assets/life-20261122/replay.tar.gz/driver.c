#include <stdint.h>
#include <stdio.h>
#include <time.h>
uint32_t next_row(uint32_t, uint32_t, uint32_t);
uint32_t survives(uint32_t alive, uint32_t count) {
  return count == 3 || (alive && count == 2);
}
static double now(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return ts.tv_sec + ts.tv_nsec * 1e-9;
}
int main(void) {
  uint16_t boards[2][16];
  uint32_t seed = 42, hash = 0;
  double start = now();
  for (unsigned gen = 0; gen < 16384; gen++) {
    uint16_t *rows = boards[gen % 2], *out = boards[(gen+1) % 2];
    if (gen % 64 == 0) {
      for (unsigned y=0; y<16; y++) {
        seed = seed * 1664525u + 1013904223u;
        rows[y] = seed >> 16;
      }
    }
    for (unsigned y=0; y<16; y++) {
      out[y] = next_row(rows[(y+15)%16], rows[y], rows[(y+1)%16]);
      hash = hash * 31 + out[y];
    }
  }
  printf("%.6f %u\n", (now()-start)*1000, hash);
}
