import csv, os, random, subprocess, time
from pathlib import Path

def command(args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)

compilers = {
    'TinyCC':[os.getenv('TCC','tcc')], 'necc':[os.getenv('NECC','necc')],
    'GCC -O2':[os.getenv('GCC','gcc'),'-O2'], 'Clang -O2':['clang','-O2'],
}
command([os.getenv('GCC','gcc'),'-O2','-c','driver.c','-o','driver.o'])
tasks = [(tool,ver) for tool in [*compilers,'Node + Wasm'] for ver in ['before','after']]
rng = random.Random(42)
with open('samples.csv','w',newline='') as f:
    out=csv.writer(f)
    out.writerow(['round','tool','variant','compile_object_ms','simulation_ms','checksum'])
    expected=None
    for rnd in range(12):
        rng.shuffle(tasks)
        for tool,ver in tasks:
            compile_ms=''
            if tool in compilers:
                start=time.perf_counter_ns()
                command([*compilers[tool],'-c',ver+'/life.c','-o','kernel.o'])
                compile_ms=round((time.perf_counter_ns()-start)/1e6,6)
                command([os.getenv('GCC','gcc'),'-no-pie','driver.o','kernel.o','-o','simulate'])
                args=['./simulate']
            else:
                args=['node','wasm.mjs',ver+'/life.wasm']
            elapsed,checksum=command(args,stdout=subprocess.PIPE,text=True).stdout.split()
            if expected is None: expected=checksum
            assert checksum==expected,(tool,ver,checksum,expected)
            if rnd: out.writerow([rnd,tool,ver,compile_ms,elapsed,checksum])
