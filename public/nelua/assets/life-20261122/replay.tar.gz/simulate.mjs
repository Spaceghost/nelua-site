export function run(instance){
  const boards = [new Uint16Array(16),new Uint16Array(16)];
  let seed=42, hash=0;
  const start=performance.now();
  for(let gen=0;gen<16384;gen++){
    const rows=boards[gen%2], out=boards[(gen+1)%2];
    if(gen%64===0) for(let y=0;y<16;y++){
      seed=(Math.imul(seed,1664525)+1013904223)>>>0;
      rows[y]=seed>>>16;
    }
    for(let y=0;y<16;y++){
      out[y]=instance.exports.next_row(rows[(y+15)%16],rows[y],rows[(y+1)%16]);
      hash=(Math.imul(hash,31)+out[y])>>>0;
    }
  }
  return [performance.now()-start,hash];
}
