import {run} from './simulate.mjs';
import fs from 'node:fs';
import rules from './rule.mjs';
const {instance} = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]), {env:{
  survives:(alive, count)=>rules.survives(alive >>> 0, count >>> 0)
}});
run(instance);
console.log(...run(instance));
