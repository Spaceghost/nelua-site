.text
.globl work
work:
 sub $8,%rsp
 mov $39,%edi
 xor %esi,%esi
 xor %edx,%edx
 xor %ecx,%ecx
 call nelibc_raw_syscall3
 add $8,%rsp
 test %rax,%rax
 jle 1f
 mov $42,%eax
 ret
1: xor %eax,%eax
 ret
.section .note.GNU-stack,"",@progbits
