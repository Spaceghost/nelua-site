.text
.globl work
work:
 call part1
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
