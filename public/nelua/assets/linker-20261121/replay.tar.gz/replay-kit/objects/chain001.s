.text
.globl part1
part1:
 call part2
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
