.text
.globl part2
part2:
 call part3
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
