.text
.globl part3
part3:
 call part4
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
