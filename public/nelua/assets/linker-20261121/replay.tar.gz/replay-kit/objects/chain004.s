.text
.globl part4
part4:
 call part5
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
