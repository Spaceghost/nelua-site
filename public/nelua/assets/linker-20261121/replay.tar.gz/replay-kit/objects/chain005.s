.text
.globl part5
part5:
 call part6
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
