.text
.globl part6
part6:
 call part7
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
