.text
.globl part7
part7:
 call part8
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
