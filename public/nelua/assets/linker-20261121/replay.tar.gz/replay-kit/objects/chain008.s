.text
.globl part8
part8:
 call part9
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
