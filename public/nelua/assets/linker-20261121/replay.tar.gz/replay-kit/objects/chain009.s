.text
.globl part9
part9:
 call part10
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
