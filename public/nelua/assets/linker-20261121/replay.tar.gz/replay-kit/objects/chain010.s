.text
.globl part10
part10:
 call part11
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
