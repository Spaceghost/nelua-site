.text
.globl part11
part11:
 call part12
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
