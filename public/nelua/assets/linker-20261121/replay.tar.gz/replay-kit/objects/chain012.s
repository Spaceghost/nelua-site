.text
.globl part12
part12:
 call part13
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
