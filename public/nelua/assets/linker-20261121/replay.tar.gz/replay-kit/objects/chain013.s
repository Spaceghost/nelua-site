.text
.globl part13
part13:
 call part14
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
