.text
.globl part14
part14:
 call part15
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
