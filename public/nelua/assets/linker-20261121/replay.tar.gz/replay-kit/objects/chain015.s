.text
.globl part15
part15:
 call part16
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
