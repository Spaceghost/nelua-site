.text
.globl part16
part16:
 call part17
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
