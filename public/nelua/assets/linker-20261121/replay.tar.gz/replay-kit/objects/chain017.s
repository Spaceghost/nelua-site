.text
.globl part17
part17:
 call part18
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
