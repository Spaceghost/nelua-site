.text
.globl part18
part18:
 call part19
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
