.text
.globl part19
part19:
 call part20
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
