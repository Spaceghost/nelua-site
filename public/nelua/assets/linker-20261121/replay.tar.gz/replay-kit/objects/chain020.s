.text
.globl part20
part20:
 call part21
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
