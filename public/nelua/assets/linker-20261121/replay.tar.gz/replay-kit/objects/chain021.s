.text
.globl part21
part21:
 call part22
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
