.text
.globl part22
part22:
 call part23
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
