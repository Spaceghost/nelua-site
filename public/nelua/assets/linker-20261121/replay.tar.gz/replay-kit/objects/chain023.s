.text
.globl part23
part23:
 call part24
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
