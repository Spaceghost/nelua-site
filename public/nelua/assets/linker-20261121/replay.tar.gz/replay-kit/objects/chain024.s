.text
.globl part24
part24:
 call part25
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
