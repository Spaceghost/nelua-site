.text
.globl part25
part25:
 call part26
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
