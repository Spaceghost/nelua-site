.text
.globl part26
part26:
 call part27
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
