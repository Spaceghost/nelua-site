.text
.globl part27
part27:
 call part28
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
