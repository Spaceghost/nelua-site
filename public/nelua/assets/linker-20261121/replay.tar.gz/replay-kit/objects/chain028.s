.text
.globl part28
part28:
 call part29
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
