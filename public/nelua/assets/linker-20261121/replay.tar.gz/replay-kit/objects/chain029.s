.text
.globl part29
part29:
 call part30
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
