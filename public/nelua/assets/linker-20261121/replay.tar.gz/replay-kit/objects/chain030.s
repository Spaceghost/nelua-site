.text
.globl part30
part30:
 call part31
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
