.text
.globl part31
part31:
 call part32
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
