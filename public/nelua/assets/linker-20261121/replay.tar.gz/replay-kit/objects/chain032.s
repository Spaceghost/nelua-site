.text
.globl part32
part32:
 call part33
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
