.text
.globl part33
part33:
 call part34
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
