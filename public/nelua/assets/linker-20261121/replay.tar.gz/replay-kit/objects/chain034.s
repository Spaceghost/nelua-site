.text
.globl part34
part34:
 call part35
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
