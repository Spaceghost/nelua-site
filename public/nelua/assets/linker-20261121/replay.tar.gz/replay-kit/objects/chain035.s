.text
.globl part35
part35:
 call part36
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
