.text
.globl part36
part36:
 call part37
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
