.text
.globl part37
part37:
 call part38
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
