.text
.globl part38
part38:
 call part39
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
