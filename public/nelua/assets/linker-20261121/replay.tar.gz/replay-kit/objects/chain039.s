.text
.globl part39
part39:
 call part40
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
