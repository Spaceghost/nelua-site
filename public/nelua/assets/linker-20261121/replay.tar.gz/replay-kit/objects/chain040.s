.text
.globl part40
part40:
 call part41
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
