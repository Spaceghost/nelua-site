.text
.globl part41
part41:
 call part42
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
