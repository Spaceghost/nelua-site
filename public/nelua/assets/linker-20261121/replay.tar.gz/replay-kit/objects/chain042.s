.text
.globl part42
part42:
 call part43
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
