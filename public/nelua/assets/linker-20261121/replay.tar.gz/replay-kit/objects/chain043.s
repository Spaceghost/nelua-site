.text
.globl part43
part43:
 call part44
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
