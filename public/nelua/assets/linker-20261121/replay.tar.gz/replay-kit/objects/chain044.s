.text
.globl part44
part44:
 call part45
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
