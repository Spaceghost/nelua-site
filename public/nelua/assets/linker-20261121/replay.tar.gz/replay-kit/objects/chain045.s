.text
.globl part45
part45:
 call part46
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
