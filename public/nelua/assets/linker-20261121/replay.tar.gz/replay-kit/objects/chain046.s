.text
.globl part46
part46:
 call part47
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
