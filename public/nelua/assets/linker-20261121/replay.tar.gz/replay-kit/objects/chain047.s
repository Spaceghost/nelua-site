.text
.globl part47
part47:
 call part48
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
