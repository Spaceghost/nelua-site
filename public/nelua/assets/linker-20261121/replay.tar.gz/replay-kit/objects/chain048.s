.text
.globl part48
part48:
 call part49
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
