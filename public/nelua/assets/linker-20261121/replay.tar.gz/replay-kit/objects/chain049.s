.text
.globl part49
part49:
 call part50
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
