.text
.globl part50
part50:
 call part51
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
