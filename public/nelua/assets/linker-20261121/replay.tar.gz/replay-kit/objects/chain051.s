.text
.globl part51
part51:
 call part52
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
