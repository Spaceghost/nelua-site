.text
.globl part52
part52:
 call part53
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
