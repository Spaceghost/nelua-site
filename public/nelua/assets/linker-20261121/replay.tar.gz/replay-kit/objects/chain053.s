.text
.globl part53
part53:
 call part54
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
