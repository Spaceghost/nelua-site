.text
.globl part54
part54:
 call part55
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
