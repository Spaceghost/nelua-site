.text
.globl part55
part55:
 call part56
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
