.text
.globl part56
part56:
 call part57
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
