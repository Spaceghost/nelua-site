.text
.globl part57
part57:
 call part58
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
