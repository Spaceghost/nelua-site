.text
.globl part58
part58:
 call part59
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
