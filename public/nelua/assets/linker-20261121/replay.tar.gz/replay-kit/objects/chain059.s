.text
.globl part59
part59:
 call part60
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
