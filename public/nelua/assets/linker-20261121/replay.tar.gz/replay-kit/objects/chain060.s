.text
.globl part60
part60:
 call part61
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
