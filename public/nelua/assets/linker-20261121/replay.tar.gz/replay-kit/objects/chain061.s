.text
.globl part61
part61:
 call part62
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
