.text
.globl part62
part62:
 call part63
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
