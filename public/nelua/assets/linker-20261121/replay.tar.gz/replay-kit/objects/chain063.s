.text
.globl part63
part63:
 call part64
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
