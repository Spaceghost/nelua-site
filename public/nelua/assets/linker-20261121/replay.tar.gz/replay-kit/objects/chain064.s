.text
.globl part64
part64:
 call part65
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
