.text
.globl part65
part65:
 call part66
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
