.text
.globl part66
part66:
 call part67
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
