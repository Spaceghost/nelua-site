.text
.globl part67
part67:
 call part68
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
