.text
.globl part68
part68:
 call part69
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
