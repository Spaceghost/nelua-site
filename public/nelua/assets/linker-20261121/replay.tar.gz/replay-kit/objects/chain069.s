.text
.globl part69
part69:
 call part70
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
