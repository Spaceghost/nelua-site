.text
.globl part70
part70:
 call part71
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
