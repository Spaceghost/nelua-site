.text
.globl part71
part71:
 call part72
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
