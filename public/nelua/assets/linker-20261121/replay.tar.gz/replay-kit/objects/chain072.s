.text
.globl part72
part72:
 call part73
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
