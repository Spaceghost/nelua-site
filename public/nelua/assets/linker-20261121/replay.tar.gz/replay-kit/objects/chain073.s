.text
.globl part73
part73:
 call part74
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
