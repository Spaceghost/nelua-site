.text
.globl part74
part74:
 call part75
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
