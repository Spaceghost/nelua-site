.text
.globl part75
part75:
 call part76
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
