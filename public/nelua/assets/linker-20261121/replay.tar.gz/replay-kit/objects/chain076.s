.text
.globl part76
part76:
 call part77
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
