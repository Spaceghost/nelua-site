.text
.globl part77
part77:
 call part78
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
