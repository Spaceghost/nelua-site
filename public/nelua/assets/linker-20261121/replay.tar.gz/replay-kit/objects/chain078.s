.text
.globl part78
part78:
 call part79
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
