.text
.globl part79
part79:
 call part80
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
