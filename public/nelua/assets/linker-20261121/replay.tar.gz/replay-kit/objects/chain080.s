.text
.globl part80
part80:
 call part81
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
