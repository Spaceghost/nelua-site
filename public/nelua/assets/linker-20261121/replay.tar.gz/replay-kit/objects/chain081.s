.text
.globl part81
part81:
 call part82
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
