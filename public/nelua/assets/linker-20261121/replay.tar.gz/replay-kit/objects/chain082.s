.text
.globl part82
part82:
 call part83
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
