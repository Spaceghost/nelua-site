.text
.globl part83
part83:
 call part84
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
