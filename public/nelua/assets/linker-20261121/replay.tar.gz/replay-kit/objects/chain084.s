.text
.globl part84
part84:
 call part85
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
