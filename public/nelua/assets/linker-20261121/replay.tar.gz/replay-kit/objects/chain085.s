.text
.globl part85
part85:
 call part86
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
