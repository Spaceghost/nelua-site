.text
.globl part86
part86:
 call part87
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
