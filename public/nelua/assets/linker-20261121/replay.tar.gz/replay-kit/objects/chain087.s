.text
.globl part87
part87:
 call part88
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
