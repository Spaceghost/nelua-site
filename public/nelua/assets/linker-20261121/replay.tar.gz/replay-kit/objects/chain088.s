.text
.globl part88
part88:
 call part89
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
