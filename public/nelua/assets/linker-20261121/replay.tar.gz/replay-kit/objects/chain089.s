.text
.globl part89
part89:
 call part90
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
