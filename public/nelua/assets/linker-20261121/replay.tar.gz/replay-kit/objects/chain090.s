.text
.globl part90
part90:
 call part91
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
