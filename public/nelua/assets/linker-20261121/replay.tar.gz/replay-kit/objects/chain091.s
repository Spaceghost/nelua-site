.text
.globl part91
part91:
 call part92
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
