.text
.globl part92
part92:
 call part93
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
