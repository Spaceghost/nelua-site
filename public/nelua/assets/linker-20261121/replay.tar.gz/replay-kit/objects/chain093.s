.text
.globl part93
part93:
 call part94
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
