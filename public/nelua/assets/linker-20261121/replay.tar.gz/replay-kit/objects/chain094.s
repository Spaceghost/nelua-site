.text
.globl part94
part94:
 call part95
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
