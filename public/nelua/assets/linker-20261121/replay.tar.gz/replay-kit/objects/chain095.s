.text
.globl part95
part95:
 call part96
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
