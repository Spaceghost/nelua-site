.text
.globl part96
part96:
 call part97
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
