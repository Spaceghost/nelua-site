.text
.globl part97
part97:
 call part98
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
