.text
.globl part98
part98:
 call part99
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
