.text
.globl part99
part99:
 call part100
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
