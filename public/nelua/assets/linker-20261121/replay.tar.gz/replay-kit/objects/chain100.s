.text
.globl part100
part100:
 call part101
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
