.text
.globl part101
part101:
 call part102
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
