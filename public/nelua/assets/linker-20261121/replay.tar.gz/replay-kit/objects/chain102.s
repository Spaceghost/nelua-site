.text
.globl part102
part102:
 call part103
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
