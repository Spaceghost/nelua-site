.text
.globl part103
part103:
 call part104
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
