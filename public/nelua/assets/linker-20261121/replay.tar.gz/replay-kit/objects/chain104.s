.text
.globl part104
part104:
 call part105
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
