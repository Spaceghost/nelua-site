.text
.globl part105
part105:
 call part106
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
