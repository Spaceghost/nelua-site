.text
.globl part106
part106:
 call part107
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
