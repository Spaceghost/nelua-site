.text
.globl part107
part107:
 call part108
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
