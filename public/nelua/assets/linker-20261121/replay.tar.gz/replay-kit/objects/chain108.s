.text
.globl part108
part108:
 call part109
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
