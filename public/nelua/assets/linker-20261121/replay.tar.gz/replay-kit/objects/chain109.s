.text
.globl part109
part109:
 call part110
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
