.text
.globl part110
part110:
 call part111
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
