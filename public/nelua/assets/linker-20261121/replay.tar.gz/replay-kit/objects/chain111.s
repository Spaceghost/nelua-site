.text
.globl part111
part111:
 call part112
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
