.text
.globl part112
part112:
 call part113
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
