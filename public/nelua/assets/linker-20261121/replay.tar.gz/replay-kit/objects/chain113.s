.text
.globl part113
part113:
 call part114
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
