.text
.globl part114
part114:
 call part115
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
