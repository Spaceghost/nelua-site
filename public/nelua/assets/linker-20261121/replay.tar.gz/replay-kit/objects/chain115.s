.text
.globl part115
part115:
 call part116
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
