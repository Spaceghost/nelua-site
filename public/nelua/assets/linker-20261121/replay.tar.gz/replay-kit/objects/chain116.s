.text
.globl part116
part116:
 call part117
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
