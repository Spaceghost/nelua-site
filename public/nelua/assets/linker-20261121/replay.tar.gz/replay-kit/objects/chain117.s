.text
.globl part117
part117:
 call part118
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
