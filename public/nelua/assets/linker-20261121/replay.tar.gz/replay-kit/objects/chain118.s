.text
.globl part118
part118:
 call part119
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
