.text
.globl part119
part119:
 call part120
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
