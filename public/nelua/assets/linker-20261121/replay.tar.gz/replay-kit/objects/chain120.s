.text
.globl part120
part120:
 call part121
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
