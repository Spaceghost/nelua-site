.text
.globl part121
part121:
 call part122
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
