.text
.globl part122
part122:
 call part123
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
