.text
.globl part123
part123:
 call part124
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
