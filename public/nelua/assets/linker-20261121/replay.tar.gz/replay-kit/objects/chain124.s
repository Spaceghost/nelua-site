.text
.globl part124
part124:
 call part125
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
