.text
.globl part125
part125:
 call part126
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
