.text
.globl part126
part126:
 call part127
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
