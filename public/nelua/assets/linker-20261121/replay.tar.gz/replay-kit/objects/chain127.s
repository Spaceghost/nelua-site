.text
.globl part127
part127:
 call part128
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
