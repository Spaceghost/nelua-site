.text
.globl part128
part128:
 call part129
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
