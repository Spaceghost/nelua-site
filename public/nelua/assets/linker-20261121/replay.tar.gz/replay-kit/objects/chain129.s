.text
.globl part129
part129:
 call part130
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
