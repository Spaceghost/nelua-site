.text
.globl part130
part130:
 call part131
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
