.text
.globl part131
part131:
 call part132
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
