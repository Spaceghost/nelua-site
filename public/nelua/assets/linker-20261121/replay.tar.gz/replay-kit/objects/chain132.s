.text
.globl part132
part132:
 call part133
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
