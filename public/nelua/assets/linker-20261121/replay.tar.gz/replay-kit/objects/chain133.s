.text
.globl part133
part133:
 call part134
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
