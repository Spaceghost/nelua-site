.text
.globl part134
part134:
 call part135
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
