.text
.globl part135
part135:
 call part136
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
