.text
.globl part136
part136:
 call part137
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
