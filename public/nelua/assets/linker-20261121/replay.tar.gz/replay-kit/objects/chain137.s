.text
.globl part137
part137:
 call part138
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
