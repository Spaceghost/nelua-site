.text
.globl part138
part138:
 call part139
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
