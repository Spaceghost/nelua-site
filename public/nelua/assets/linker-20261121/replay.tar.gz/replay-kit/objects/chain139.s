.text
.globl part139
part139:
 call part140
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
