.text
.globl part140
part140:
 call part141
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
