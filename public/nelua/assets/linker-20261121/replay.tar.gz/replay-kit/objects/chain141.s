.text
.globl part141
part141:
 call part142
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
