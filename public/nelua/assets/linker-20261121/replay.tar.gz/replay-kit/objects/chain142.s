.text
.globl part142
part142:
 call part143
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
