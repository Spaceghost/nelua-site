.text
.globl part143
part143:
 call part144
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
