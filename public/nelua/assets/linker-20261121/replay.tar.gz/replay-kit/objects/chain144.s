.text
.globl part144
part144:
 call part145
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
