.text
.globl part145
part145:
 call part146
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
