.text
.globl part146
part146:
 call part147
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
