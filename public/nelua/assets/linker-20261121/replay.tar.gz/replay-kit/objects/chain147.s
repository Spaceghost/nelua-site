.text
.globl part147
part147:
 call part148
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
