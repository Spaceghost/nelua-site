.text
.globl part148
part148:
 call part149
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
