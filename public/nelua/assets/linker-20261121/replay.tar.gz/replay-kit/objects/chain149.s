.text
.globl part149
part149:
 call part150
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
