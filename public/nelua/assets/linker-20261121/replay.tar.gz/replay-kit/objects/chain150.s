.text
.globl part150
part150:
 call part151
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
