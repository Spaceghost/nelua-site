.text
.globl part151
part151:
 call part152
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
