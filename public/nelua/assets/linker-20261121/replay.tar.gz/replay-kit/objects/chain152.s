.text
.globl part152
part152:
 call part153
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
