.text
.globl part153
part153:
 call part154
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
