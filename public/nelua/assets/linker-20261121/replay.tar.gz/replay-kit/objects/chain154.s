.text
.globl part154
part154:
 call part155
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
