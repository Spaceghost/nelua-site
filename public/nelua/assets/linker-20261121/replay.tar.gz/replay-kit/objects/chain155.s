.text
.globl part155
part155:
 call part156
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
