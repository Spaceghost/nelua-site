.text
.globl part156
part156:
 call part157
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
