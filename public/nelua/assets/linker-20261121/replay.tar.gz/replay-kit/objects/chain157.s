.text
.globl part157
part157:
 call part158
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
