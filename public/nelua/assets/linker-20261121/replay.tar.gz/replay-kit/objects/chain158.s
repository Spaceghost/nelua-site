.text
.globl part158
part158:
 call part159
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
