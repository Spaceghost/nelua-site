.text
.globl part160
part160:
 call part161
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
