.text
.globl part161
part161:
 call part162
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
