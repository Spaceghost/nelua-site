.text
.globl part162
part162:
 call part163
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
