.text
.globl part163
part163:
 call part164
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
