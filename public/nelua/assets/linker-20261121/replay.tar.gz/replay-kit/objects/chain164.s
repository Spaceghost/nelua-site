.text
.globl part164
part164:
 call part165
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
