.text
.globl part165
part165:
 call part166
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
