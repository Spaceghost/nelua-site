.text
.globl part166
part166:
 call part167
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
