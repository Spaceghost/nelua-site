.text
.globl part167
part167:
 call part168
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
