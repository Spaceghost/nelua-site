.text
.globl part168
part168:
 call part169
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
