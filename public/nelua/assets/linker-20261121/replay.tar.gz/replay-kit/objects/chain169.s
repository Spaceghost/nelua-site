.text
.globl part169
part169:
 call part170
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
