.text
.globl part170
part170:
 call part171
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
