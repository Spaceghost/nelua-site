.text
.globl part171
part171:
 call part172
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
