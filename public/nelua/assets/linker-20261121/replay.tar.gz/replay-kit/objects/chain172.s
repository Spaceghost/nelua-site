.text
.globl part172
part172:
 call part173
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
