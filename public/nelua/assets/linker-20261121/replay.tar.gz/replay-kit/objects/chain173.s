.text
.globl part173
part173:
 call part174
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
