.text
.globl part174
part174:
 call part175
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
