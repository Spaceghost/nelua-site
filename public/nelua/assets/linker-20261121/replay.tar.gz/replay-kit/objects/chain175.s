.text
.globl part175
part175:
 call part176
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
