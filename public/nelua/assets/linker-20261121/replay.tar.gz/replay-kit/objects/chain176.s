.text
.globl part176
part176:
 call part177
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
