.text
.globl part177
part177:
 call part178
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
