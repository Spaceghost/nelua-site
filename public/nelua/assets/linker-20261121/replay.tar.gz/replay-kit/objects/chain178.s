.text
.globl part178
part178:
 call part179
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
