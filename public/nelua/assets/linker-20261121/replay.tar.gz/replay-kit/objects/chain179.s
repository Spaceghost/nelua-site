.text
.globl part179
part179:
 call part180
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
