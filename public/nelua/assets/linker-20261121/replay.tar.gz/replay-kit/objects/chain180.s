.text
.globl part180
part180:
 call part181
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
