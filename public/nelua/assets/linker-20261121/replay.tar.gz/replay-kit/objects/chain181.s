.text
.globl part181
part181:
 call part182
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
