.text
.globl part182
part182:
 call part183
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
