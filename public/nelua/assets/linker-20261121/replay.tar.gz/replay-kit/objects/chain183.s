.text
.globl part183
part183:
 call part184
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
