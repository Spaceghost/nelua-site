.text
.globl part184
part184:
 call part185
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
