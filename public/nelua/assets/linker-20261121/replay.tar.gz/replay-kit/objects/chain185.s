.text
.globl part185
part185:
 call part186
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
