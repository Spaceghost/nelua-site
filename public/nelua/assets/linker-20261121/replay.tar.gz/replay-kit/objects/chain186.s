.text
.globl part186
part186:
 call part187
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
