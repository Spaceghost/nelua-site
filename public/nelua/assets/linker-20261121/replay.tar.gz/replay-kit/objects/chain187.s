.text
.globl part187
part187:
 call part188
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
