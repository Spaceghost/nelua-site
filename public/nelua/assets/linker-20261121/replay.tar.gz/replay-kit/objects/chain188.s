.text
.globl part188
part188:
 call part189
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
