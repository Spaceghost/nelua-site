.text
.globl part189
part189:
 call part190
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
