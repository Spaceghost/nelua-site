.text
.globl part190
part190:
 call part191
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
