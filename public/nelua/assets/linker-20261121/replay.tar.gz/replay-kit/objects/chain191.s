.text
.globl part191
part191:
 call part192
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
