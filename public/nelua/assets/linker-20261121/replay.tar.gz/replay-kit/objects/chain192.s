.text
.globl part192
part192:
 call part193
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
