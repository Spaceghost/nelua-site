.text
.globl part193
part193:
 call part194
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
