.text
.globl part194
part194:
 call part195
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
