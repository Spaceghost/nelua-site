.text
.globl part195
part195:
 call part196
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
