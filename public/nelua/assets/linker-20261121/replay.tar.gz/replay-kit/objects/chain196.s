.text
.globl part196
part196:
 call part197
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
