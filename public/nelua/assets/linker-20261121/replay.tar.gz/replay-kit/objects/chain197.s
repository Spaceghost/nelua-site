.text
.globl part197
part197:
 call part198
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
