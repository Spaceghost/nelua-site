.text
.globl part198
part198:
 call part199
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
