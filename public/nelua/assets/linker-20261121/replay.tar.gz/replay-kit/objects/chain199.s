.text
.globl part199
part199:
 call part200
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
