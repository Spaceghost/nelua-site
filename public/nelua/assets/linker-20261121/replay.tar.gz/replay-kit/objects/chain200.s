.text
.globl part200
part200:
 call part201
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
