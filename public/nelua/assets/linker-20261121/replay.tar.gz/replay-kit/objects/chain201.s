.text
.globl part201
part201:
 call part202
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
