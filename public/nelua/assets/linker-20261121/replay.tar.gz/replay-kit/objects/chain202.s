.text
.globl part202
part202:
 call part203
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
