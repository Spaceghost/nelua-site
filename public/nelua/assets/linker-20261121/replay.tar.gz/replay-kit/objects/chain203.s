.text
.globl part203
part203:
 call part204
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
