.text
.globl part204
part204:
 call part205
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
