.text
.globl part205
part205:
 call part206
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
