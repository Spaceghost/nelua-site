.text
.globl part206
part206:
 call part207
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
