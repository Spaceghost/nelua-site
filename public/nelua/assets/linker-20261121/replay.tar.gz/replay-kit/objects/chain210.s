.text
.globl part210
part210:
 call part211
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
