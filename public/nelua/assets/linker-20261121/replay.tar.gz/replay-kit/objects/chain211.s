.text
.globl part211
part211:
 call part212
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
