.text
.globl part212
part212:
 call part213
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
