.text
.globl part213
part213:
 call part214
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
