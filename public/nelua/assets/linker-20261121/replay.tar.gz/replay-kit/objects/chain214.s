.text
.globl part214
part214:
 call part215
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
