.text
.globl part215
part215:
 call part216
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
