.text
.globl part216
part216:
 call part217
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
