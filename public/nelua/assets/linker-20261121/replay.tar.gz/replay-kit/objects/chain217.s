.text
.globl part217
part217:
 call part218
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
