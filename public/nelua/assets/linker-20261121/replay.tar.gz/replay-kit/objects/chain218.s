.text
.globl part218
part218:
 call part219
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
