.text
.globl part219
part219:
 call part220
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
