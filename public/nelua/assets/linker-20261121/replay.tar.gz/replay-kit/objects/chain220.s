.text
.globl part220
part220:
 call part221
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
