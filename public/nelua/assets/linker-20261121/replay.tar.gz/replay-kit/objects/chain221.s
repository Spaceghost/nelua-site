.text
.globl part221
part221:
 call part222
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
