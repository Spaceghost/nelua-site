.text
.globl part222
part222:
 call part223
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
