.text
.globl part223
part223:
 call part224
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
