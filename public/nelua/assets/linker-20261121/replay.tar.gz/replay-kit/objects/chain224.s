.text
.globl part224
part224:
 call part225
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
