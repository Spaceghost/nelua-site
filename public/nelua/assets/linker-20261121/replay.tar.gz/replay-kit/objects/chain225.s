.text
.globl part225
part225:
 call part226
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
