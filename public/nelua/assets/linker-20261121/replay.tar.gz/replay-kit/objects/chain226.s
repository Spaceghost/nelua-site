.text
.globl part226
part226:
 call part227
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
