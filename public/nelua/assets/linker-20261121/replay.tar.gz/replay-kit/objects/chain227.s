.text
.globl part227
part227:
 call part228
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
