.text
.globl part228
part228:
 call part229
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
