.text
.globl part229
part229:
 call part230
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
