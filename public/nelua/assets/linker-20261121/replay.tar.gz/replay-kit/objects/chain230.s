.text
.globl part230
part230:
 call part231
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
