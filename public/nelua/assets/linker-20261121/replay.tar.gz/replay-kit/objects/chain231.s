.text
.globl part231
part231:
 call part232
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
