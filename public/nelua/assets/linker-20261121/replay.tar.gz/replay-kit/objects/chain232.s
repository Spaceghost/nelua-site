.text
.globl part232
part232:
 call part233
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
