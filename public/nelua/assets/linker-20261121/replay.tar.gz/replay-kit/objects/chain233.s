.text
.globl part233
part233:
 call part234
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
