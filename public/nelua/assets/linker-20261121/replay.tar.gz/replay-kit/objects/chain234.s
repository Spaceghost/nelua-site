.text
.globl part234
part234:
 call part235
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
