.text
.globl part235
part235:
 call part236
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
