.text
.globl part236
part236:
 call part237
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
