.text
.globl part237
part237:
 call part238
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
