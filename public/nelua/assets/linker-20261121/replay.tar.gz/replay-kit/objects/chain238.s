.text
.globl part238
part238:
 call part239
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
