.text
.globl part239
part239:
 call part240
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
