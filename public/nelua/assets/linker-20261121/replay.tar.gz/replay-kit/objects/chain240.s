.text
.globl part240
part240:
 call part241
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
