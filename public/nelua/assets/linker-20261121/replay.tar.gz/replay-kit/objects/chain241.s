.text
.globl part241
part241:
 call part242
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
