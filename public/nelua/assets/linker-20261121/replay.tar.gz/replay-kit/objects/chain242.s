.text
.globl part242
part242:
 call part243
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
