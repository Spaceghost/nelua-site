.text
.globl part243
part243:
 call part244
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
