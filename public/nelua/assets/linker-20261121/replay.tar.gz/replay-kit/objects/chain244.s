.text
.globl part244
part244:
 call part245
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
