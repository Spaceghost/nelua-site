.text
.globl part245
part245:
 call part246
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
