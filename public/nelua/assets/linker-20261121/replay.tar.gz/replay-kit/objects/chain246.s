.text
.globl part246
part246:
 call part247
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
