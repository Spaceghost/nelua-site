.text
.globl part247
part247:
 call part248
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
