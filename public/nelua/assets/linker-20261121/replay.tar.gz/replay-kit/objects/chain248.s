.text
.globl part248
part248:
 call part249
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
