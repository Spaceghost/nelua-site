.text
.globl part249
part249:
 call part250
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
