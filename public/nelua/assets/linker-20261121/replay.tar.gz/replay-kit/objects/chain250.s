.text
.globl part250
part250:
 call part251
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
