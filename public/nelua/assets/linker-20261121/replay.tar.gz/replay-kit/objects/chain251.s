.text
.globl part251
part251:
 call part252
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
