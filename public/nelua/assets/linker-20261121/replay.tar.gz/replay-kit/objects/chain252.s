.text
.globl part252
part252:
 call part253
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
