.text
.globl part253
part253:
 call part254
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
