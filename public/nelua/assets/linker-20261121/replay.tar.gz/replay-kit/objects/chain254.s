.text
.globl part254
part254:
 call part255
 add $1,%eax
 ret
.section .note.GNU-stack,"",@progbits
