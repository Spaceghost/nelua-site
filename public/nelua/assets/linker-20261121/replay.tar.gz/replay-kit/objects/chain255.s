.text
.globl part255
part255:
 mov $43,%eax
 ret
.section .note.GNU-stack,"",@progbits
