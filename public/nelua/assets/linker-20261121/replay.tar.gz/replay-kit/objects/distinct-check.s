.text
.globl work
work:
 lea distinct_table(%rip),%rsi
 lea value0000(%rip),%rdx
 xor %ecx,%ecx
.Lagain:
 cmp %rdx,(%rsi,%rcx,8)
 jne .Lbad
 cmp %ecx,(%rdx)
 jne .Lbad
 add $4,%rdx
 inc %ecx
 cmp $8192,%ecx
 jne .Lagain
 mov $42,%eax
 ret
.Lbad:
 xor %eax,%eax
 ret
.section .note.GNU-stack,"",@progbits
