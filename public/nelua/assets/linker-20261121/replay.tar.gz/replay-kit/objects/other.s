.text
.globl other
other:
 mov $40,%eax
 ret
.section .note.GNU-stack,"",@progbits
