.text
.globl work
work:
 lea table(%rip),%rcx
 lea target(%rip),%rdx
 mov $32768,%esi
.Lagain:
 cmp %rdx,(%rcx)
 jne .Lbad
 add $8,%rcx
 dec %esi
 jne .Lagain
 mov (%rdx),%eax
 ret
.Lbad:
 xor %eax,%eax
 ret
.section .rodata
.globl target
target: .long 42
.section .note.GNU-stack,"",@progbits
