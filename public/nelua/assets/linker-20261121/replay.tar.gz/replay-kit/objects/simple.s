.text
.globl work
work:
 call other
 add $2,%eax
 ret
.section .note.GNU-stack,"",@progbits
