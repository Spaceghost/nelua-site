.text
.globl work
work:
 mov $39,%edi
 xor %esi,%esi
 xor %edx,%edx
 xor %ecx,%ecx
 sub $8,%rsp
 call nelibc_raw_syscall3
 add $8,%rsp
 test %rax,%rax
 jle .Lbad
 mov $42,%eax
 ret
.Lbad:
 xor %eax,%eax
 ret
.section .note.GNU-stack,"",@progbits
