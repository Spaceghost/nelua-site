.data
.globl table
table:
.rept 32768
.quad target
.endr
.section .note.GNU-stack,"",@progbits
