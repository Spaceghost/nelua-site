"""Replay a timed link command and verify its output using the measured inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('tool', help='nelinker-gcc, nelinker-distro, GNU-bfd, GNU-gold, LLD-14, LLD-22-Zig, TinyCC, mold or Wild')
parser.add_argument('binary', type=lambda p: str(Path(p).resolve(strict=True)))
parser.add_argument('sdk', type=lambda p: Path(p).resolve(strict=True))
parser.add_argument('--case', help='one object or archive case, e.g. archives/reverse-chain-256')
args = parser.parse_args()
root = Path(__file__).resolve().parent
def read(name):
    return json.loads((root/name).read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
checks = read('qualification.json')
commands = read('commands.json')
expected = read('inputs.json')
matched = 0
with tempfile.TemporaryDirectory() as tmp:
    work = Path(tmp)
    fixture = work/'fixtures'
    fixture.mkdir()
    for name in ('objects','archives'):
        (fixture/name).symlink_to(root/name, target_is_directory=True)
    libc = args.sdk/'libnelibc.a'
    (fixture/'sdk-syscall.o').write_bytes(subprocess.check_output(['ar','p',libc,'syscall-asm.o']))
    for name, want in expected.items():
        path = args.sdk / name[4:] if name.startswith('sdk/') else fixture/name
        if digest(path) != want:
            raise SystemExit(f'Input digest differs: {name}')
    output = work/'program'
    for key, options in commands.items():
        case, tool = key.rsplit('/',1)
        if tool != args.tool or args.case and case != args.case:
            continue
        matched += 1
        if not checks[key]['passed']:
            print(case, 'excluded in measured run:', checks[key]['reason'])
            continue
        output.unlink(missing_ok=True)
        cmd = [args.binary, *(x.format(sdk=args.sdk, output=output, fixtures=fixture) for x in options)]
        subprocess.run(cmd, check=True, timeout=35)
        exe = subprocess.run([output], capture_output=True, timeout=2)
        if exe.returncode != 42 or exe.stdout or output.stat().st_size != checks[key]['bytes']:
            raise SystemExit(f'{case}: exit={exe.returncode} bytes={output.stat().st_size} stdout={exe.stdout!r}')
        print(case, 'passed', output.stat().st_size, 'bytes')
if not matched:
    parser.error('No matching workload and tool')
