#!/usr/bin/env python3
"""Classify changes to the linked machine-code bytes of every input function."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
from validate import cases

def body(encoded):
    # Use individual function sections + the checked SDK assembler for local labels/branches.
    # Extracting pre-relocation .text would compare unused displacement placeholders.
    return hashlib.sha256(encoded).hexdigest()

def code_sizes(out, compiler, sdk, label):
    asm=out/(label+'-kernels.s')

    result={}
    for c in cases:
        subprocess.run([compiler,'-S','units/'+c.name+'.c','-o',asm.name],cwd=out,check=True)
        code=asm.read_text()
        name=re.escape(c.name)
        routine=re.search(r'^\.globl '+name+r'\n.*?^\.size '+name+r',\s*\.-'+name+r'\s*$',code,re.M|re.S)
        if not routine: raise RuntimeError(f'missing generated code for {c.name}')
        # Use the same local labels, branch relocations and external-call addresses
        # per compiler. Stub calls are used only to compare bytes; execution uses the real driver.
        src=out/'one.s'
        src.write_text('.text\n'+routine[0].rstrip()+'\n')
        subprocess.run([sdk/'tcc/tcc','-c','one.s','-o','one.o'],cwd=out,check=True,capture_output=True)
        subprocess.run(['ld','-static','-e',c.name,'--defsym','tap=0x401000','--defsym','address_tap=0x401100',
                        '-o','one.elf','one.o'],cwd=out,check=True,capture_output=True)
        subprocess.run(['objcopy','-O','binary','-j','.text','one.elf','one.bin'],cwd=out,check=True)
        data=(out/'one.bin').read_bytes()
        result[c.name]={'bytes':len(data),'sha256':body(data)}
    return result
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('out',type=Path)
    ap.add_argument('sdk',type=Path)
    ap.add_argument('--check',nargs=2,action='append',required=True,metavar=('LABEL','NECC'))
    a=ap.parse_args()
    reports={name:code_sizes(a.out.resolve(),compiler,a.sdk,name) for name,compiler in a.check}
    if len(reports)==2:
        a,b=reports.values()
        reports['changed']=[k for k in a if a[k]['sha256']!=b[k]['sha256']]
    print(json.dumps(reports,indent=2))
