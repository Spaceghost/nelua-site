#!/usr/bin/env python3
"""Exercise Lua's hash routine from the production compiler's complete lstring.c assembly."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

# Keep lexical spellings. Matches of comments and character literals protect
# their contents; neither contributes tokens. No C preprocessing is applied.
TOKENS = re.compile(rb"//[^\n]*|/\*[\s\S]*?\*/|'(?:\\[\s\S]|[^'\\])*'|\"(?:\\[\s\S]|[^\"\\])*\"|[A-Za-z_][A-Za-z_0-9]*")
SEEDS = (0, 19, 0x80000000, 0xffffffff)
MASK = 2**32-1
def sha(data): return hashlib.sha256(data).hexdigest()
def oracle(token, seed):
    h = seed ^ len(token)
    for ch in reversed(token):
        h ^= ((h<<5)+(h>>2)+ch)&MASK
    return h

def read_inputs(lua):
    names = {}
    records = []
    for f in sorted([*lua.glob('*.c'),*lua.glob('*.h')]):
        data = f.read_bytes()
        names[f.name]=sha(data)
        for match in TOKENS.finditer(data):
            token=match.group()
            if token[:1] not in (b'/',b"'"):
                records.append(token)
    return names, records

driver = r'''
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
unsigned int luaS_hash(const char *, size_t, unsigned int);
int main(int argc, char **argv) {
    FILE *f;
    unsigned int lengths, n, loops;
    const unsigned int seeds[4]={0, 19, 0x80000000, 0xffffffff};
    struct entry { unsigned int len; const char *p; } *tokens;
    struct timespec start,end;
    uint64_t checksum=14695981039346656037ULL;
    if (argc!=3 || !(f=fopen(argv[1],"rb"))) return 2;
    if (fread(&n,4,1,f)!=1 || fread(&lengths,4,1,f)!=1 || !n || !lengths) return 3;
    char *bytes=malloc(lengths);
    tokens=calloc(n,sizeof(*tokens));
    if (!bytes || !tokens) return 4;
    size_t offset=0;
    for (size_t t=0;t<n;t++) {
        unsigned int len;
        if (fread(&len,4,1,f)!=1 || len>lengths-offset || fread(bytes+offset,1,len,f)!=len) return 5;
        tokens[t].len=len;
        tokens[t].p=bytes+offset;
        offset+=len;
    }
    if(offset!=lengths || fgetc(f)!=EOF || ferror(f)) return 6;
    fclose(f);
    loops=(unsigned int)strtoul(argv[2],0,10);
    clock_gettime(CLOCK_MONOTONIC_RAW,&start);
    for(unsigned int loop=0;loop<(loops ? loops : 1);loop++) {
        for(size_t t=0;t<n;t++) {
            for (unsigned int s=0;s<4;s++) {
                unsigned int h=luaS_hash(tokens[t].p,tokens[t].len,seeds[s]);
                if(!loops && fwrite(&h,4,1,stdout)!=1) return 7;
                checksum=(checksum^h)*1099511628211ULL;
            }
        }
    }
    clock_gettime(CLOCK_MONOTONIC_RAW,&end);
    if(loops) printf("%llu %llu\n",(unsigned long long)checksum,(unsigned long long)
      ((int64_t)(end.tv_sec-start.tv_sec)*1000000000LL + end.tv_nsec-start.tv_nsec));
    free(bytes);
    free(tokens);
    return 0;
}
'''
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('out',type=Path)
    ap.add_argument('lua',type=Path)
    ap.add_argument('sdk',type=Path)
    ap.add_argument('--check',nargs=2,action='append',required=True,metavar=('NAME','NECC'))
    args=ap.parse_args()
    out=args.out.resolve()
    out.mkdir(parents=True,exist_ok=True)
    names, tokens=read_inputs(args.lua)
    packet=bytearray(struct.pack('<II',len(tokens),sum(map(len,tokens))))
    expected=bytearray()
    for token in tokens:
        packet += struct.pack('<I',len(token)) + token
        expected += struct.pack('<4I',*(oracle(token,seed) for seed in SEEDS))
    (out/'tokens.bin').write_bytes(packet)
    (out/'driver.c').write_text(driver)
    report={'source_sha256':names['lstring.c'],'corpus_files':len(names),
            'corpus_files_sha256':sha(json.dumps(names,sort_keys=True).encode()),
            'tokens':len(tokens),'distinct_tokens':len(set(tokens)), 'hashes_checked':len(tokens)*4,
            'inputs_sha256':sha(packet),'oracle_sha256':sha(expected), 'implementations':{}}
    for label,cc in args.check:
        compiler=[cc,'-DNDEBUG','-DNELIBC_STANDALONE','-isystem',args.lua]
        subprocess.run([*compiler,'-S',args.lua/'lstring.c','-o',label+'-whole.s'],cwd=out,check=True)
        subprocess.run([*compiler,'-c',args.lua/'lstring.c','-o',label+'-whole.o'],cwd=out,check=True)
        assembly=(out/(label+'-whole.s')).read_text()
        match=re.search(r'^\.globl luaS_hash\n.*?^\.size luaS_hash,\s*\.-luaS_hash\s*$',assembly,re.M|re.S)
        if not match: raise RuntimeError('hash routine lacks the expected bounds')
        routine='.text\n'+match.group().strip()+'\n'
        (out/(label+'-hash.s')).write_text(routine)
        subprocess.run([args.sdk/'tcc/tcc','-c',label+'-hash.s','-o',label+'-hash.o'],cwd=out,check=True)
        subprocess.run(['ld','-static','-e','luaS_hash','-o',label+'-routine.elf',label+'-hash.o'],cwd=out,check=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',label+'-routine.elf',label+'-routine.bin'],cwd=out,check=True)
        subprocess.run(['gcc','-no-pie','-Wl,-z,noexecstack','-O2','driver.c',label+'-hash.o','-o',label],cwd=out,check=True)
        run=subprocess.run([out/label,out/'tokens.bin','0'],capture_output=True,check=True,timeout=12)
        if run.stdout!=expected: raise RuntimeError(f'{label}: hash differs from scalar formula')
        report['implementations'][label]={'whole_object_sha256':sha((out/(label+'-whole.o')).read_bytes()),
            'linked_routine_bytes':(out/(label+'-routine.bin')).stat().st_size,
            'linked_routine_sha256':sha((out/(label+'-routine.bin')).read_bytes()),
            'routine_assembly_sha256':sha(routine.encode()),'routine_object_sha256':sha((out/(label+'-hash.o')).read_bytes()),
            'values_sha256':sha(run.stdout)}
    print(json.dumps(report,indent=2))
if __name__=='__main__': main()
