#!/bin/sh
# Run on x86-64 Linux with GNU C/binutils, Python 3.11+, and the frozen fixtures.
set -eu
if [ "$#" != 8 ]; then
  echo "usage: $0 OUTPUT OLD_NECC NEW_NECC SDK FIXTURES LUA_SOURCE FROZEN_ZIG_ELF CPU" >&2
  exit 2
fi
tools=$(CDPATH= cd "$(dirname "$0")" && pwd)
out=$(realpath -m "$1")
old=$(realpath "$2")
new=$(realpath "$3")
export NECC_SYSROOT=$(realpath "$4")
fixtures=$(realpath "$5")
lua=$(realpath "$6")
zig=$(realpath "$7")
cpu=$8
mkdir -p "$out/tmp" "$out/timing"
export TMPDIR=$out/tmp TMP=$out/tmp TEMP=$out/tmp PYTHONDONTWRITEBYTECODE=1
python3 "$tools/validate.py" "$out/differential" --check old "$old" --check new "$new" > "$out/semantic.json"
python3 "$tools/compare-code.py" "$out/differential" "$NECC_SYSROOT" --check old "$old" --check new "$new" > "$out/code.json"
printf '%s\n' '#!/bin/sh' 'exec gcc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined "$@"' > "$out/gcc-ubsan"
chmod +x "$out/gcc-ubsan"
python3 "$tools/validate.py" "$out/gcc-controls" --hostcc "$out/gcc-ubsan" --check ubsan "$out/gcc-ubsan" > "$out/ubsan.json"
python3 "$tools/lua-hash.py" "$out/lua" "$lua" "$NECC_SYSROOT" --check old "$old" --check new "$new" > "$out/lua.json"
for name in old new; do
  case "$name" in old) cc=$old ;; new) cc=$new ;; esac
  "$cc" -c "$fixtures/arithmetic.c" -o "$out/$name.o"
  ld -static -e _start "$fixtures/driver.o" "$out/$name.o" -o "$out/$name.elf"
done
python3 "$tools/timed-runtime.py" "$out/timing" --old "$out/old.elf" --new "$out/new.elf" --zig "$zig" --cpu "$cpu"
python3 "$tools/timed-lua.py" "$out/lua" "$out/timing" --cpu "$cpu"
