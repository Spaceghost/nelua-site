#!/usr/bin/env python3
"""Compare the Lua hash workload using paired, balanced AB/BA launch order."""
import argparse
import csv
import json
import os
from pathlib import Path
import random
import statistics
import subprocess

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('dir', type=Path)
    p.add_argument('out', type=Path)
    p.add_argument('--cpu',type=int,default=5)
    p.add_argument('--repeats',type=int,default=6)
    args=p.parse_args()
    folder=args.dir.resolve()
    args.out.mkdir(parents=True,exist_ok=True)
    os.sched_setaffinity(0,{args.cpu})
    if os.sched_getaffinity(0)!={args.cpu}: raise ValueError('incorrect CPU affinity')
    expected=None
    def sample(label):
        nonlocal expected
        cmd=[folder/label,folder/'tokens.bin',str(args.repeats)]
        r=subprocess.run(cmd,timeout=10,check=True,capture_output=True,text=True)
        checksum, ns = map(int,r.stdout.split())
        if expected is None: expected=checksum
        if checksum!=expected or ns<=0: raise ValueError('hash timed checksum changed')
        return ns
    for label in ('old','new','new','old'): sample(label)
    rows=[]
    paired=[]
    allvalues={'old':[],'new':[]}
    rng=random.Random(65922)
    load=os.getloadavg()
    for block in range(9):
        orders=[('old','new'),('new','old')]
        rng.shuffle(orders)
        for i, order in enumerate(orders):
            values={}
            for label in order:
                ns=sample(label)
                values[label]=ns
                allvalues[label].append(ns)
                rows.append({'round':2*block+i+1,'order':'/'.join(order),'implementation':label,
                             'elapsed_ns':ns,'checksum':expected})
            paired.append(values['old']/values['new'])
    with (args.out/'lua-raw.csv').open('w') as f:
        writer=csv.DictWriter(f,rows[0].keys());writer.writeheader();writer.writerows(rows)
    q=statistics.quantiles(paired,n=4)
    result={'method':'CLOCK_MONOTONIC_RAW inside the consumer, excluding source token input and process startup. Each pair runs both complete loops. Each two-round block uses both AB and BA.',
            'rounds':len(paired),'cpu':args.cpu, 'repeats_per_sample':args.repeats,
            'hashes_per_sample':263688*args.repeats,'checksum':expected,'load_start':load,'load_end':os.getloadavg(),
            'median_ns':{k:statistics.median(v) for k,v in allvalues.items()},
            'paired_old_over_new':{'median':statistics.median(paired),'q1':q[0],'q3':q[2],
                                   'min':min(paired),'max':max(paired)}}
    (args.out/'lua-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
