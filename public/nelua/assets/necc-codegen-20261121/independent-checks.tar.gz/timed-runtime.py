#!/usr/bin/env python3
"""Warm, blocked-randomized runtimes for the original six-million iteration ELF."""
import argparse
import csv
import hashlib
import itertools
import json
import os
from pathlib import Path
import random
import statistics
import struct
import subprocess
import time

FROZEN_ZIG='f72abe2893b6b6e64bc52a9abe06ab0f34d34c8b801e86dd814b616092f487e9'
def digest(f): return hashlib.sha256(f.read_bytes()).hexdigest()
def quantiles(nums):
    return {'median':statistics.median(nums),'q1':statistics.quantiles(nums,n=4)[0],
            'q3':statistics.quantiles(nums,n=4)[2],'min':min(nums),'max':max(nums)}

def time_one(binary,expected):
    start=time.perf_counter_ns()
    r=subprocess.run([str(binary.resolve())],stdin=subprocess.DEVNULL,capture_output=True,timeout=2)
    elapsed=time.perf_counter_ns()-start
    if r.returncode or r.stdout!=expected or r.stderr:
        raise RuntimeError(f'{binary.name}: output/status differs from the original driver contract')
    return elapsed

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('out',type=Path)
    for k in ('old','new','zig'): p.add_argument('--'+k,type=Path,required=True)
    p.add_argument('--blocks',type=int,default=7)
    p.add_argument('--cpu',type=int,default=5)
    args=p.parse_args()
    if args.blocks<1: raise ValueError('need >=1 block')
    files={k:getattr(args,k) for k in ('old','new','zig')}
    # Check the original compiler artifact, not a newly built Zig compiler.
    if digest(files['zig'])!=FROZEN_ZIG: raise ValueError('wrong frozen Zig reference')
    x=19
    for i in range(6_000_000):
        x=(33*x+i+17)&1048575
    expected=struct.pack('<q',x)
    rng=random.Random(0x9e1162)
    orders=list(itertools.permutations(files))
    os.sched_setaffinity(0,{args.cpu})
    affinity=sorted(os.sched_getaffinity(0))
    if affinity!=[args.cpu]: raise ValueError('failed to pin runtime process')
    for _ in range(3):
        names=list(files)
        rng.shuffle(names)
        for k in names: time_one(files[k],expected)
    samples, paired, values=[],[],{k:[] for k in files}
    load_start=os.getloadavg()
    for b in range(args.blocks):
        rng.shuffle(orders)
        for i,ordering in enumerate(orders):
            entry={}
            for j,name in enumerate(ordering):
                ns=time_one(files[name],expected)
                values[name].append(ns)
                samples.append({'round':6*b+i+1,'order':'/'.join(ordering),'position':j+1,
                                'implementation':name,'wall_ns':ns,'answer':x})
                entry[name]=ns
            paired.append(entry)
    args.out.mkdir(exist_ok=True,parents=True)
    with (args.out/'runtime-raw.csv').open('w') as f:
        w=csv.DictWriter(f,samples[0].keys());w.writeheader();w.writerows(samples)
    summary={'method':'Wall time around process start, eight-byte stdout verification and exit; 3 warmups each and random permutation blocks, once per order per block.',
             'cpu':args.cpu,'affinity':affinity,'rounds':len(paired),'seed':0x9e1162,
             'load_start':load_start,'load_end':os.getloadavg(),'answer':x,
             'binary_sha256':{k:digest(f) for k,f in files.items()},
             'wall_ns':{k:quantiles(v) for k,v in values.items()},
             'paired_old_over_new':quantiles([r['old']/r['new'] for r in paired]),
             'paired_new_over_zig':quantiles([r['new']/r['zig'] for r in paired]),
             'paired_old_over_zig':quantiles([r['old']/r['zig'] for r in paired])}
    (args.out/'runtime-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
