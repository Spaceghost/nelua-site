#!/usr/bin/env python3
"""Differential checks for counted integer loops with a scalar Python oracle."""
import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import random
import subprocess

@dataclass(frozen=True)
class Case:
    name: str
    typ: str = 'long'
    mult: int = 33
    bias: int = 17
    mask: int = 1048575
    start: int = 0
    step: int = 1
    mode: str = 'plain'
    slope: int = 1
    ivparam: bool = False

types = {'long': (64, True), 'unsigned long': (64, False), 'int': (32, True),
         'unsigned int': (32, False), 'short': (16, True), 'unsigned short': (16, False),
         'signed char': (8, True), 'unsigned char': (8, False)}
cases = [Case('frozen'), Case('zero_multiplier', mult=0), Case('identity_multiplier', mult=1, bias=0),
         Case('even_multiplier', mult=6, bias=-137), Case('negative_multiplier', mult=-13, bias=-7),
         Case('negative_start', start=-5), Case('nonzero_start', start=5),
         Case('wrap64', 'unsigned long', 65537, 257, 2**64-1),
         Case('wrap32', 'unsigned int', 65537, 127, 2**32-1), Case('signed32', 'int', -13, 99, 32767),
         Case('u16', 'unsigned short', 17, 5, 65535), Case('i16', 'short', 17, 5, 4095),
         Case('u8', 'unsigned char', 17, 5, 255), Case('i8', 'signed char', 3, 5, 63),
         Case('sparse_mask', mask=0x51a55), Case('zero_mask', mask=0), Case('mask_one', mask=1),
         Case('stride3', step=3), Case('descend', start=12, step=-1),
         Case('unsigned_index', mode='unsigned'), Case('inclusive', mode='inclusive'),
         Case('do_while', mode='do'), Case('for_loop', mode='for'), Case('volatile_index', mode='volatile'),
         Case('trace_counter', mode='call'), Case('pointer_observation', mode='observe'), Case('early_break', mode='break'),
         Case('xor_state', mode='xor'), Case('nonlinear', 'unsigned long', mode='square'), Case('masked_once', mode='premask'),
         Case('change_bound', mode='bound'), Case('condition_in_body', mode='continue'),
         Case('mutable_stride', mode='stride'), Case('changing_mask', mode='dynmask'),
         Case('commuted', mode='commuted'), Case('two_counters', mode='two'), Case('late_update', mode='preinc'),
         Case('carry_after_loop', mode='carry'), Case('second_invariant', mode='invariant'),
         Case('alias_state', mode='alias'), Case('volatile_state', mode='vstate'),
         Case('no_index', mult=9, bias=-5, slope=0), Case('weighted_index', mult=11, bias=7, slope=5),
         Case('negative_index', mult=-3, bias=-19, slope=-2),
         Case('wide_mask', 'unsigned long', 17, 19, 2**53-1, slope=9),
         Case('high_odd', 'unsigned long', 4294967311, 127, 2**64-1, slope=29),
         Case('near_signed_end', 'unsigned long', 33, 17, 2**64-1, start=2**63-17),
         Case('near_unsigned_end', 'unsigned long', 33, 17, 2**64-1, start=2**64-17, mode='unsigned'),
         Case('post_final_i', mode='ivresult'),
         Case('repeated_additions', mult=7, bias=19, slope=3, mode='sequence'),
         Case('repeated_subtractions', mult=5, bias=40, slope=-2, mode='sequence'),
         Case('induction_first', mult=9, mode='ivfirst'),
         Case('sequence_no_index', mult=21, bias=777, slope=0, mode='sequence'),
         Case('masked_31', mult=7, bias=19, mask=2**31-1, mode='sequence', typ='unsigned long'),
         Case('near_signed_param', 'unsigned long', 33, 17, 2**64-1, start=2**63-17, ivparam=True),
         Case('near_unsigned_param', 'unsigned long', 33, 17, 2**64-1, start=2**64-17, mode='unsigned', ivparam=True),
         Case('near_negative_param', 'unsigned long', 33, 17, 2**64-1, start=-2**63, ivparam=True)]

def fixed(x, typ):
    width, signed = types[typ]
    x &= (1 << width) - 1
    return x - (1 << width) if signed and x >= 1 << (width - 1) else x

def operand(c):
    suffix = 'UL' if c.typ == 'unsigned long' else 'U' if c.typ == 'unsigned int' else ''
    return str(c.mask) + suffix

def source(c):
    counter = 'volatile long' if c.mode=='volatile' else 'unsigned long' if c.mode=='unsigned' else 'long'
    limit = 'unsigned long' if c.mode=='unsigned' else 'long'
    x_type = ('volatile ' if c.mode=='vstate' else '') + c.typ
    args = f'{limit} n, {x_type} x'
    if c.ivparam: args += f', {counter} i'
    if c.mode=='observe': args += ', unsigned long *seen'
    condition = 'i > n' if c.step < 0 else 'i <= n' if c.mode=='inclusive' else 'i < n'
    increment = f'i += {c.step}'
    induction_term = 'i' if c.slope == 1 else f'({c.slope} * i)'
    value = f'x * {c.mult} + {induction_term} + ({c.bias})'
    if c.mode=='xor':
        value = f'(x * {c.mult} + ({c.bias})) ^ i'
    elif c.mode=='square':
        value = 'x * x + i'
    elif c.mode=='commuted':
        value = f'i + ({c.bias}) + {c.mult} * x'
    elif c.mode=='two':
        value += ' + j'
    elif c.mode=='invariant':
        value += ' + hold'
    mask = operand(c) + (' ^ (i & 3)' if c.mode=='dynmask' else '')
    body = []
    if c.mode=='break': body.append('if (x == 17 || i == 19) break;')
    if c.mode=='call': body.append('tap((unsigned long)i, (unsigned long)x);')
    if c.mode=='alias': body.append('address_tap(&x, i);')
    if c.mode=='observe': body.append('*seen = *seen * 5UL + (unsigned long)x;')
    if c.mode=='preinc': body.append('++i;')
    if c.mode=='continue': body.append('if ((i & 3) == 1) { ++i; continue; }')
    if c.mode=='ivfirst': body.append('i += 1;')
    if c.mode=='sequence':
        body.append(f'x *= {c.mult};')
        body.extend(['x += i;' if c.slope>0 else 'x -= i;'] * abs(c.slope))
        body.append(f'x = (x + ({c.bias})) & ({mask});')
    else: body.append(f'x = ({value}) & ({mask});')
    if c.mode=='bound': body.append('if ((i & 3) == 0) --n;')
    if c.mode=='two': body.append('j += 3;')
    if c.mode=='stride': body.append('if ((x & 1) != 0) ++i;')
    if c.mode not in ('for','preinc','ivfirst'): body.append(increment+';')
    lines = [f'{c.typ} {c.name}({args}) {{', f'  {counter} i = {c.start}{"UL" if c.start >= 2**63 else ""};']
    if c.ivparam: lines.pop()
    if c.mode=='two': lines += ['  long j = 9;']
    if c.mode=='invariant': lines += ['  long hold = (n & 31) + 7;']
    if c.mode=='premask': lines += [f'  x &= {mask};']
    loop = 'do {' if c.mode=='do' else f'for (; {condition}; {increment}) {{' if c.mode=='for' else f'while ({condition}) {{'
    lines += ['  '+loop, *['    '+x for x in body], '  }' + (f' while ({condition});' if c.mode=='do' else '')]
    lines += ['  return ' + ('x ^ i' if c.mode=='carry' else 'i' if c.mode=='ivresult' else 'x') + ';','}']
    return '\n'.join(lines)

def scalar(c, n, x):
    x = fixed(x, c.typ)
    i, j, trace, hold = c.start, 9, 0, (n & 31)+7
    if c.mode=='premask': x &= c.mask
    first = True
    while ((i>n if c.step<0 else i<=n if c.mode=='inclusive' else i<n) or (first and c.mode=='do')):
        first = False
        if c.mode=='break' and (x==17 or i==19): break
        if c.mode=='call': trace = (trace * 5 + x + i) % 2**64
        if c.mode=='alias' and i%3==0: x ^= 31
        if c.mode=='observe': trace = (trace * 5 + x) % 2**64
        if c.mode in ('preinc','ivfirst'): i += 1
        if c.mode=='continue' and i&3 == 1:
            i += 1
            continue
        y = x*c.mult + c.slope*i + c.bias
        if c.mode=='xor': y = (x*c.mult + c.bias) ^ i
        if c.mode=='square': y = x*x + i
        if c.mode=='two': y += j
        if c.mode=='invariant': y += hold
        mask = c.mask ^ ((i&3) if c.mode=='dynmask' else 0)
        x = fixed(y & mask, c.typ)
        if c.mode=='bound' and i&3 == 0: n -= 1
        if c.mode=='two': j += 3
        if c.mode=='stride' and x&1: i += 1
        if c.mode not in ('preinc','ivfirst'): i += c.step
    if c.mode=='ivresult': x = i
    if c.mode=='carry': x = fixed(x ^ i, c.typ)
    return x % 2**64, trace

def generate(out):
    out.mkdir(parents=True, exist_ok=True)
    kernels = ['extern void tap(unsigned long i, unsigned long x);', 'extern void address_tap(long *x, long i);']
    prelude = '\n'.join(kernels)
    units = out/'units'
    units.mkdir(exist_ok=True)
    declarations, dispatch = [], []
    for index,c in enumerate(cases):
        f = source(c)
        kernels.append(f)
        (units/(c.name+'.c')).write_text(prelude+'\n'+f+'\n')
        declarations.append(f.split('{',1)[0]+';')
        args = f'({ "unsigned long" if c.mode=="unsigned" else "long"})n, ({c.typ})x'
        if c.ivparam:
            literal = f'{c.start}UL' if c.start >= 2**63 else '(-9223372036854775807L-1L)' if c.start == -2**63 else str(c.start)
            args += ', '+literal
        if c.mode=='observe': args += ', &trace'
        dispatch.append(f'    case {index}: answer = (unsigned long){c.name}({args}); break;')
    (out/'kernels.c').write_text('\n\n'.join(kernels)+'\n')
    (out/'driver.c').write_text('#include <stdio.h>\n'+'\n'.join(declarations)+'''
static unsigned long trace;
void tap(unsigned long i, unsigned long x) { trace = 5UL*trace + x + i; }
void address_tap(long *x, long i) { if (i % 3 == 0) *x ^= 31; }
int main(void) {
  unsigned int k; unsigned long n, x, answer;
  while (scanf("%u %lu %lu", &k, &n, &x) == 3) {
    trace = 0;
    switch (k) {
'''+'\n'.join(dispatch)+'''
    default: return 2;
    }
    printf("%lu %lu\\n", answer, trace);
  }
  return ferror(stdin) || ferror(stdout);
}
''')
    rng = random.Random(0xA7719E)
    inputs, outputs = [], []
    for index, c in enumerate(cases):
        width, signed = types[c.typ]
        counts = [-17,-1,0,1,2,3,4,5,7,8,9,15,16,17,30,31,32,33,63,64,65,127,128,129,255,256,257,1021]
        if c.mode == 'unsigned': counts = [n for n in counts if n>=0]
        seeds = [-513,-17,-1,0,1,17,19,71,255,1023,1048575,1048576]
        if not signed: seeds += [2**width-1, 2**(width-1)+13, 2**width-2]
        if signed and width < 64: seeds = [fixed(x,c.typ) for x in seeds]
        if signed and width == 64 and c.name != 'frozen': seeds += [-(2**40), 2**40]
        pairs = [(n,x) for n in counts for x in seeds]
        pairs += [(rng.randrange(0,950),rng.randrange(0,2**min(width,18))) for _ in range(96)]
        if c.name.startswith('near_'):
            limit = 2**64-1 if 'unsigned' in c.name else 2**63-1
            pairs = [(limit-dist, x) for dist in (0,1,2,3,7,8,9,14,15,16,17,20,33) for x in seeds]
        if c.name=='near_negative_param':
            pairs = [(c.start+count,x) for count in (0,1,15,16,17,31,32,33,63,64,127) for x in seeds]
        if c.name=='frozen':
            pairs += [(n,x) for n in (-(2**63), -1, 0) for x in (-(2**63), 2**63-1)]
        for n, x in pairs:
            inputs.append(f'{index} {n % 2**64} {x % 2**64}')
            outputs.append('%d %d' % scalar(c,n,x))
    (out/'inputs.txt').write_text('\n'.join(inputs)+'\n')
    (out/'expected.txt').write_text('\n'.join(outputs)+'\n')
    return len(inputs)

def run(cc, hostcc, out, name):
    objs = []
    for c in cases:
        obj = 'units/'+name+'-'+c.name+'.o'
        subprocess.run([cc,'-c','units/'+c.name+'.c','-o',obj],cwd=out,check=True)
        objs.append(obj)
    subprocess.run([hostcc,'-no-pie','-O2','driver.c',*objs,'-o',name],cwd=out,check=True)
    with (out/'inputs.txt').open('rb') as src:
        result = subprocess.run([str((out/name).resolve())],stdin=src,capture_output=True,timeout=20,check=True)
    expected = (out/'expected.txt').read_bytes().splitlines()
    actual = result.stdout.splitlines()
    if actual != expected:
        if len(actual)!=len(expected): raise RuntimeError(f'{name}: {len(actual)} lines, expected {len(expected)}')
        index = next(i for i,(a,b) in enumerate(zip(expected, actual)) if a!=b)
        args = (out/'inputs.txt').read_text().splitlines()[index]
        ident, n, x = args.split()
        raise RuntimeError(f'{name}: {cases[int(ident)].name} {n=} {x=} expected {expected[index]!r}, got {actual[index]!r}')
    return {'observations':len(actual),'output_sha256':hashlib.sha256(result.stdout).hexdigest()}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('out',type=Path)
    parser.add_argument('--hostcc',default='gcc')
    parser.add_argument('--check',nargs=2,action='append',default=[],metavar=('NAME','COMPILER'))
    args=parser.parse_args()
    count=generate(args.out)
    report={'functions':len(cases),'vectors':count,'implementations':{}}
    for name,compiler in args.check:
        report['implementations'][name]=run(compiler,args.hostcc,args.out,name)
    print(json.dumps(report,indent=2))
