Neboot AArch64 firmware smoke, source 09596e2
Built in Fedora Incus with Nelua, Clang and lld-link.
Verified in QEMU TCG with AArch64 EDK2.
Source and instructions: https://github.com/Spaceghost/neboot/tree/09596e2#aarch64-uefi
