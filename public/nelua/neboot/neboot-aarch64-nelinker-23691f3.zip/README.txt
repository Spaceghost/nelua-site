Neboot 23691f3, linked with Nelinker 46c05bb.
Built in Fedora Incus. Verified with AArch64 EDK2 and QEMU TCG.
https://github.com/Spaceghost/neboot/tree/23691f3#link-the-aarch64-efi-applications-with-nelinker
